# flutter_meituan

Flutter 仿美团demo

## Screenshot


<img src="https://github.com/spadekmit/Flutter_MeiTuan/raw/master/screenshot/1.jpg" width="300"/><img src="https://github.com/spadekmit/Flutter_MeiTuan/raw/master/screenshot/1-1.png" width="300"/>

<img src="https://github.com/spadekmit/Flutter_MeiTuan/raw/master/screenshot/1-2.png" width="300"/><img src="https://github.com/spadekmit/Flutter_MeiTuan/raw/master/screenshot/2.png" width="300"/>

<img src="https://github.com/spadekmit/Flutter_MeiTuan/raw/master/screenshot/3.jpg" width="300"/><img src="https://github.com/spadekmit/Flutter_MeiTuan/raw/master/screenshot/4.jpg" width="300"/>

<img src="https://github.com/spadekmit/Flutter_MeiTuan/raw/master/screenshot/5.jpg" width="300"/><img src="https://github.com/spadekmit/Flutter_MeiTuan/raw/master/screenshot/6.jpg" width="300"/>

<img src="https://github.com/spadekmit/Flutter_MeiTuan/raw/master/screenshot/7.jpg" width="300"/><img src="https://github.com/spadekmit/Flutter_MeiTuan/raw/master/screenshot/8.jpg" width="300"/>

<img src="https://github.com/spadekmit/Flutter_MeiTuan/raw/master/screenshot/9.jpg" width="300"/><img src="https://github.com/spadekmit/Flutter_MeiTuan/raw/master/screenshot/10.png" width="300"/>

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our 
[online documentation](https://flutter.dev/docs), which offers tutorials, 
samples, guidance on mobile development, and a full API reference.
