/// 网络类型
class NetworkType {
  static final int kNetworkStateMobile = 1;
  static final int kNetworkState2g = 2;
  static final int kNetworkState3g = 3;
  static final int kNetworkStateWifi = 4;
  static final int kNetworkState4g = 5;
  static final int kNetworkState5g = 6;
}
