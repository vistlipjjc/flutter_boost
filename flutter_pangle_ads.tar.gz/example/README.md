# flutter_pangle_ads_example
<p align="center">
<img src="https://raw.githubusercontent.com/FlutterAds/site/master/logo/flutterads_logo.png" alt="logo" height="144"/>
</p>
<a href="https://github.com/FlutterAds"><h3 align="center">FlutterAds 致力于构建优质的 Flutter 广告插件</h3></a>

## 联系作者
- 微信：ZeroFlutter
- 邮箱：zhengsonglan001@gmail.com

## 支持开源

<img src="https://github.com/yy1300326388/yy1300326388/blob/main/images/pay_qr_code/pay_qr_code.png?raw=true" alt="支持作者" height="160"/>

> 或许你不知道经过了多少个夜晚，就是为了方便你使用
