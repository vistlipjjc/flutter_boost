//
//  FAQRewardVideoPage.h
//  flutter_qq_ads
//
//  Created by zero on 2021/8/19.
//

#import "FAQBaseAdPage.h"
// 激励视频页面
@interface FAQRewardVideoPage : FAQBaseAdPage
@end
