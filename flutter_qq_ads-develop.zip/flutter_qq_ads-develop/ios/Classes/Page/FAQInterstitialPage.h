//
//  FAQInterstitialPage.h
//  flutter_qq_ads
//
//  Created by zero on 2021/8/18.
//

#import "FAQBaseAdPage.h"
// 插屏广告
@interface FAQInterstitialPage : FAQBaseAdPage
@end
