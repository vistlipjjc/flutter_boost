#!/bin/bash

flutter pub get
open ./ -a Visual\ Studio\ Code.app
