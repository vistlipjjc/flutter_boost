package com.flutterruntime.flutter_runtime_ide

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
