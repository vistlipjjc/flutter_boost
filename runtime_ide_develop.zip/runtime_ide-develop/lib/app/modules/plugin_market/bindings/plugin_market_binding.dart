import 'package:get/get.dart';

class PluginMarketBinding extends Bindings {
  @override
  void dependencies() {
    // Get.lazyPut<PluginMarketController>(
    //   () => PluginMarketController(),
    // );
  }
}
