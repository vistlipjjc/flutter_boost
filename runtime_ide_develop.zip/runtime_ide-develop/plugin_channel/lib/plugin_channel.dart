/// Support for doing something awesome.
///
/// More dartdocs go here.
library plugin_channel;

export 'src/channel_identifier.dart';
export 'src/channel_resource.dart';
