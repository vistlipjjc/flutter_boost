package com.example.flutter_bilibili;

import com.baidu.mapapi.base.BmfMapApplication;

public class MyApplication extends BmfMapApplication {

}
