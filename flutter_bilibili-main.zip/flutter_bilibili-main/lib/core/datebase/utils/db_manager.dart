import 'dart:io';

import 'package:sqflite/sqflite.dart';

///数据库工具类
class DBManager {
  ///数据库版本
  static const int _version = 1;

  ///数据库名称
  static const String _dbName = "bilibili.db";

  ///数据库实例
  static late Database _database;

  ///获取当前数据库的实例
  static Future<Database> getCurrentDatabase() async {
    var databasePath = await getDatabasesPath();
    String dbName = _dbName;
    String path = databasePath + dbName;
    if (Platform.isIOS) {
      path = databasePath + "/" + dbName;
    }

    ///打开数据库
    _database = await openDatabase(
      path,
      version: _version,
      onCreate: (Database db, int version) async {
        ///创建表
      },
    );
    return _database;
  }

  ///判断表是否存在
  static judgeTableExits(String tableName) async {
    await getCurrentDatabase();
    String sql =
        "select * from Sqlite_master where type = 'table' and name = '$tableName'";
    var res = await _database.rawQuery(sql);
    return res.isNotEmpty;
  }

  ///关闭数据库
  static close() {
    _database.close();
  }
}
