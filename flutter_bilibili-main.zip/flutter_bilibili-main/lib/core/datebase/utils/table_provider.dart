import 'package:sqflite/sqflite.dart';

import 'db_manager.dart';

///数据库表抽象类
abstract class TableProvider {
  bool isTableExist = false;

  tableSqlString();

  tableName();

  ///创建表基础sql语句
  tableBaseString(String name, String columnId) {
    return '''
      create table $name ($columnId integer primary key autoincrement, 
    ''';
  }

  ///判断表是否存在；创建表
  prepare(tableName, createSql) async {
    isTableExist = await DBManager.judgeTableExits(tableName);
    if (!isTableExist) {
      Database db = await DBManager.getCurrentDatabase();
      return await db.execute(createSql);
    }
  }

  Future<Database> getDatabase() async {
    if (!isTableExist) {
      await prepare(tableName(), tableSqlString());
    }
    return await DBManager.getCurrentDatabase();
  }
}
