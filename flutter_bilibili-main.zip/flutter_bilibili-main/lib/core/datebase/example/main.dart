import 'dart:math';

import 'package:flutter/material.dart';

import '../dao/chat_dao.dart';
import '../model/chat_ message.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late String _nameText;
  late String _queryIdText;
  late String _deleteIdText;
  late String _updateIdText;
  late String _updateNameText;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      onChanged: (text) {
                        _nameText = text;
                      },
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      insertMessage(_nameText);
                    },
                    child: Text("插入数据"),
                  ),
                ],
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Expanded(
                    child: TextField(
                      onChanged: (text) {
                        _queryIdText = text;
                      },
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      queryMessageById(_queryIdText);
                    },
                    child: Text("查询数据（单个）"),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      onChanged: (text) {
                        _deleteIdText = text;
                      },
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      deleteMessageById(_deleteIdText);
                    },
                    child: Text("删除数据（单个）"),
                  )
                ],
              ),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      onChanged: (text) {
                        _updateIdText = text;
                      },
                    ),
                  ),
                  Expanded(
                    child: TextField(
                      onChanged: (text) {
                        _updateNameText = text;
                      },
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      updateMessageWithName(_updateIdText, _updateNameText);
                    },
                    child: Text("更新数据（单个）"),
                  )
                ],
              ),
              ElevatedButton(
                onPressed: () {
                  queryMessageList();
                },
                child: Text("查询所有数据"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  ///插入数据
  Future insertMessage(String name) async {
    int random = Random().nextInt(10000);
    ChatDao dao = ChatDao();
    ChatMessage message = ChatMessage(id: random.toString(), name: name);
    int i = await dao.insert(message);
    print("插入数据: $i");
  }

  ///根据ID查询数据
  Future queryMessageById(String id) async {
    ChatDao dao = ChatDao();
    ChatMessage? message = await dao.getMessageById(id);
    if (message == null) {
      print("无法查询到数据");
    } else {
      print("获取数据" + message.toJson().toString());
    }
  }

  ///查询所有数据
  Future queryMessageList() async {
    ChatDao dao = ChatDao();
    List<ChatMessage>? messages = await dao.getMessageList();
    if (messages == null) {
      print("没有数据");
    } else {
      print("获取数据列表");
      for (var item in messages) {
        print(item.toJson().toString());
      }
    }
  }

  Future deleteMessageById(String id) async {
    ChatDao dao = ChatDao();
    int i = await dao.deleteById(id);
    print("删除数据: $i");
  }

  Future updateMessageWithName(String id, String name) async {
    ChatDao dao = ChatDao();
    int i = await dao.updateById(id, name);
    print("更新数据: $i");
  }
}
