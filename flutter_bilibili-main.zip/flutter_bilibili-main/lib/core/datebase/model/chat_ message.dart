class ChatMessage {
  ChatMessage({
    required this.id,
    required this.name,
  });

  String id;
  String name;

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
        id: json["id"],
        name: json["name"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
      };
}
