import 'package:flutter/cupertino.dart';

import '../model/live_rooms_model.dart';
import '../service/request/live_room_list_request.dart';

class HYLiveRoomViewModel extends ChangeNotifier {
  List<RecommendRoomList> _recommendLiveRooms = [];
  List<RoomList> _roomList = [];
  List<RoomListList> _wzryRoomList = [];

  List<RecommendRoomList> get recommendLiveRooms => _recommendLiveRooms;

  set recommendLiveRooms(List<RecommendRoomList> value) {
    _recommendLiveRooms = value;
  }

  List<RoomList> get roomList => _roomList;

  set roomList(List<RoomList> value) {
    _roomList = value;
  }

  List<RoomListList> get wzryRoomList => _wzryRoomList;

  set wzryRoomList(List<RoomListList> value) {
    _wzryRoomList = value;
  }

  HYLiveRoomViewModel() {
    //请求数据
    HYLiveRoomsRequest.getLiveRoomsData().then((res) {
      _recommendLiveRooms = res.recommendRoomList;
      _roomList = res.roomList;
      _wzryRoomList = res.roomList[4].list;
      notifyListeners();
    });
  }
}