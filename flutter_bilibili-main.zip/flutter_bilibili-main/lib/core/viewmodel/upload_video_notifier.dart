import 'package:flutter/cupertino.dart';

class UploadVideoNotifier extends ChangeNotifier {
  ///当前播放的视频
  int _currentVideoIndex = 0;

  int get currentVideoIndex => _currentVideoIndex;

  set currentVideoIndex(int value) {
    _currentVideoIndex = value;
    notifyListeners();
  }

  UploadVideoNotifier() {
    _currentVideoIndex = 0;
  }
}
