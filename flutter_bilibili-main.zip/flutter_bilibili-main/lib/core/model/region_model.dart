class RegionModel {
  String region = "中国";
  String telNum = "+86";

  RegionModel(this.region, this.telNum);
}