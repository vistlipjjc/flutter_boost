import '../../ui/shared/math_compute.dart';

class HYLocalVideoModel {
  String videoName;
  String videoLocation;
  String duration;

  HYLocalVideoModel(
      {required this.videoName,
      required this.videoLocation,
      required this.duration});
}
