class HYImageModel {
  String name;
  String location;

  HYImageModel(this.name, this.location);
}
