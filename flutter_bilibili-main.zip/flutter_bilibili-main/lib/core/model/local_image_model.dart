///手机本地图片
class HYLocalImageModel {
  String imageName;
  String imageLocation;

  HYLocalImageModel(this.imageName, this.imageLocation);
}
