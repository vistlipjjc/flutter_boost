import 'package:event_bus/event_bus.dart';

///跨Widget通信
///用户基本信息
final accountMineEventBus = EventBus();

///点击头像等效于跳转“我的”界面
final mineEventBus = EventBus();
