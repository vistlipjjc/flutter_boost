///建立Android端与Flutter端之间的通信（Channel）
///定义唯一标识的Channel ID
class HYChannel {
  ///上传视频
  static const String uploadDataChannel = "upload_data";
}
