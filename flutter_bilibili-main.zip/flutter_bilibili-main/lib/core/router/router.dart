import 'package:flutter/material.dart';
import 'package:flutter_bilibili/ui/pages/charts/charts.dart';
import 'package:flutter_bilibili/ui/pages/dynamic_circle/dynamic_circle.dart';
import 'package:flutter_bilibili/ui/pages/home/home.dart';
import 'package:flutter_bilibili/ui/pages/home/search/search.dart';
import 'package:flutter_bilibili/ui/pages/login/login.dart';
import 'package:flutter_bilibili/ui/pages/main/main.dart';
import 'package:flutter_bilibili/ui/pages/mine/mine.dart';
import 'package:flutter_bilibili/ui/pages/mine/mine_scan_login.dart';
import 'package:flutter_bilibili/ui/pages/publish/baidu_map_location.dart';
import 'package:flutter_bilibili/ui/pages/publish/publish.dart';
import 'package:flutter_bilibili/ui/pages/video_play/video/video_play.dart';
import 'package:flutter_bilibili/ui/pages/vip_shop/vip_shop.dart';
import 'package:get/get_navigation/src/routes/get_route.dart';

import '../../ui/pages/live/live_room_play.dart';
import '../../ui/pages/mine/offline_cache/offline_cache.dart';
<<<<<<< HEAD
=======
import '../../ui/pages/mine/setting/setting_binding.dart';
>>>>>>> e6f29a1a2d8662694d549211f094eba34e796f37
import '../../ui/pages/publish/ready_2_publish.dart';
import '../../ui/pages/push/push.dart';

class HYRouter {
  static const String initialRoute = HYMainScreen.routeName;

  ///初始化路由,指的是到主页 "/"
  static Map<String, WidgetBuilder> routes = {
    HYMainScreen.routeName: (ctx) => const HYMainScreen(),

    ///所有页面的入口
    HYHomeScreen.routeName: (ctx) => const HYHomeScreen(),

    ///home主页
    HYDynamicCircleScreen.routeName: (ctx) => const HYDynamicCircleScreen(),

    ///动态圈页面
    HYMineScreen.routeName: (ctx) => const HYMineScreen(),

    ///”我的“页面
    HYVipShopScreen.routeName: (ctx) => const HYVipShopScreen(),

    ///会员购页面
    HYLoginScreen.routeName: (ctx) => HYLoginScreen(),

    ///登录页面
    HYMineScanLogin.routeName: (ctx) => HYMineScanLogin(),

    ///视频播放界面
    HYVideoPlayScreen.routeName: (ctx) => const HYVideoPlayScreen(),

    ///图表界面
    HYChartScreen.routeName: (ctx) => const HYChartScreen(),

    ///百度地图定位
    HYBaiduMapLocationScreen.routeName: (ctx) =>
        const HYBaiduMapLocationScreen(),

    ///发布界面
    HYPublishScreen.routeName: (ctx) => const HYPublishScreen(),

    ///准备发布界面
    HYReady2PublishScreen.routeName: (ctx) => HYReady2PublishScreen(),

    ///直播界面
    HYLiveRoomPlayScreen.routeName: (ctx) => const HYLiveRoomPlayScreen(),

    ///推送界面
    HYPushScreen.routeName: (ctx) => const HYPushScreen(),

    ///离线缓存
    HYOfflineCacheScreen.routeName: (ctx) => const HYOfflineCacheScreen(),

    ///主页的搜索界面
    HYHomeSearchScreen.routeName: (ctx) => const HYHomeSearchScreen()
  };

  ///getX的别名路由
<<<<<<< HEAD
  // static final List<GetPage> getPages = [
  //   GetPage(
  //     name: HYSettingScreen.routeName,
  //     page: () => const HYSettingScreen(),
  //   )
  // ];
=======
  static final List<GetPage> getPages = [
    GetPage(
      name: SettingPage.routeName,
      page: () => SettingPage(),
      binding: SettingBinding(),
    )
  ];
>>>>>>> e6f29a1a2d8662694d549211f094eba34e796f37
}
