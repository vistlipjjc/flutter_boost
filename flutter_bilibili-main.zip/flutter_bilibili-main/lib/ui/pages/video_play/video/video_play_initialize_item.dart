import 'package:flutter_screenutil/flutter_screenutil.dart';

final videoPlayIconSize = 17.sp;
final videoPlayActiveIcon = 17.sp;
