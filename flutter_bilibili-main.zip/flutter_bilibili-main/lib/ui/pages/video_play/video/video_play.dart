import 'package:flutter/material.dart';
import 'package:flutter_bilibili/core/model/video_model.dart';
import 'package:flutter_bilibili/ui/pages/video_play/video/video_play_content.dart';

import '../../../../core/model/feed_index_model.dart';

class HYVideoPlayScreen extends StatelessWidget {
  static const String routeName = "/video_play";

  const HYVideoPlayScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double aspectRatio = MediaQuery.of(context).size.aspectRatio;
    FeedIndexItem _videoData =
        ModalRoute.of(context)?.settings.arguments as FeedIndexItem;
    return SafeArea(
        child: HYVideoPlayContent(video: _videoData, aspectRatio: aspectRatio));
  }
}