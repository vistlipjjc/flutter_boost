// import 'package:flutter/material.dart';
// class DanMuItem extends StatefulWidget {
//   String title;
//   double top;
//
//   DanMuItem(this.title, this.top);
//
//   @override
//   State<DanMuItem> createState() => _DanMuItemState();
// }
//
// class _DanMuItemState extends State<DanMuItem>
//     with SingleTickerProviderStateMixin {
//   late AnimationController controller;
//   late Animation<Offset> animation;
//
//   @override
//   void initState() {
//     controller =
//         AnimationController(duration: Duration(seconds: 12), vsync: this);
//     controller.addStatusListener((status) {
//       if (status == AnimationStatus.completed) {
//         // controller.reverse();
//       } else if (status == AnimationStatus.dismissed) {
//         controller.stop();
//       }
//     });
//     animation = Tween(begin: Offset(1.0, .0), end: Offset(-1.0, .0))
//         .animate(controller);
//     controller.forward();
//     super.initState();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Positioned.fill( ///这里的fill是指整个stack的position，去掉之后就是相对上一个弹幕
//       top: widget.top,
//       child: SlideTransition(
//         position: animation,
//         child: Text(
//           widget.title,
//           style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
//         ),
//       ),
//     );
//   }
//
//   @override
//   void dispose() {
//     controller.dispose();
//     super.dispose();
//   }
// }
