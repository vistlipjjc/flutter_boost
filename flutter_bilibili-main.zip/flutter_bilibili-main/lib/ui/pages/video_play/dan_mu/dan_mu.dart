import 'package:flutter/material.dart';

import 'dan_mu_item.dart';

// class DanMu extends StatefulWidget {
//   DanMu({required Key key}): super(key: key);
//
//   @override
//   State<DanMu> createState() => DanMuState();
// }
//
// class DanMuState extends State<DanMu> {
//   List<DanMuItem> _danMuList = [];
//   addDanMu(String title, double top) {
//     _danMuList.add(DanMuItem(title, top));
//     setState(() {});
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return LayoutBuilder(
//       builder: (context, constraintType) {
//         return Stack(
//           children: _danMuList,
//         );
//       },
//     );
//   }
// }
