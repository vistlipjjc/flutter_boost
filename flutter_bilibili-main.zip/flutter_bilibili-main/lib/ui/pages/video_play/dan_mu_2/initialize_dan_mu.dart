///每条轨道距离顶部距离
List<double> movingDMRouteTop = [5, 25, 45, 65, 85, 105];
List<double> topDMRouteTop = [5, 25, 45];
List<double> bottomDMRouteTop = [140, 160, 180];

///每条轨道运动时间不同
List<int> moveTimeList = [13000, 12000, 11000, 13000, 12000, 11000];
List<int> showTimeList = [4000, 4500, 5000];
