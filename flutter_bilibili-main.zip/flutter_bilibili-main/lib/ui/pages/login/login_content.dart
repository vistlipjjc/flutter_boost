import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bilibili/core/shared_preferences/bilibili_shared_preference.dart';
import 'package:flutter_bilibili/ui/pages/login/initialize_login.dart';
import 'package:flutter_bilibili/ui/shared/app_theme.dart';
import 'package:flutter_bilibili/ui/widgets/timer_button.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'package:get/get_utils/get_utils.dart';

import '../../../core/I18n/str_res_keys.dart';
import '../../../core/event_bus/event_bus.dart';
import '../../../core/service/request/login_request.dart';
import '../../../core/shared_preferences/shared_preference_util.dart';
import '../../shared/image_assets.dart';
import '../../shared/params_sign.dart';
import '../../widgets/rectangle_checkBox.dart';

class HYLoginContent extends StatefulWidget {
  const HYLoginContent({Key? key}) : super(key: key);

  @override
  State<HYLoginContent> createState() => _HYLoginContentState();
}

class _HYLoginContentState extends State<HYLoginContent> with InitializeLogin {
  late TextEditingController _telTextEditController;
  late TextEditingController _verifyPasswordTextFieldController;
  late TextEditingController _userNameTextEditController;
  late TextEditingController _passwordTextFieldController;

  ///电话号码
  String _telText = "";

  ///验证码
  String _verifyText = "";

  ///用户名
  String _userNameText = "";

  ///登录密码
  String _passwordText = "";

  ///判断当前是以什么方式登录的
  bool loginTypeIsMessage = true;
  late String webViewUrl = "";

  ///appKey和appSec用于安卓端接口（传值、计算sign）
  var appKey = '1d8b6e7d45233436';
  var appSec = '560c52ccd288fed045859ed18bffd973';

  ///发送验证码后得到key
  String captchaKey = "";

  ///电话的地区前缀
  String cid = '86';

  @override
  void initState() {
    _telTextEditController = TextEditingController();
    _verifyPasswordTextFieldController = TextEditingController();
    _userNameTextEditController = TextEditingController();
    _passwordTextFieldController = TextEditingController();
    super.initState();
  }

  @override
  void dispose() {
    _telTextEditController.dispose();
    _verifyPasswordTextFieldController.dispose();
    _userNameTextEditController.dispose();
    _passwordTextFieldController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: .5,
        backgroundColor: Colors.white,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Icon(
            Icons.arrow_back,
            color: HYAppTheme.norTextColors,
            size: HYAppTheme.normalFontSize,
          ),
        ),
        title: Text(
          loginTypeIsMessage == true
              ? SR.telRegisterAndLogin.tr.toUpperCase()
              : SR.passwordLogin.tr.toUpperCase(),
          style: TextStyle(
              fontSize: HYAppTheme.xSmallFontSize,
              color: HYAppTheme.norTextColors,
              fontWeight: FontWeight.normal),
        ),
        actions: [
          ///右上角的密码登录
          GestureDetector(
            onTap: () {
              loginTypeIsMessage = !loginTypeIsMessage;
              setState(() {});
            },
            child: Center(
                child: Text(
              loginTypeIsMessage == true
                  ? SR.passwordLogin.tr
                  : SR.telRegisterAndLogin.tr,
              style: TextStyle(
                  fontSize: HYAppTheme.xxSmallFontSize,
                  color: HYAppTheme.norTextColors,
                  fontWeight: FontWeight.bold),
            )),
          ),
          10.horizontalSpace,
        ],
      ),
      body: Column(
        children: [
          ///2233娘背景
          buildLoginImage(),
          loginTypeIsMessage == true ? buildLoginRegion(context) : Container(),

          ///电话号码
          loginTypeIsMessage == true
              ? buildLoginTel(context)
              : buildUserNameAndPassword(),

          15.verticalSpace,

          ///登录按钮
          loginTypeIsMessage == true
              ? buildVerifyLoginButton()
              : buildRegisterAndLoginButton(),
          15.verticalSpace,

          ///用户协议部分
          buildLoginAgreement(),
        ],
      ),

      ///防止键盘弹出超出边界
      resizeToAvoidBottomInset: false,
    );
  }

  ///验证登录（短信登录的登录按钮）
  Widget buildVerifyLoginButton() {
    return Opacity(
      opacity: _telText.isNotEmpty && _verifyText.isNotEmpty ? 1 : .5,
      child: ElevatedButton(
        style: ButtonStyle(
          overlayColor: MaterialStateProperty.all(
              HYAppTheme.norTextColors.withOpacity(.1)),
          elevation: MaterialStateProperty.all(0),
          backgroundColor:
              MaterialStateProperty.all(HYAppTheme.norMainThemeColors),
          minimumSize: MaterialStateProperty.all(Size(1.sw - 30.w, 40.h)),
        ),
        onPressed: _telText.isNotEmpty && _verifyText.isNotEmpty
            ? () {
                ///短信验证登录（同时获取登录后的用户基本信息）
                messageVerifyLogin(_telText, _verifyText, captchaKey, cid);
              }
            : () {
                SmartDialog.showToast("电话或验证码为空");
              },
        child: Text(
          SR.verifyLogin.tr,
          style: TextStyle(
              color: Colors.white, fontSize: HYAppTheme.xSmallFontSize),
        ),
      ),
    );
  }

  Widget buildRegisterAndLoginButton() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        ElevatedButton(
          style: ButtonStyle(
              overlayColor: MaterialStateProperty.all(
                  HYAppTheme.norTextColors.withOpacity(.1)),
              elevation: MaterialStateProperty.all(0),
              backgroundColor: MaterialStateProperty.all(Colors.white),
              minimumSize: MaterialStateProperty.all(Size(.5.sw - 15.w, 40.h)),
              shape: MaterialStateProperty.all(
                RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(const Radius.circular(3).r),
                    side:
                        const BorderSide(color: HYAppTheme.norMainThemeColors)),
              )),
          onPressed: _userNameText.isNotEmpty && _passwordText.isNotEmpty
              ? () {
                  // ///点击验证登录
                  // HYSpaceAccInfoRequest.getSpaceAccInfoData(243766934)
                  //     .then((value) {
                  //   spaceAccInfoEventBus.fire(value);
                  //   Navigator.of(context).pop();
                  // });
                }
              : null,
          child: Text(
            SR.register.tr.toUpperCase(),
            style: TextStyle(
                color: HYAppTheme.norMainThemeColors,
                fontSize: HYAppTheme.xSmallFontSize,
                fontWeight: FontWeight.normal),
          ),
        ),
        Opacity(
          opacity:
              _userNameText.isNotEmpty && _passwordText.isNotEmpty ? 1 : .5,
          child: ElevatedButton(
            style: ButtonStyle(
              overlayColor: MaterialStateProperty.all(
                  HYAppTheme.norTextColors.withOpacity(.1)),
              elevation: MaterialStateProperty.all(0),
              backgroundColor:
                  MaterialStateProperty.all(HYAppTheme.norMainThemeColors),
              minimumSize: MaterialStateProperty.all(Size(.5.sw - 15.w, 40.h)),
            ),
            onPressed: _userNameText.isNotEmpty && _passwordText.isNotEmpty
                ? () {
                    SmartDialog.showToast("密码登录暂时不行");
                  }
                : null,
            child: Text(
              SR.login.tr.toUpperCase(),
              style: TextStyle(
                  color: Colors.white,
                  fontSize: HYAppTheme.xSmallFontSize,
                  fontWeight: FontWeight.normal),
            ),
          ),
        ),
      ],
    );
  }

  ///2233娘
  Widget buildLoginImage() {
    return Stack(
      children: [
        Center(
            child: Image.asset(
          ImageAssets.bilibiliPNG,
          width: imageWidth,
          height: imageHeight,
        )),
        Positioned(
          child: Image.asset(ImageAssets.open22PNG),
          width: imageWidth,
          height: imageHeight,
          left: 0,
          bottom: 0,
        ),
        Positioned(
          child: Image.asset(ImageAssets.open33PNG),
          width: imageWidth,
          height: imageHeight,
          right: 0,
          bottom: 0,
        ),
      ],
    );
  }

  ///地区（+86）
  Widget buildLoginRegion(BuildContext context) {
    return GestureDetector(
      onTap: () {
        buildRegionDialog(context);
      },
      child: Stack(
        children: [
          Container(
            alignment: Alignment.centerLeft,
            child: Text(
              regionList[regionIndex].region,
              style: const TextStyle(color: HYAppTheme.norTextColors),
            ),
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15).r,
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border(
                ///底部设置边框
                bottom: BorderSide(
                    width: 1.w, color: Theme.of(context).canvasColor),
              ),
            ),
          ),
          Positioned(
              right: 15.w,
              top: 0,
              bottom: 0,
              child: Icon(
                Icons.arrow_forward_ios,
                size: 15.sp,
              ))
        ],
      ),
    );
  }

  Widget buildUserNameAndPassword() {
    return Container(
      color: Colors.white,
      width: 1.sw,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 15).r,
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border(
                bottom: BorderSide(
                    width: 2.w, color: Theme.of(context).canvasColor),
              ),
            ),
            child: Row(
              children: [
                Container(
                  child: Text(SR.account.tr,
                      style: TextStyle(
                          color: HYAppTheme.norTextColors,
                          fontSize: HYAppTheme.xxSmallFontSize,
                          fontWeight: FontWeight.bold)),
                  alignment: Alignment.centerLeft,
                  width: 45.w,
                ),
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.only(left: 15).r,
                    child: TextField(
                      autofocus: true,
                      showCursor: true,
                      cursorHeight: HYAppTheme.normalFontSize,
                      onChanged: (text) {
                        _userNameText = text;
                        setState(() {});
                      },
                      cursorColor: HYAppTheme.norMainThemeColors,
                      controller: _userNameTextEditController,
                      decoration: InputDecoration(
                          hintText: SR.pleaseInputTelOrMail.tr,
                          border: InputBorder.none,
                          hintStyle: TextStyle(
                            fontSize: HYAppTheme.xxSmallFontSize,
                          )),
                      style: TextStyle(
                          fontSize: HYAppTheme.xSmallFontSize,
                          color: HYAppTheme.norMainThemeColors),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 15).r,
            child: Row(
              children: [
                Container(
                  alignment: Alignment.centerLeft,
                  width: 45.w,
                  child: Text(
                    SR.password.tr,
                    style: TextStyle(
                        color: HYAppTheme.norTextColors,
                        fontSize: HYAppTheme.xxSmallFontSize,
                        fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.only(left: 15).r,
                    child: TextField(
                        onChanged: (text) {
                          _passwordText = text;
                          setState(() {});
                        },
                        showCursor: true,
                        cursorHeight: HYAppTheme.normalFontSize,
                        cursorColor: HYAppTheme.norMainThemeColors,
                        controller: _passwordTextFieldController,
                        decoration: InputDecoration(
                            hintText: SR.pleaseInputPassword.tr,
                            border: InputBorder.none,
                            hintStyle: TextStyle(
                              fontSize: HYAppTheme.xxSmallFontSize,
                            )),
                        style: TextStyle(
                            fontSize: HYAppTheme.xSmallFontSize,
                            color: HYAppTheme.norTextColors)),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.only(left: 20).r,
                  child: Text(
                    SR.forgetPassword.tr,
                    style: TextStyle(
                        color: HYAppTheme.norMainThemeColors,
                        fontSize: HYAppTheme.xxSmallFontSize,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  ///手机号码/验证码
  Widget buildLoginTel(BuildContext context) {
    return Container(
      color: Colors.white,
      width: double.infinity,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 15).r,
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border(
                bottom: BorderSide(
                    width: 2.w, color: Theme.of(context).canvasColor),
              ),
            ),
            child: Row(
              children: [
                Container(
                  child: Text(regionList[regionIndex].telNum,
                      style: TextStyle(
                        color: HYAppTheme.norTextColors,
                        fontSize: HYAppTheme.xxSmallFontSize,
                      )),
                  alignment: Alignment.centerLeft,
                  width: 40.w,
                ),
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.only(left: 15).r,
                    child: TextField(
                      autofocus: true,
                      showCursor: true,
                      cursorHeight: HYAppTheme.normalFontSize,
                      onChanged: (text) {
                        _telText = text;
                        setState(() {});
                      },
                      cursorColor: HYAppTheme.norMainThemeColors,
                      controller: _telTextEditController,
                      decoration: InputDecoration(
                          hintText: SR.pleaseInputTel.tr,
                          border: InputBorder.none,
                          hintStyle: TextStyle(
                            fontSize: HYAppTheme.xxSmallFontSize,
                          )),
                      style: TextStyle(
                          fontSize: HYAppTheme.xSmallFontSize,
                          color: HYAppTheme.norMainThemeColors),
                    ),
                  ),
                ),
                _telText.isNotEmpty
                    ? HYTimerButton(
                        onTap: () {
                          SmartDialog.showToast("已发送验证码短信");
                          sendSMS(_telText);
                        },
                      )
                    : HYTimerButton(
                        onTap: () {
                          SmartDialog.showToast("嘿，留个电话~");
                        },
                        isEnable: false,
                      )
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 15).r,
            child: Row(
              children: [
                Container(
                  alignment: Alignment.centerLeft,
                  width: 40.w,
                  child: Text(
                    SR.code.tr,
                    style: TextStyle(
                      color: HYAppTheme.norTextColors,
                      fontSize: HYAppTheme.xxSmallFontSize,
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.only(left: 15).r,
                    child: TextField(
                        onChanged: (text) {
                          _verifyText = text;
                          setState(() {});
                        },
                        showCursor: true,
                        cursorHeight: HYAppTheme.normalFontSize,
                        cursorColor: HYAppTheme.norMainThemeColors,
                        controller: _verifyPasswordTextFieldController,
                        decoration: InputDecoration(
                            hintText: SR.pleaseInputCode.tr,
                            border: InputBorder.none,
                            hintStyle: TextStyle(
                              fontSize: HYAppTheme.xxSmallFontSize,
                            )),
                        style: TextStyle(
                            fontSize: HYAppTheme.xSmallFontSize,
                            color: HYAppTheme.norTextColors)),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  ///选择地区的弹框
  buildRegionDialog(BuildContext context) async {
    List<Widget> widgets = [];
    for (int i = 0; i < regionList.length; i++) {
      widgets.add(TextButton(
        onPressed: () {
          regionIndex = i;
          Navigator.pop(context);
        },
        child: Text(
          regionList[i].region,
          style: const TextStyle(color: HYAppTheme.norTextColors),
        ),
      ));
    }
    var regionDialog = await showDialog(
      context: context,
      builder: (context) {
        return SimpleDialog(
          title: Text(
            SR.zone.tr,
            style: TextStyle(
                fontSize: HYAppTheme.xSmallFontSize,
                fontWeight: FontWeight.bold),
          ),
          children: widgets,
        );
      },
    );
    return regionDialog;
  }

  buildLoginAgreement() {
    bool flag = true;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15).r,
      child: Column(
        children: [
          GestureDetector(
            //checkbox
            onTap: () {
              setState(() {
                flag = !flag;
              });
            },
            child: Text.rich(
              //实现换行
              TextSpan(
                children: [
                  WidgetSpan(
                    child: RectangleCheckBox(
                      //自定义矩形的checkbox
                      size: HYAppTheme.xSmallFontSize,
                      checkedColor: HYAppTheme.norMainThemeColors,
                      isChecked: flag,
                      onTap: (value) {
                        setState(() {
                          flag = value!;
                        });
                      },
                    ),
                  ),
                  TextSpan(
                    text: "   ",
                    style: TextStyle(fontSize: HYAppTheme.xxSmallFontSize),
                  ),
                  TextSpan(
                    text: SR.userAgreementText01.tr,
                    style: TextStyle(
                        color: Colors.grey,
                        fontSize: HYAppTheme.xxSmallFontSize),
                  ),
                  TextSpan(
                    text: SR.userAgreementText02A.tr,
                    style: TextStyle(
                        color: Colors.blue,
                        fontSize: HYAppTheme.xxSmallFontSize),
                  ),
                  TextSpan(
                    text: SR.userAgreementText03.tr,
                    style: TextStyle(
                        color: Colors.grey,
                        fontSize: HYAppTheme.xxSmallFontSize),
                  ),
                  TextSpan(
                    text: SR.userAgreementText02B.tr,
                    style: TextStyle(
                        color: Colors.blue,
                        fontSize: HYAppTheme.xxSmallFontSize),
                  ),
                  loginTypeIsMessage == true
                      ? TextSpan(
                    text: SR.userAgreementText05.tr,
                          style: TextStyle(
                              color: Colors.grey,
                              fontSize: HYAppTheme.xxSmallFontSize),
                        )
                      : const TextSpan(),
                ],
              ),
            ),
          ),
          20.verticalSpace,
          Text.rich(
            TextSpan(
              children: [
                TextSpan(
                  text: SR.havingProblems.tr,
                  style: TextStyle(
                      color: Colors.grey, fontSize: HYAppTheme.xxSmallFontSize),
                ),
                TextSpan(
                  text: SR.seeTheHelp.tr,
                  style: TextStyle(
                      color: Colors.blue, fontSize: HYAppTheme.xxSmallFontSize),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  ///发送短信
  void sendSMS(String tel) {
    ///格式必须加入单引号，key和value都要加，否则格式有误
    Map<String, dynamic> originalQuery = {
      'appkey': appKey,
      'build': '6720300',
      'buvid': 'XZBF5D5B82C2D9D36FA139ED863534AC258FF',
      'c_locale': 'zh_CN',
      'channel': 'html5_search_baidu',
      'cid': '86',
      'device_tourist_id': '20096420566197',
      'disable_rcmd': '0',
      'local_id': 'XZBF5D5B82C2D9D36FA139ED863534AC258FF',
      'login_session_id': '0423050c1436b3354f14ef999b581179',
      'mobi_app': 'android',
      'platform': 'android',
      's_locale': 'zh_CN',
      'spm_id': 'main.my-information.my-login.0',
      'statistics': '{"appId":1,"platform":3,"version":"6.72.0","abtest":""}',
      'tel': tel,
      'ts': '1658880357'
    };

    ///加上sign字段
    final signEntry = <String, dynamic>{
      'sign': ParamsSign.getSign(originalQuery)
    };
    originalQuery.addEntries(signEntry.entries);

    ///表单格式提交数据
    FormData data = FormData.fromMap(originalQuery);
    HYLoginRequest.sendSMSMessage(data).then((value) {
      captchaKey = jsonDecode(value)["data"]["captcha_key"];
    });
  }

  ///短信验证码登录
  void messageVerifyLogin(
      String tel, String code, String captchaKey, String cid) {
    ///获取公钥key和盐值hash
    HYLoginRequest.getPassportLogin().then((value) {
      Map<String, dynamic> originalQuery = {
        'appkey': appKey,
        'bili_local_id':
            'b7728df0958a2ea81523b27e974a2fd2202207211020261e67b331a310d1da6c',
        'build': '6720300',
        'buvid': 'XZBF5D5B82C2D9D36FA139ED863534AC258FF',
        'c_locale': 'zh_CN',
        'captcha_key': captchaKey,
        'channel': 'html5_search_baidu',
        'cid': cid,
        'code': code,
        'device': 'phone',
        'device_id':
            'b7728df0958a2ea81523b27e974a2fd2202207211020261e67b331a310d1da6c',
        'device_meta':
            'C35D369BE3FD8409C3E56EC5B9F02BA98CEC89439D32C383A1A0EA7267DE91891D3086D0004416EDF8BEABFC20116B5BCBAAB574CE5502FCCB8624D130B047C3B86206706708B5254B17C3F3C431F776A50546FBF5B8F29D457A4D8101C8D76998E3C0DAAB652AD2FBC9CFF467AED7B0BC0DB96A1854ED355FE7164A861E03F009AE9A34D0346186B16C56FA427D1D5A383A45886332CDF25AB8C95EBCF09E7551B089A2C12F1C381A0C647BB3EBE0C3BF80EB69EDB7268027C79DC348D012897DB6D7367F6FD69F66A88E894085F8F5882255C4A9643A5D1366217DADCD46EA75DAA1D9D75EA65C8AD2DC608455EDA8E7F47BCBC0A53E025AED01DD1FE6E1ED6F55C8869583DDD2115D0EDC51AF0BB56B5AE3D40B16E6D812BC184396EB3C1633B7055CC1AC2BC5A92D7BD8BC0B9BF02FCF0DF4FE145DC32DBA01B6E15975CED431CECD8AACD67CEE64443E205A115AFFAE10A8F780BAB748FDBB67B11BEA52BE3FC7F364EE1691B10F0A63A049788E6C78374C057DD6FD51E1596450A7F16DDEF14B61F66E51D5FD726420BBBD89DB849B8A0F82B7866AA43F84359BD6CA2FC4B2FE2F09634D1EF57B08154B3AA548791F5387B5720469860C6458D63D56338C9945EAE86D0CB71F0ED28BD3B190E77A86D2DA6B65777EB5D1CF5CDC83053C6A47EF161822CC4A6C95B9ACE6F8CB86631D511E29CDAD931FC8BD21C07158F26D3B7C445CFD0EAB139989E08B0EDA3F76AB3050CAB6D4873F249BB881D7330A53074CCCC9748FAB259BDB81978E0B7C1AE21ED80D61E0467BCA33AF39FF189D517362C05D1DCF351965D6AEB069A2D5289809C056DE25134782B1FFE3828B96B3A2F01B17D75AE48B7D0FD9C285DAE25803B4D5E366CE61B91A8BD01054F75EA9F7A42E0E5EA5B255429EE3029EFA1E5A875F5274FCB9E8C4D4FD2EDCCAAF13B35BB5316A0AD50BA44DE0B068FA8DEC787626FC5F1FD1490D67F1E9C6CFF579E25E1926FC7CC41F7F05442EC2E98F05158671B67EC6D12760EFDD240B56E06F0895B64F33982393CB88EF51CE4849F87CAA25B8A8DA0E44706FFE3F969A8990E94DE08C6189441C1A80204A2BE3F3829E65BFC06B4600FF6AD1C68C0A4E496E15C868DBC58F5CF0DF67794A574B557AC08BEF50CC2EC231931B66D079DFCBC4EB96B656C773345446B47C8A17EC7B1DEB94866D0EED3DE54708CFACA195AF6A7991D3399860985EFD52F4468C4F5B7CA874B3512B30588F353570DE4224D510980DB3AE444A645CEABD4FC580C5D25A230BC9D58591398A1B2B3F40627A08E46B1415612ED38EAD83370F84AF6094066E7FB242D5D06FBB78105E7CC3B60010462F89224377C24C19F44FC0070F6BB231AB4F3766EC1D72B1DF06638344BC0908C37F9FAF1B6B59C316C22A34C6EAF0EE8F9E4894C07F3F03A5A2F287EB468964E1621E51FD98DE5641E6696E8CA7FA046386B99AF60D7A70A7F9682E702B4742DD74C16BFFCA5703BD7C7EBB495B1373DD0DEA41D60AA047C782B759068CC8653C104B1665647F42F6CC48D8AB2BFE48205C42F58AE3023F5DF428FB9CF913C49D7B2E19ADD76FD7A10F381D284A612869F1560B1F384447AA982D7B329D292B538ADE024030D89A6362EFED5254B64ECD2C9FEA1EDA0879151BEB39BD8BB12F832B1EAACB657F00FEF2ECD4A45B360C8D9AE1D7C70A07E60F534E927C7AD044EBC4A26CA411F68AF7C5D0985FBABB22BC9AD2678B2ABC0058D326861FF530BA99C215383079E263D73EFA95B732A0B2763F2A6E087D18422C4E1CB210145337391CB734F4DB354B0FAA1DD6A63157CB01D64829BA78E1FAA59965B4A30F0D98E77D1D4F515D29557E3909EBE568966ABBCBE8071ADBB709943EA80A31B225916C739538DEB8F85ACFCBCEA3DAAF9D8CD1FEDC19A4289726FAC5086996173700BEE98138E4B2E473E8C735189E06013F1E44DD134C4E2AE6684B22C5DA02BCB9D9F98293B1996B86257EB36EEE989904ADB312D9C3977595355D7635B1D55D568307D4BB3375DDD50A92C4BAC28C0DDC12B0E6B4530505A79BF9CBC92E211C904193D204C8E819F260F0108513742B15E7B4241DB1490C257E6A53EEDB339688FDCED8DCAA9B09415A48FB8036C843DE038D3CB0184904C7A238598D7FA16CAF55658936EF884498E945161E9329895E2D22B1B420C02DADE7FE494DB243550F0E58D03D1DE9D1F517449CBA7DB1825DEF45B555D652C9AEF86B2980C881F406E868493C363B12F7855FDE2C60DC947926CAD7E7EC976FBE7E22387F01A4AA2ABA6265564FD5A8E05BDD770489090D9E71DDD96AB9AFBC68B9AB27E892A76C8477D12E02380405A9D4FC195C008F18884C001E5EC1AAC4A9547AA04F637AA149E6872920928DA2B8C93D5AF40BDEB82FDE3F1C30D4460C875EA7E56BD9F20A7000DC6E5C20BFD4063E892E6E6462DBBC39BB1116ABE994AB24839EAD6B0CEEBF71DA70C94665A5F2E01DFDC2C1A67CBBC1AD667212A5D96D6C4F8340052005EDC1C7A3B05893139775AE4D855A38CAC85DCF37D9F47D3180DEA77DA98343233D331B729755614D9484B0AF49C8E64F047DB977DE605DAD0869EA4B0F8B79501B1EF69DA5DBFD889074289A0E36FAEEEBB96AEA693DC75CB2F75C4EE176669B728915A703D4190CC2EDCA2DE6980F5AF413E276238E3B9F4B293422AEACA3EE42032551794A72EC4E235BF25FA0C5805D9F01940607F873EF99F0E18D8883999A4A2ECE20974EB7CE826EBCAA2A31618D2FD67B91A5F0E5DBAC769931821677BDA46E587651B10DB04811D81CD9D431CB104FBDBFA47D029097D473ACB54B9AB1EA653EAE94A59B27B7A40B98F7A3A6428A0608E7C34ABEF2BB7D72767F80175647EF66A9B4089B999BF61222D7BFDC1AB4C1AF17398C7C80981FA90A76AE3ACB52D3E8BFF553201E6C55E1CE3E7F59FAF2BF233166FDB518FF598FA92AE4199202B8511937FD5224C90D17E45051E4E861DB898DDAE86D1B7102B5A7FF38E922A5DFE593AC9080C4DC9C1A5292D476A89576DC789D6EDC47D9B77E9FCAD2CA0AD6EDC8EE0AF631110D97192B50EC0936B5CB1D7B650F611D5395F7BE3B2F39D722014A3F7BE63DDA9A0F36FC14A916225CBA92B0C74A1572E2BADD8EF760DB1D7F3620C963C8BA9B2B2EAC23D98B124AF34264AFDA67487BC262347AC7AF9A677CB113E8FE2246F6E84CB777BE411FD3632F339A772E51BF8C6FC3E38359FF1D86F76A1AADD353CEAF7BD5CFBFD4CF4E077A361C89BCBDF31E55BE51416A8C84B4A379467AEEECF2CB56957F326AEF2E0E4DDAE078312A10CFC9998436A58339BEFDF453F4988A6A5392B7AE975FDFACD7EA3705AD0E7CA9FEE770D4BE9CF5343EAB86EAC1F1C5B32804BDF23864BF856A74E4C15893F88A05690AD5F486B4ED33FBB8BAA7D2EECF725DA076DA0D1605D76303721EC40DD0555A61A03AC9CBE0DDAB362E5ED7605E13BD5D40F9426FB22F54F0090F600B5BF628588D1834BE67D25C3AD41C8A655B8D658052F35F839FEEB2F546CFE53628E8B46CC904E1F99703F058AEF948B966DC8C9C7E669553A4450721E559F0C5087CA101ABC882BE91301B025E68BE6F901E9E408A88195209DABAA0475BBFD201FF2005CCE8BE739C6F135AC79BD4E4AF17B66DCA7CD124089425162C41970311B11338DFE778841F2F6B4AFD7957B6C66A882945D6C8A4A520B63E107DAA845D98BC5720C8AAFBD3B5B8B559ACC4575354D602F4F59636A32CCCB7883A74FC33916935CFCB6A63DA7EC9472BA53897A1B0CD903C9FB27EE7482BBCF1E855BEEA6992BCD623425B454611EE7016DF1AF04AD646140AEE10712B3696AABA4CEE4969E79381DBD7CAF10CB4BFC8EBD5C3E79410DC4E29171AE5106EB08D23E3AE20394D0CEC722E5FAC26CB06E0629D015AB5A5C67F55379FCFD434557C0950A4FC2C4FC633E39A8042A0211ADBE28A6A2DF5B30822BF37766249FCDAB532D2EB5C0C22C6DA798611C4D8B612A747E22734F2EF184EF5272BF2229546995CDA768D1359540E7C06546E09F059F7B02FE3AFF600DCD63B580979B65142B09BB374D229B5892EA3E24BC139CA4CD9D4991EA31086189C1C5D6AB6838AE7A53949D7F3BCB522C3601DF6C1C905D1AB898FD7D0211451D9EEACF2AF751BB20734184954B77DB3BAE67314B9F470DF05DE135F766CFD5E93AA05ECCBC65DEAEBD6FDA411424425C3D5862EE7F88632251CEA5E0CF5EADED098481A95FFE6F14B503475B2E9F002F7115E3524BEDEB6EE90910CAE84749448BB6F7F2CF3E5532E5E278A4EA2CD75D87AC4B9EB1D2E6605CDF7DB891644B722C6C0E6422D3F457C6F18F5770EA6ECD15C851AD944CF58AF6EAC86347AE7EEC01B65018417537ABDB6DEA2E3439ABEA649C0A957248BC19D07056D03637037BD5B2AC39D04A60B00AE013C7FAB7AD14FA413BC15967C8C3247C1CEBD68CB144CF841609C5A0D4296B8985C3F39A00FB7FAEEC6574434E741252786FA6B7B32BBEC765CBA9A19BC6B7FE33A3EDCA722B34D58F4402A3F03963B8EF2941EC01E6448E5307FC2B21FA3DA14A19649ABA780F83626B49652ACEC54802DD2E6A8D30C406C5CABD7AF2557A40DA9A6979D735365920EFDA28ECD0E7E635774FAFF58379DDED0F00DC2B98D33261FD67E7DE2D19E0814EDCDBD7B2EA8194469F6B661F8375A971DCE0E77CBC2FE075FF1F819881B568B25B22DD80C67D34D89205ABB25163627F6086FC04A1B141398A91F9B0CD4DE6C39B60CF25E935F9A817B0EE1522C7738B28B121F5A65B5E213905067E94FE3393F2C11E550A436D36A12D5752A3F8BB033C660DE59114A5919E73DD3C4A03F96412CB6BAEBB1EF4524DE3E68589BCA2FD04628C9B287C89CBB2C8376E5BC58B697FF93B597AB93A06C93DCEBB1099FE920C1AFF2CB9243E40655A0AB988CD257DFAB241584A659BA5AF73474DCA77DAF75DA205512B749480C7061B65B985A3C5A95CAA118A95C7C65D48A5A2CDB18CC5EBD61752FEA5BF42D6A061C8C81AA6E15BF99C2E90AC2612CB270CD0B4B7303A36B328D7B00A7847C482DCACC90A2FBC732DA74E45E0BFB20C428729967A6CC9CA0054134E74724E9FD4692B62C0BC826DF6D0428CC9A535C379AF500B88DC7692ACDB702FEAA148F905EE450F2CDA72F06D222270EEC9C72F098B20C1B79087477F8F49FD42859D02D51C5286A8608CFDBA45DACE75F618A32C1D7AF68B50E6D77462174DEA7108E85DF1E78C3B79054842663B81C35894A9DBA005CCCF51A1CCEA6304E4AE1D5C1CA78AAA7A3621A294DD7B89AF0DC66E8F2BD0474770DFF2E112D7BD02763D2ED30F6D49AABB1F87E3E5DDAD9C0286F872C8CAAA19F8CC641DD77E02D4F78F26E35455D80AD1F3A01C415790A257BA3297E38D8A7670549F6D04A9E5E3D29152DCF7F673FB850602A61B840F09B6C1D7804747B3661BDD8821599291A9C2DB3126A2F9FD860BBE0D910F27956C2FE9103D3C2E2A7607BBD5B2A5EB6ABADE3B82FA5F0B32D4243112D0D7AB20C8C639EDEF71E911B804D8FD83B89F21CE01FF7013AC4B8E16CB5A5FD04006108F6C1EE31FD6F004ABE99A5D461D5AF9C4E20E868990421B084A88BB56981F260DBA08D8C66DDA5D805408BB0D180358CDDC4F38B9A303A3C76D8569D4398812AC7FE2A708783AEAAE0003D02B743DCD736924FD67F72624F71BD50DD8D37C04309BD548160C590501E204606B2B12058B45B98137620DDA309CA77CC92C74FC5D86DC44DADF0D63B53B79B7D1B3FC3F90E59226024B847D825E803842BC649F38238AB7AB938F5EDD39B0EC4CE65EB9EFAB1D02E9A7D195F57C4E394A6FF101F4FE43157E5F7F3FFB1C1C03DBA035785919EC51C72E0A0642020C53D61296DF35E8BCEDE9EE324CC9EA3BA01CB3517A4F30C2F8B70B47DE89965E91B78AEF779D718DFBB04D46961B3A703895FD9504F7E054EBC5E4B89BAB900B6307BA1C539D1FFD8C5C4DC63B1D49CC7BF39FD6A04C27D47792A387E3D965C13E4C89A72B959100EF41014567119A52B165474C3479DC67BD5C509B603D586859523062F6CE007B543CCBD1BD8F0420641981CACF60604ED844C9D42AF0397744B8EC025C71B4178EC40E5F1D82C189BF6B993B13749F0EDA8738DDB59933C7FDDD338C104EE74A19910D72AC2CEAB5E7677FE460B466BC8E880FA1B59966280B87F3E9D02F4E4001BEC56B30E3BD5164CB8C99F9A5FA528FAEADF736531F583A9742C83C9FA973EA28F8F74BA7A9DB2FF99BCACC10E1BD6ACDE49C1BD4B065500F55B7AAD4567BF0DD72BFC423039540D38578F612C7BF42FBBDB87A7A7118899ECE3C035344845B403343998B67A8223DA1D538BDE8148B6CD50D7E618C888D6C3AB32D5E9B03B4493A14278F437B3F0E7757105CC15BD5457AA2C28DF453219D1597217DFEAC5DE6CD44A9EF4F4507C67DA5070D8AA7CE319BE9559DCEE0783ED8510E854722E6E79E5A3BC866D0396B652191B41E164762EA2D03C8FE283DB2EAE242EEACB2148E34BCF031418BDB137182A4EFAA5970407893E7EE4D36BFF7231F0EDDA5002F9ED1F11024EACFD4A8857512F0A751540D092D95FBCDBD7CE5961B9E64C6F384800BD62C36CB00A6F42FE103EA89EC52FC8603EF91DAF0EAE14B6AD7E21C6602E83ACE524087D65EC707679758A793F9BFF6A4A798E15F1F4906109FF6D79FD3205F02192865FA87BB2F3BA9F0E3DF76DA01AD2C97D4DDFB10C3D57F1509DD5FCC2BA027B278F78AE612BA89B9A49C27F08BC812FE84FF84616FC7CD04B8DA47A367D6563940B72C2495F2CD3D5226432F2D6F7D7637B4B573A1AB3A21A4D07CFFEF41302178D72935E857AC855FC71C7B6EA2DF0CC95553A72FB80F57693AAD5ACAA7F2896008CC5AC39B24EE0483F15B4F74AF7F1BCCA7506A2C1014DB982A63ACB21AFCF7D99A3EAC4B2E7AAEB31217F4FE3010BCDF8C67C4DB786F241A39F0D4625CE10C75E307B050C977C27C374C9F35C1FE483EBF3195029A8CE1C7482F8CBBEA76A0BBCC5E4219A2CD9C597D40BAC49BF5BBE29FCCB67150199AE44919DA59EAAD04B3B5781949477BFF78A24BB0971CF82649A151B7CB1094A536D38F9B7F6BECBAFF9DE72680B346C4CD98352CEACC5047064DB096A12B9589213E9ADE941DF22348899B9E5EFAABA475BE5DA163E59CEC4843312DA491907D837BF1A7A79C708B7EA199A79087C1C83961708638F5F4EEB255215D184341D476C4AD8EA6D70D165CCE818809655625207266C44FFE0CAB4503B9469E79C08195BFB5BDAA5F5F940CF5384A52BF71703E1EF7E598BB3DE716A16E5E2603830FB7479A499E290F25BE303E60D510E050CCAE21B9A00F0116B4629DAF92F5857D0E7213F74EDE9FE4D28CBF3508E03332B619C39331DBC08835B21C51861314A6635862509B1AD92E5EB3A823177CE8078C1D523A13B835ADDDA50050859EE1E03E0E3DDE877A20837D678C4C16C14C16EA10A4F196E77EAC03D3AFA09DB097D828C6F3D74AEA4EF370AAF1C451A25F052BCE7192E50ED20C38A57BA441CBF95F77E7114D8B43BDFF6F4CCF2CB4250FE5C767626E88406560AA623326DB9A929D66CA4CA522C0CA7402D0F116D04B3D3B55A691E172921486AD9563A4AFFA9114B0F2F639D155DD862D88D7EB4AB33C1D44F9B7E4CFBDC81D4C71C08FAA516C7E73A90662D8C255293B8D54F76096CFB362C11E18AF953F80FF849BD95F4797574948D45E2585C3092C065B4683BD1AEA0CC6B329134B4B26EB7D52528FFAB92AE9B4DE9D3FDF5DC22E1A5A82BBAD07E98521CF0F4A3BC419F0841059FDDE80DFB2D26DE5513466687758E60A719A46B2CF3A2896273EDD33AC7FB424DE928E0A633C332E50FD54993C4FA3E605874F8C3729D38273268B0490CD89A0D6214ADBF81012EAD33A979C920D1E72BC84DC0A92501D853536C4FDB2EFFD1872D08E25790067FEE50F112BBAA2EB4C5D44E82EAD2DE73A470764DA2D1EE28A9A58DFF829D8DF252422230A6922100E639F5DA92ECE48B6925C14D2E82A28D5442B3077C0599A06CAC304147998D111279B1E8D496D3F601A6FF0897D366B1B0F750B8F26E0418EDDE6561ADE6FE1D43303A7AE51A97F746D054681442A5FAB06BD468CE54C82A57FA8755086CB0157186D37C0016B51B6033742F70E1DDB6DA681DECA9383982715F32572AE0875A76BAF8330FF49342A755B5CB0BE9A8A69BD500C3B076A1EB86C7BCC24E88FAEF8E71996B0C051BD2EB741F595E0B19C68D4C170D85B4DBFC4C1110D2ACD1D635D6CCD712522122F1D758E15E586C561FF498602CC20B2465E615AEC2C1F5DE05583D59E3DAD82F8789526D3FD3856408CF49A4D8A955B37D916684A56AF1F46102C6E9BD7F7F9F0CC43D3F7C19C1E690798C05A670063D37A056AA5EB352A65B2B94F2F5A3129DF6EE926810F6CB5C036DF1829FC55F5AFB3311F405088CB15A65A1EAF8983B622B4492E003E20FEC570398DBDE74590F77C4199B914AFEFFF7DD75CBD81DEA403D9A661E434BB4939C9D6A1903C15F6FC52A43CE85B2F0576842678EE0D56A4EB71C3E8A15C440E86FF14D5B411D74634DD5A7921E68AD2F760220E6F8F9B7B6F8D4A2CFD65ED58305EC632283052ED05802D421D43C0EC28152876AC74C71C6B45547158C8CFF2A99C63908CCBC1CB2266661989FDC9BB4BAE132AAA0C0A13D46EE99BF6DBEBEBA95508E0FFBB17AD72F3354C5D6C0AD51D247DC8D2A728A86D906DABC62F664186D86999B465290E38CA2D719BEDBA117F3580C97E3417C7AE6D93BDC1EDD1B757EA629FE85459A414A344646D768C655FD2C86E3B55A3DDCDC934008C66F053528ECCF054570495D0D17399DB82D3DA6BF66D2BFF3FF5CDC21C5C308F4FE4D961DBAD6E2E59ACA8172B8CA47CC02FFE25E9EC1A2527B5B5ED42A8EAD8674D2558930DC05C3351DFF6EF56BDFA7D65A2F5EE339A2B12F4BF1BB0FC5EB0709F857970B6B2E7EB5A3BFA6E1E2D0710C6E4020E30A003EAD9BD0D06797208A8BAF5410DF9A10B43B808252B394ED3232C33F9899B092E0074DD019E6ED7E82A1C5474886FCC28D2DC5115C529C8149C612731C39360317C602754F477CBBDE29961F9FF7B667E1FAB987915F994AD3DD750E0A6E2FBEB40080322949D7DDF0DA5204C3CE441B2B32C888C7E92BF33025104ACCB9883B31A7117BA7618EF489E13CC3964D50D1ADE06B90C436876AC2DAD2BA2D0EF669AE76CB1E3F9E740D6EBFD72A417DB43BB7DCB684358E02CF8055040698ED2ECE0415C0FE1F7AF2BBE2D357C640E15A6F41A892E332E31E96A4A22EF4EFD51EC9639E1AAA2CB08DC8E599C69A1E19F32C3487BD75D7936607FBB3FC6CE8778A962C17256F14D41D010EEA2B04B8541685B038E69C8658C2AE814E47612295D757AF78FD43529C13994E708250E17EC0B90B95D1897A5FEE8C44993E221760BB6F9A63B87E73C8E83E33FCC666918A3D871421375EBDDE5520BA56E1F0E16483E8E18137FFBFECDC9AFDE3522C9393D2EEE4A1AAEB987994DAAC286FEB4E4C472F0DD22C981551DBEDF91EA0572D8BCBF24713E3EFEDBDB103FB68C460A65C405B2F6F0C0C1E8DF894A8946AF19BA16FCDA637916B53734E9A650DAF856AA9B9D1F2195BAC37B3B876530E284C48073BF90AD5CA6EE9E3E5F79A88B7A5AF6735A210EFF09591A6682F456066C97814831ABFE332DE3E20F29E421098D06CEFFF8FAF69F67D9AA5CCFF10EE0E0032C56584653A5B8517D5A3F304D59DB801A383A632759B1C91E9EDC1088343A352A63D952B92EB5987033069B0D27EAC8EF50A066250F22E14B24D30E39DA83FF60D0F2D3A6D486AA72A7160926E38EF3BE8F14250A3BA1E6FC1A87EFD0DFDCC806B0A776CCE85E66D6916FB9C4505CD78F0CF406FED39CD7264DBAEBAE926B6B715C89C035977E9210CDD6CD6146AD1B8D5F30B20CFAE5BC72548F8314BB287DB74714FE992A9E4DCCA7C59A191A064930C79874220FCA0C6551EBC18A04C6AA21560B3116F661B1749657125AC55BA19A810D3B64CD3819E761E4DAFF402161D07B6FD6EFC41DD848FFD56DC4C09FD437B92AB235E7F0B89A8A0B546DC39C50B7C0CD36CD7F93C29727059EB0FD1D47ED4088559FAAA31BEFF2B59C081FAECC4260EFD8064047168FFEEA40CB37A40070C78BAC76BF248E2C83B0A02B4E8859E56D8EBB78B36F32692CD47D161F4877A94DE1F842AE936A25572C197312BB5E8A1A4DEC9F1DF4501835E35B19C097B000A93C0D588A1E0A01BA534A0C847FC6A25C34A60E19BC6D872A878DBA32512043E98CA54550E84ECF1F98F075C07D33C6BE439FC17677585A9B5B46F6454D60EEF4F44F6035C4D348D85EB0F052BB50B6A47D987D0805212615AEF93D717640109736E66BE96E1DAF1B6746944F49703784AB6356A9138549FAC5197B05FB5C4CF79860C76B5247B8C70E8AD52045E80B12392B9775CD990E9971D6830FDFF14C1FB79798622B6B4B2D234BCCBE5AE1849A6B5A985FC877B3935A051EB0832B6EDA49F633AFF83034A543C1DCB5EC4E26892DD671BFF73284C23987154EA7248138659F6EB9BE0EDDBF8842325CD17741A0E563DC32CBE5B84155DC7FE2CDE496755DF4F902453967FA2BD596586DDF6BB4ED187BDCB2EF8F545E85F66589334EC351470019D4710F6C6D47B031B5B7C0360596B6A6773D2C6529D065033BCF81498C0E1FD46356A8E99A9AB81D7954D483B9D66CC2932B68E558D7FCBD06A481F1C7B0B3C70027A525AEAA6F7BFFC2FA1AA9F2080F6605E051517A338A188F651D576426BF9851FD6DC80B9D96E79B49ADF2A0F49A23717469D3FC5653CA9FB65555287128CEF1A252F44276576811DA72A8CDF7878597626131E7E0085F65B5051D680768E013B58C83FFCC0390CFCB2A73CA38DCA5C35D4E08E812EA5198461534F2C4B3D67E2BA81EB13D8DF310638F95E7DECE440B2C130234E941EFDE50BA2AF4ED130B78121DB4551E41A4B555DD266196E8BDD106B682435CB46E551BDEAAFBB2FA3E7CDE43DE8FC2B854548E46E29973FB0C780C8D6B54DA62370920E3973A5823E7A4D76BA7F2497B9A4751A7418653A472AC43D6F5812816A52A4629F763010ED1DEECBE3E9FF148455CF7BC39128EEB10C723D6DAD4255DD86BD5FB77A82B29E5DDC88F45CACE7C730703286856B6083CE01197246B87FF393F182FF4FE50F4615EF1F91CB877B6BAB71BF72856E6BE19F05E90CA0FBD9E6700C24EC5AB8C89222DDA2EDC3EE9BFF449239AC01E963D50AAED83EFA841DEB8BD2AAE15B74EF6F8F4F94DDE40D8E3B61226C37962870FD1836EC2CF9FA6B1ABE01DCF0CE6B3532236985421FAFE317609D7EBDEB163444FA848A36BE23CCF58580D9FCB317DC6D4193317339CD51771917E385C31D33AB01CC0522BC356237A8850DDF52E7F5E6D080D07694D6EE4E2706687174C4DFC3FD188B3E088D1D45E27DEFD1E164106D5B960A764E944B8577E57B5526D152610C796D4A2F7AB77E3843326C408DE3B318F4869518DA0E350493BE91712F71E6712786B27E6ED7CECD8258C9B02C4F6437235AECC880A05390379E84BE71137C6D259C22B30E4CED766AA9917066B08443CCDC4E57053862E830842453D580B3F9BF618C0F55911BDF7DD67493815590734D882B771F924E77A8F322CBD7754C994F27BD83686DF60E56588FD0811E6FF632FB3E82CBFDF8C38902746723DC961FF290B79AC4CD1C20A1924C6CF524A83A0A20BAE20598B46BBFCC9B7CE47668C33AC97C34C4C1F0787506FB46F0DE02480EE22F9054C27703C5654128305618810CFD15010A7C22FE9679547C7523F254F1AA9A11E2FDE8AF2FE1199C0BC74D338F4AB0DAD8733DCCCA8237A924C80A6BBEA96BA793A1F4CB7D4C9E3AEF683859A96BA4EB67B5416F3D0C6C725A8F3A490AA63508AA6863CA07516EAEFA693A5F1AB23B4C1ED955181E4220CE4537BFD0EB7EA1E3D5D6988F6BA82462D0F7217DB55B859598AEA7450C0C0EB79E34C38727EC5C84B3EB0ED6165B4194361A7FB7133329B6507A4B297B560134690D6F383CAFAA073E7342DE4A1D367A938B172B1C79EBDC9BD64A44CF4BF698073B58C69254C9568D46F89431925905E92DB2EEBBCDE07F57D034',
        'device_name': 'NeteaseMuMu',
        'device_platform': 'Android6.0.1NeteaseMuMu',
        'device_tourist_id': '20096420566197',
        'disable_rcmd': '0',
        'dt':
            'ZRugblkbHqzfOXfy4vE/BYgHUZkBTziyqq7r/HWFDG4kVQU+d+0EOqjEkoBdRtZO1ZvCV6L+0XVP3I3OQBzXKDlgmX1vJ16cDhginaA9+/bSHY2J+N2aZXcvZTFgQyiuJz2IfkbCPUIGhY9q0wMGRWSB7VZRTwsQPnXJOxUoz8M=',
        'from_pv': 'main.my-information.my-login.0.click',
        'from_url': 'bilibili://user_center/mine',
        'local_id': 'XZBF5D5B82C2D9D36FA139ED863534AC258FF',
        'login_session_id': 'ee4ede33ed3575d536ca23b605542b55',
        'mobi_app': 'android',
        'platform': 'android',
        's_locale': 'zh_CN',
        'spm_id': 'main.my-information.my-login.0',
        'statistics': '{"appId":1,"platform":3,"version":"6.72.0","abtest":""}',
        'tel': tel,
        'ts': '1658974686'
      };

      ///加上sign字段
      final signEntry = <String, dynamic>{
        'sign': ParamsSign.getSign(originalQuery)
      };
      originalQuery.addEntries(signEntry.entries);

      ///表单格式提交数据
      FormData data = FormData.fromMap(originalQuery);

      ///短信验证码登录
      HYLoginRequest.messageCodeLogin(data).then((value) {
        int _code = jsonDecode(value)["code"];
        if (_code == 0) {
          ///保存重要数据到本地
          int mid = jsonDecode(value)["data"]["token_info"]["mid"];
          String accessToken =
              jsonDecode(value)["data"]["token_info"]["access_token"];
          String refreshToken =
              jsonDecode(value)["data"]["token_info"]["refresh_token"];
          SharedPreferenceUtil.setBool(BilibiliSharedPreference.isLogin, true);
          SharedPreferenceUtil.setInt(BilibiliSharedPreference.mid, mid);
          SharedPreferenceUtil.setString(
              BilibiliSharedPreference.accessToken, accessToken);
          SharedPreferenceUtil.setString(
              BilibiliSharedPreference.refreshToken, refreshToken);

          ///获取用户基本数据(用户的头像、粉丝....)
          Map<String, dynamic> params = {
            'access_key': accessToken,
            'appkey': appKey,
            'bili_link_new': '1',
            'build': '6720300',
            'c_locale': 'zh_CN',
            'channel': 'html5_search_baidu',
            'disable_rcmd': '0',
            'mobi_app': 'android',
            'platform': 'android',
            's_locale': 'zh_CN',
            'statistics':
                '%7B%22appId%22%3A1%2C%22platform%22%3A3%2C%22version%22%3A%226.72.0%22%2C%22abtest%22%3A%22%22%7D',
            'ts': '1658974686',
          };

          ///加上sign字段
          final signEntry = <String, dynamic>{
            'sign': ParamsSign.getSign(params)
          };
          params.addEntries(signEntry.entries);

          HYLoginRequest.getAccountMineData(params).then((value) {
            ///将数据发往主页
            accountMineEventBus.fire(value);
            Navigator.of(context).pop();
          });
        } else {
          String message = jsonDecode(value)["message"];
          SmartDialog.showToast(message);
        }
      });
    });
  }
}
// ///账号密码登录（目前还是会跳转到短信验证）
// void userNameAndPasswordLogin(String userName, String password) {
//   var appkey = '1d8b6e7d45233436';
//   var appsec = '560c52ccd288fed045859ed18bffd973';
//   HYLoginRequest.getPassportLogin().then((value) {
//     HYEncrypt.encryption(
//         value.hashKeyData.hash + password, value.hashKeyData.key)
//         .then((rsaPassword) {
//       Map<String, dynamic> originalQuery = {
//         'appkey': appkey,
//         'bili_local_id':
//         'b7728df0958a2ea81523b27e974a2fd2202207211020261e67b331a310d1da6c',
//         'build': '6720300',
//         'buvid': 'XZBF5D5B82C2D9D36FA139ED863534AC258FF',
//         'c_locale': 'zh_CN',
//         'channel': 'html5_search_baidu',
//         'device': 'phone',
//         'device_id':
//         'b7728df0958a2ea81523b27e974a2fd2202207211020261e67b331a310d1da6c',
//         'device_meta':
//         '9D1042B0B5B2076C26EB699BD67B2770BEEB5EC13057957D68126ADDC6AA6CE4A1D01BD9E5654B4BECD2949E1CE6207ECFE1AD8AD330AD7045751FC81088154D63EECEC2CC9A2A641EA1C3DF6DA77380628106A33262DA60EF980D0318DC2170AE5CB4F8BBB7F7D0CAF3570ECAD72138FB766EBBBD487577A166223E764AE44485DCC313E86472F8A703CD121BAAE167ED05DFBBC17D9D23A40E1D22FF0EB55FCAC1AEABC12278039A9ADCC869F5F20BB04FDC7BA12BCFC2EE030B25A58391520E2F2BF8C0E54A6E38808F65E35763A6E44FEFB498AFD0C32141943F6906F6A523F747D6FD42618342809098516D4C471032729DD12B68C32F08F61DF042EFA237BB72C0ECF5652376F49F642230684735C2F061C4D177979FE547FF6612576CACEDCC26105090F791EF98388A466FDB7E2073BC85EBB465C4F59CCD9140B19A3A70954DF163B68F2FED96B21C0F3D4AC7EF8556B3FDDA3D87BA3D2B7C937EDBF82FC983A7392EB7069B2E6F847723A16A8259BEF81936E63767EE92138B2D1FF6DCC1AE33378D441F305700D786599F9C8C303123F27E7F09B6BDB5DC2F415282A8BC571E082B215EE1514C6B3E214FAC93EF917794D844BDE8C84D2DC5269E97DD3238A50D748B5F0A99BBD7FDAFA84623DBB57244D4A450CFCB91DDB4C6AE7157C338838CB2B31AB564E012061B0F0B7CAC70B068B6986F24E53E620E892C9967FA56B3F84D644559F6AC5B836DD8391C3ECFA84BF42B8F8EF30FCF7E0580C5E26B5DCF77496958D16B32D9984FF2EEA7237B264FA96466D2F9A3760F7CAD78D13006B0206B88CA204DB1428CC0558A9CC854B50345C4A2E39A0FC72514498B43DC3BA55C7743D9DE77466A31B16B844446691CDDF3FDFAECBB730DE0093AED438733DC43279271FC5BDD9B3B065048A09268582408C2EAC28258A8D5A57BAB1096968A7A3C90CF6A7D076C48597DE03287B31E1BDD587771FEF5F6FB149AAB525DE77DC7D7A45A41CC851B9F917D357F6772EB58521FE3EFCFF287AFCF8D3BF4ACC89EA7ED0B9CB73CB9031131C11F65B82222FA0F040F289FA7F971ED2D2AB676DFE8116D4B203A0D2F29BD69C0447EF5CF31A5F5A512348EBD13F7BC1AEE1397A87E4BC35FBC904B6FABC907DB2F9F4E4A0EBA88C89DEC6F665BEBBAC3862B1C78E029C1F3919ED80B92E3C02416661ADD180F3739299C8BEB2107CE0460A615C20FBBE84B98D13164BA155BCC60A38FC83615158AF6A82E0469C05E06D5D4BC8918D82E8CBA26E58A926C274929A8C4EF4DF5364F4F3D363EC77E832AE88DAED5E0FA031221C59121704BCC45C4844FBDB721786A21835A111BFF2CEFB3C645AE75C6558E9EC8F88176E505A42947AF7891B775F0D7AECE55EF87FDEFEA0AB702B5A49A5937A2BD0770F2D743CC500BC3BED2826F0883E509D0FA0CAFB0FB1C3E5AE148B9CEE138D955DE084E2910FD04D9D260A5CEE39113F8D1B4381A8DC47B56E963F3380EB6F566D23940CA3583BD76C66A284B9157DA888543B54028EFAB99BA2A8C0374D03759D74BE7C3EE62659E0420320BFB9D6F17FA8985871557C2CBBEA37E7D49A88D2E89736BB8B62E68A8DC9532C5213479BDDBBF9259BE3C3E8644AF43F74016D4AA14720F2C4FED88196793338748BE669C99D0613BD2B1A7B7A09A139FCDBD84204310D364E5C5AC799AB71F72ED6084FF169F19077CA6956923FDD7C95800D0F8F950F13078B3187F5C1F2F04174A512035CF1923289ECADAC785D7071675997025DAA29D70760CD0722D538A0DF3D168238FC3D626AA4664B20FDEB4F649397755368EC6AF13524E23F4C3587069582247208D0344D68161EA405C7A26FE62E6A1CBBB3A7AF59D562DC5B21174F0D867002831400E79C3B3CAC3C1324E47E26AD25A38076D59345D524A9306E7A66A447A4EA02E693403E853374DAA1E83D1A070E075A03ABC79AE750EBFF91FBB514786AD893F73A34AB8C33A81F86E8DF03A4F461F2AFCB33FA5CFD0ECC669C3A22B860FAC4024C3212D0AA787B1847CC832D3D4080B9B79361533CF92918B601AF958E7F73E4129B6845C620FF5E26E07E6155F44E422AEB6CCE63E5181626C99F8C525BC83493BC0EDBD26D7E0EBC89B31629A6B865A3CD16B370F23657169C49EBF9F6595F2E932B55658A84D6A46BA8FCB28605AD8793B96F58D11DE9D7CB7B78E70FC7A0B7A7FD283E8267419C7A478021FEA7A05AF628C8BBD0A89078127142F2B9AFB6173D978F0BED6BCF1E2692F3C4E848AC41C585FA15970B4DB270CA971BE79D7D72F69EF3914AB1DDF8017CF9352FB707B6771680C07798088B1D35B782E9E9A3489614C5CAF410602D203BABC1B958DBA7DE45715836769942D5E9B6D621A889585E707AD76F289A691BE6C71679DCCD2DF0CC3A3838A2EF13E4CFCBA1308FFAF5A99152310DC87F93B985C7C7A3971E8EF1FFF2E624F0F6A38F9E6201672E000FFD9061F3161F123955C1EAF5F20F6A65DFDBB7EE6F0BBB55C2130D3A669C203405C0DF3A2C85A3CFA2AF3CA4489200BCACE8889AFB4C11420DDE46029AC5C9EB02469B3ECBDC19E5C7A87EC54D3F9B4D049246F526D1D0172786278D0FD5BBE4336525DDB27001B1A0A39866B4F4EEFCE48EFDAA131AB8049E5835384EB27A5C7725619A50EF05FD2028719F931A0D13CA63515159C2A58A73013BBE87057D913AD0DCB90E4EF28E9ACABE60DEC8DB64CA6D59E5E96E41C536C9C035E02DC4E1BA313EF357FD2F919AA05373295D2823E7D573681ECB7A1D57F86CD1AD016A380C13DE5E5B80594FD37AA1AC0994103B0266786E343B05DA5FC50FF7FC54FCA31AB87E049ED06889A484956BAC402376EE6925EF20C0EDEDF28E0CFFA56411FF9B5D313467E3235E8289885E52741FE641BFB0EEED63008F448E752E1F3A1C41E98CCB6CB22C45D81C6B16B3D0432CB6C72F808D5D9E22D56D6FEFE092D103122F804F90EE4C3BE28D53849128D203A8DD4B53AC319F37F03DCB84AB74F56A141314A6E826ACB35E2A34FED4A63AD37ACEE8E29BA6E7CB57F9110E958DB95CC594B01E39222957CCD34FAFB12AAC49B5E5290440E8A3C734B88B4E643A655EF5959D4D1559223376B7A45686DC86021AC94A6FB17EF0D102838C1E52C94C5F5AB3A92C9DF31948F574FC0968E5F371146DB641A6A4B254B51EA74C493931DF109D425B460A3784890AC35312C84D66F5C10FAEE9E70A4436BE81CF14B37A15C994E8B47FC835D0E6D4A0BADB7171F7E58BB719FE4999DFA7EAE9D04065B6ED24EA4F86535B6C1028A0E5A8FF12E187A4B3B5A7D6B3D68CA130F552DF1F46A3EDC561E073460EFC73C19BDF7D4520EF46C1C1831A77E70CEEE9489FD468A29FFD8F7B386DC40B6D188F8B80B7F03E97A91AF182287C9A88E27060C588DF2976F3A15340D53C9F82638D56258B88CF17B8D49A8100E5554D84FDD4FE233989D9829522F889A62EECE643E371A2A2D28BE43A77044D2B133677394DBFDD23342D0543E52667BD2D4A798C93724AE435CB58E67018CA12B0659144F67AC51AB241A20C1B069087D2D2EF38477B6601598151250862CF5C90A3C0B44E5A436E522862D13F5EFF1C574D4DECF16B453AA496925B7DCDC63D2574C6B1DCF96604CCAF41CCF2CEAA381EE6211BA2D460958D5146C903AE9654E622666DE7FE14E7485A73B29A874CB458D745D2461346D54FA50241B57657801E916EDD7E39A888860A13F45F8B8F21AB85F5776BAD18B447B4BABC3FBEFA3EAE7C7859602D408934A197AD969E46E7F4F15F25901C4F63917197D59DF6DCDFB0644F337BF8D44E4CB2CB081D7E2EAE8D72D6025CB8C1702EB17A31C32F05774E1E731675ADA4816DE4740C98E6F17BF371317C3CC0A48DC8AD16F0F8A8E641B0237C8BDB7592033B65AD7FA15C098026FE72EBD140FC2B2B86A1F5AD1AA7D8B7C80C7CDF6AD1F8DD4A5BB944581277F55710B1D06FBAC2D5A6AD761B59101EB1DC516E4FFF05FC5D48E718BBE53531138ACBCDA4F5601BAF6D6F001487BDF2D2054C9763DFC55FA39CEDD545F13C6B0FEFA23F54A08E0784A482F1FBD6BC353EC83837ADF88EF83ABF8E7FD571866BE717292EE9C2D04A72DAA8F218470C084FD2B6554FC729F926D7650D647DD1CAB367A99A587BD70091573CF6705F380944DF482D2B45C22EBB565DF4C24B50B46328ACE589BCE4FC0DD1F81511FFB375CB5F3A0EE270E73E2FEA5FAC68BEDF4F991F73B7F3C9E2C7AB77F2DCD116686B22FFCEBB56E6413DE93107DC28D8D7361707AC7BEDE604E85D52CEF6A29FD632B40F8112B9ECD4342D9DAC2F371814E73DCD64CAC6490967097B374550ABD0D292EA49E112EA51B86AF898C6E95A80367897A1EF61E7CE2298682CDA410545ED29C4B0A63526B865D857296148884ED2ED284B4730379280656BED459412EE331D40FE67893D238145AAF38E16EF1A0C74DEB3469C1B2F6629F504569F5D37C3CB6DE544EF9CD5B67E3F48653DAFA48D126DD682C67C7A0C7275B859FE8E76E0FB10FE1518F76DF02C414E51E6399E1754B343366AE5D38A576E578D7F4DAF263030E112E49B49B5522B631198A69BC3FE1E4CFA12882D3599546C3251917BC16828EB946B1D78C9822CDD563A4E79D27B11855BEB5723F71C708406E293C1CBBD062C392DCA75F197273127203C274D0AAB410261CD40B02497DF855C5DBE03D9BFBABBC1F067F2CE2296993B65BA6AC3C89F5F37D6B6EEE3172EB523EB790231B1806DFF09B0FD46ECC0FC87982A6AFCA289A3816903C2C3A27441601E2C2D1B2D0C5187B3D06CBB15838972F3AD901479889903AA4FC43629A9355AE731CA4BFFA2DC1659B2B99A50DAC96F1CF67AD8F4E952922B9418C2DB9C244F39E9A115501A9A86F67FED23AB40CCD6FBB7CEAC21FF05C04EF18876E241FE6F9B14E1FA25FED1ED3DAFA0099184E55072D1946C6F1893922A36513A61CBC39863616FEFADA8E593A7960A143077191A17C777A77FBE68B648A1E50BE1D39856E6C17A8DD5B7CD4C3B4AA85046A95288720DBB5B1BE067221421B933C3BCD1DA765C47FEC37350238FEE1F9955840D177D007B7BA8FC8AC30BA10371F79B8F0B052D994DF10F8FC810845B3BE37CF5BA96D197D816976D6DB70491E1F3492049B1CB4F64D937ECD0D7B391536572F68138D08AF227DD83275AB42F8D31CCC3924C1B9D4E705EDF25A651C6EA05984D6F5A05ED37B7A1483309448AE5F65844B4EBC801B8643282F0C03976E4E2862BA13C84C7ABF8E1A08EA9DD81A79547E5EA6BEDD35841544DFF6C1AEE8952B349DD671D4DE3F094569ADB471BB28F455C97E6B1281DFD1CD6F66CF8DAF9E6634C03ABECD190A51239351346231FE50E1BBB55FCCFCCFD1213CB6A4CEE7910D2B80C05708F87AF19AC8426874355B4273103E28E5D6482FC20788E20500D9C3D32EB18D843142F7F16D1492F2E5F8CA68B904FAE0AA30F57DF4B67AFD457F3A1E8E4C54ED3D2F97C68F0AFCD1DD6B06849B22CBB126CDC5C4694D05CDEA2BB2B5C8AF733476F325CBD8B5F55035AB530913D9EEF381F162952778DAEB665C6511542219EC5FABA8A5ACCCEF8D5856DC577350735B81E971ACBA8A7CEBFA415B990DBCF229598A603BAC20FFC1799FCD8C9200CB7D604E860518D00E9744C225647EDE9B03CBB2910DDC0509510B52DF5DAC4599824ED4AEFB94673827AAD9885B0320F8929C3F39E51245DC7E4957F6A20A557205DF42960E4F9854C5EF459C20570A67E8DFEFAC40A8600BB7E0B43BDA5595EB664C40AA850B26265BE1C3402151100812673E6C9DCD033351F774ACC46D3771461C860B8778AB2AD10E73E6ECD09A417D1CC796B53D20BA9D207363F8793D352015AF5C62216CD97BEFDA4477EC29D7C1E3A0583A3DE7FB01BA9530C8AA2DFD532EC32D8C456140D71A5E7495107922440C92FD8C339B12DE1CCD650F44AAF7F6902281232E31E4903EDD0EF2BFDED682C86ED55B1489C935423B63D5357D231EDB4BB71C2A10EE6BD2CA6337FF5CB424954E7A172A832B6452CBDE78AEB2CD27F204A40B7C158441F32FB7393FA3ADE0710974D36E59C200BD7193065C1B934FB9CAECDC5FDD1BFE6F9454BFED8BDBD6EB55BA5E0B08F0E2269595133D9C49C2756B1CB3B6B9CE2AF8A8F039C679B7A842329A4893A3E827D34E7207E2BED5A33EF6A23C86F56DD024180E22BB34B922BB23ED15FC9B61C2E491A91EC7A49A8661C0111455E183BD31CD8C4E413E2BAB567A85617301FE71CAC2807F2E0E50835EEB833416FE3346246E97A01885FA36B61863173E068784D024147A96A0E2BCD468F729BB7FC9185C3592BE00D5582C6E474EFE73BCA473176E9CBF5FD755BFA9C0D7FD5B3927A2643969D9FF7EC796D3A205887B043A6673D551D05A6B1CEF8BD34C60DB17E4E1CB9D0A1DC5E9BC519D060B304F4A9DAFBA334AAE3B18FA0265A9EA4D9AC42FF7C558D9B8301B3858BB97A24FAA22CB5F5C308DADCB5C256A431E01445AE3CAEE4720B77671838B9C69088BA73EDE6F92EC301A29A18C04FA4A4632CCD8B37CAC21322379F8B352105C42D7F000315DCE9DF7C236F6AE8D001553CD5B42F3E9ADC893DD503B589333C1B1B95346BCDD9A60349E6EFC85AAA9041455150C7631DFC9E2FA2E229B5BE0B6A7028C32D9E34B1A2D84D77DB88FF4F8458DEE0DAA9758CC1BE1A7A219F63FF38F6291ED8585EB0594DF3E57CF01C2A153EB9C7BEDDD29E8C0284532817265348B6B7713DFE95EA2D9BB0B1C2658AC3B2A99A9A856523490A8EEF4E01E07FB51FAB5B70007F345DDFB28760BBCEE6072740F4670DF030C10C339447B94FD15201F291A2BD636F33E5F13D5FB55B211A0AB5426E97355D5D1FB17DD7000C92E83BF3C2D633C5B60B1F3CE78E4D09FF2AC9794355BE2171E289B0E94E47DC08A5231B7E748EB2C781AE8B96FA834444DD4B1C3E3A989D7AADE3829CA8693D7E23396FC567C28781FD20A4F657133C96E2953EE6CBF9F1A716D9E42DC53717F2D32763332D60DC56080085684BD411A5C788AD9F56393B96E38B5A502A8DD99A83F9AA272EC6AC6697315330E849D01AA734262AA4693283A2FA06CFC564A63D138774ED0B5E1BF873485BFC1CD7C132103031118D7B3623431446199DBEB7BC9B7B3829DB9662E47FD6E10F7A89BCDE6512DA45D0DDDBA05012C182CC5A53637C9050F56F91CE0530885DAD308D98F7AE70CB98DFE4008ECB7925FEA5F5CED8D511FC736D4EA1606836E0480E31F73F1380C47172B81782318F51786C5F80D17F86041D5A4709E96136E1E3489EF421B5446C4D2729370E5D45D630C9473157F09543D6E68272E49D81C84BCC690CA7114435B4AC1C786F16B19BE793E95A6B8D86B9463431448AA51560659B13EDB8B6F7B4F4213654379EEF94675CD6193DA96394C45E301D147867638641E82B68A790ACE349B868EEF215733FE610E1E2FA0554E22748BC9A09D26DE28AF114471F56DA21C090C3C8E8804725A1637FA3BBEAEC52B88AC35B4BBA068B8F33969F035440696103414D37B94FC3B016DD1E5724EC0335692BAB778CE3EF188E04173305056632C2EE33901696587057ABA5DF95BD6C8A0412BEA4BD96A04430D10DFBB874AF38B28284D2C9A6EB5FBD980C107A510E8365DF843992F2E379E9005B205EFDF45F4A3B17B25640D1E1DEEB601B09A2C2604BB2C2F6517C9DEC0749F0D680C8C71BC969A3FC239621463BC4806F40F32C465546E6A71C7E4BB1CF4D704848C5796804D75D779BC11F2A84CF0F88D94BDEADC394664A6DDA6EEFEA6A21F40003A64094260B9FF704BAAF61459E0DE24649C57D828F24E3015B6940DC161AF7586FAA93C8EF2D64CCEC9107002308E5E599660C1E3E86AD9562EC885FE1AA5B7ED14B8F578381DB28CE1466237A09BB7FE60913E0EF4CF1FA15FD9978842F48829DA671EA8AC01FDFBDD57D19BFFB1FE5DDA7E9D8AE9AC7BE24C22623E67DB3EF71991880D72D6CDBDD17B63FFA489CC5AA2750B31432DFBC8EF402E349F11A72A5A379AF716BAB7507907D9A7E25527C23A9E54EC153CC223497F7C884EDE74C027DC1486EE211502F222CD24C3710214F1EB867837F1A09FD0D7A2D929927D296331B38E17E4F13CF73C753E7E8C53724B896148AA8B2A9E936DA386956BF7156B33785C5B2051D4F4DDA629D2BF9EE75608B43B894D58BD513D85341F5537F3688DCFB049DC5AE09A03195B3F875FC9E225DE1BAEE206B55E4EF797E1E57A1D5041DF44125B81D6B083A5897809F20BFF398D7DEB0E7CE16F3C4938C29110F302367A3F42EA8A3720DC22E6ACECD0B6020E3334BD97B19D4F4C09179A9E92449B7626FF3EB185CD0BFF83D7E28027C8D9AD5245F6678801AE9E5BEB60FFF02308EAB1812597B2419F722138FA54FB6CAD105335D447581BC99533E4F2149D00F312018617AA37FDA5FCD942190D07E6A596C1800C19AC6569558B7488FFAFA08365D384DA6ECE3272A18A89ACA72E60699ABD09342DAAF3081A8C96181852285B29C986FC966DC1D10D32C3BABB83417D8CC6FF23888A0C377C3E401181AF1A1C51597AA74597881FB779F922E1844346F05FA4AF498D94DDE7ADE92057DB2B93463543F7DDD58C57FA8333345285286B0CF1196FF7C3839AF37D855BDAE836B5C68A4C82387DADA9498CA64E0CAFDDC37F94319F75075051E251FBF676E320771A2AF925B10BF97F81716BA3E8E11656B9CD280A8A9D7144C520BDB082D69079282B8A013AAF2FB43EBF265544F51201B842509B2DDCE827529195C81D5B2646E782257AE261D8E7A1BFF0EC856CD572BB752EF9252D3A10A29AABD7DD2C3EC8A96754621385698956A592994B35199508A75E7E35084012644D6B386A2D4DD6A60981AE7DA167E1D3ACBD48B6416C04C8235CAE89C079E7C7DEB0D45CFAE6035617CB3140BC7D48A37276784579134FEEFD2E84667A26B99F636615C820D51DC2E8CF36544832EA8F0D5527B7A950137D6F05B1DAF30A9EFAF05D5974EEDD7177A4BF82552A67A30009B7D25EFAC7A2E696147F80F73A11710B7FF02D8996E21AE8D5226DC418B30BE7BA55ECCA755B484BF8C474401ACA973A0D7B3E5DD6045A79164BD248F561DE486781272B35D785769D54ED469C0C241A0B2B74A28FA62CD70C583AC9A166F7C43CFFAF245997256121B4DCD8107FB79FFC8EAA3B3A5BD53D44CF7AA79A9F2601D2A978A5E392765503C63BEC949345C7E3CB76B1FA7C31E10C58463CB9C9E428B70B18327173955F53631DC442B6ABC7AA56A3BA217A84328E243375D3486E1DBB6CC0D7A96ED863D749F623604E05F185F80941676E74273D745CB977BBF1F515E2A6105A2937A6559F7A80D37BD5FC36FA0A18595AEF24294EACDA140B236F8CBFBC0C085B6C2CA398B32A9551E62910F968C7F7A11877BF888B6183BBB8067CAB57F36863C576023390A43E96EC45096E3DE48CD5F6EDF461B17FBC169EA74D64F189715C18262EBD58AC2F98AEA0AFB3AF60C190F664F32D4F6D41D1D16E139B326A8F0307E5AE003FEF9DA30F0FBFD078A269D0F044B0C8DBA2DED4D620E3A1502CCB8C54EF27C5DBFF461B287EB6FE26C37609C5C08F02F0B212F9A227B81F541E83B7441F6B4EADCF4B3D0DCBF9C5D07354B4A6DA905A3B7A8CA5ED668CB166FCB041025F163D52783A3CCAA083D1B20014CC869D73C3185E701E3AE5D9D5D1A1313232EE5AAF0158EF6C1EB5D7600D8C130BFCAACC292EAAAD43E560AE080661AFB3031CFB5FF83F4EEE6DE4F361DE13EF958CB8E5E409E92FDCC2FB39C01770991F7DADBF563AC9C3B0D52AF9FA18E1E22E92DA5881140DFEB68E614920098E283170000E5F3AAA90D361A6D9CA9DF7F959260A120F15F83BAE5054AED39F9BC0B9E60FE334ABF57A56BB6769CF6EB10E0F56B44FA327B6F90C9AECCF9FE6F07E19A3838F391126D949965BC842718788CE0D6980F707421AC14D97864F75F3281CEFF9A807A95BFF18491E577545D86999133BF518A03E2BC6FFA746047FB7FA3314EDEB6D76DD4A1F172BA246A3E5265510BE6F70314FD4958C2F6939DF954624AA8030BEEA15823D3DF44373D5B7A61905FC2FA03115360604C9C5945C619A561E9BAEDFD262C4365D9EFB8A05C1B10BE6B9661F46A71FFE68EE2BA27376B41E9247DB1D5CA192DE41F079354CA64B17274F15BB544AE9533308E469AF3B415D696124262EE93AC8D3049E9301EB63A0DD43320FAB051E217E387B8F5058BF0BD7DFFB34CAC5C986A6028A1AF09FFED1E172F31D45A446B139F26B3A3D67C24E3C96503887161AC42BEE67CD1818952E07C614A0F9575DCE7B4BD8A990E3B302F38AE3910020459FA1962DB8761312C35E9CB66E47E7A79EEEB7359445915742CA6F0B20278C078B7E944ADC95BB0B380944FE82BC3EFBCDA8C2D47B463179E0AB1F8A5563D95757BEA4198E7F287E34E91696B46396A6259794AA3FA11CD9239BEAB73D8E63DC8C9F1E55909BEBD12E5AEB91EF1ACF1270D3C1F617D888DBDF7A4027083B8A83E63AE8F87749D83A02CF20EE65131346FAB05E012799C2ECFBABB8444351E38D80F91187AA067847CB63992160793B3985C7B6B023A16A733886E4E58D78DFB719FF4B5DED8B8E635803EAF473C21E8BADC4D811AC76790AFDDD0C1BAFFE949A725323B1B3DB2D6DB0CD40099E1C92E18DAECFB61BA948B8104E3A65C635ABA96F9C2451A9AE915258D1ED76FB4042975FAA822BC6BD97FB5CDC8079E28219C610F1144D3A947C6BBD432B30E730B0FDE2C93A72BECA56B1CC1EFC63E12D20C50E9619A33AED1B85BBBD33E6C9353DF3126B22B798B663D7CC1523AB14E1B37D3AF5A0F6FFE27980B329A873142374097945E41709E8F2D900ACD42B56039C63AF8976C2BF74A9466F899DF39F4B08BE2D1E3A693161738F6F9B774CF1717F7DF3E67ADBAB2E567886B745FF077EBBD09CEA84B4F7A6FB69A4DCEFFC333017B37F33233D5729D8D7D079E1E05CE5ECD725A1CB4377F0BCDF04EE2521CE85C71DD2BD2A4036DAD3C9773993845F1B5DA5EE2B100FF459C82A9FB5358CFB2963CE5E708F3E38FF548AA30B858D4D751BE03911435621EC1EB7D61BAFFF60D702306657F482F10F11245A10C5592C99D15B3866AB885BE39F9D3F6609921F14019CA9C280B5C8C084B83A5D8A4845DD75BCB630E1B17C0CD5B134D5341E2F527D6F335631DB3DA03C0EA10C3B6F66A7A4B6F67645B486678D8794227B02736A2C4BD2DF1DF57CE2CB01685E35F770FD2FA2781A4B488118CCC4AF9D21C813662E6042F5D03A31B3E9694EA04F161047A843176876503D9EF33787BCFA58B329E94588DB952779C253898E7942A3929637FE6628C222A2F5C08A259F0405E900CF14000E6258B1961B832870DDF2D2503E0E1961888ECDA5F963B5A61D526570D952E0249A818D5EF9B09722480FF15FF60DC3C1E78C0361E9833230B9245D7ED1C04B1210EBB162998293BDA5D39989591BE6B9031E85CB74B6E602C682F8EBB5FC8F30DC84C9B4C4CFC4DAA03EB1D0D4871EAA7E64AC0F5DA901B11DBE3E0B9928AB21DFD1F54DC9DA505FFA4444C7C5BEE6178D571D93761A7F8727C9F0D162FBD141F4846E2F56D23A30BB9E12FB03F13EEFD42012FEF328F099A2E413BF1A984913803809508645BA5217E2C63DEFC1AFF1141D6794F137904D9AC48D5B4E46BA852EAF4687EDC813C44DFF869A6EB6DE908269218CC92CDB0CA8A700546B589DF4691A942B2DD3231A1FB3D11F202F06F4F054771BC043FF1EE1E0D99C65389C9482232F87F4D63AEBC4310F04F3AFCB16B44A3DF2281445F94C114BD3B585BF233714CD7643C5B7098D42769544DBB328A7E7F421181B4A2E354E30BA7503DB2786F69EC6F067A2F987417C24D8CDB530BB5CA4E56CAE11238E3F244D55A6CF894AC39E52BCC3B32D4911A18026C28F1B76108A69925233A4104011AFB63EC2BC5687ECA75BB9DB0ED8971FA8AF13594396037179C8D048D6E66468942B69E317E5D3EF0C43C842E0B19122A17EEB25B76D2444BB34C8ABFD9C531776B21174CD7AC136CB882ADF40B0337F772CBEEBB09E0C647278ED21770AB26B18E6D276E057D9D251A5398FCAFA3CD93DD861DDD072F6BD9FA134C5C0F4650880',
//         'device_name': 'NeteaseMuMu',
//         'device_platform': 'Android6.0.1NeteaseMuMu',
//         'device_tourist_id': '20096420566197',
//         'disable_rcmd': '0',
//         'dt':
//         'mV2Z/6SLYv10MZBYowD/J/j+JQ4IE2T7zaiLrnxxpyj1LQJ8yJ2GguZwqHIlGo/u2LfhLb84ye3/\n0ylX0hixiOaVIfaaI8MTLZrQIxSi1q17cq/kpIXVT3MDyLxJzcJUdsA15Qw7sp0MSwLL09cQXclG\ncxYIyARMKH6MfD6M7Qg=\n',
//         'from_pv': 'main.homepage.avatar-nologin.all.click',
//         'from_url': 'bilibili://pegasus/promo',
//         'local_id': 'XZBF5D5B82C2D9D36FA139ED863534AC258FF',
//         'login_session_id': '4ebc268bd604d7684e05eb613a27c83c',
//         'mobi_app': 'android',
//         'password': rsaPassword,
//         'platform': 'android',
//         's_locale': 'zh_CN',
//         'statistics':
//         '{"appId":1,"platform":3,"version":"6.72.0","abtest":""}',
//         'ts': '1658922744',
//         'username': userName,
//       };
//
//       Map<String, dynamic> query = {
//         'appkey': '1d8b6e7d45233436',
//         'bili_local_id':
//         'b7728df0958a2ea81523b27e974a2fd2202207211020261e67b331a310d1da6c',
//         'build': '6720300',
//         'buvid': 'XZBF5D5B82C2D9D36FA139ED863534AC258FF',
//         'c_locale': 'zh_CN',
//         'channel': 'html5_search_baidu',
//         'device': 'phone',
//         'device_id':
//         'b7728df0958a2ea81523b27e974a2fd2202207211020261e67b331a310d1da6c',
//         'device_meta':
//         '9D1042B0B5B2076C26EB699BD67B2770BEEB5EC13057957D68126ADDC6AA6CE4A1D01BD9E5654B4BECD2949E1CE6207ECFE1AD8AD330AD7045751FC81088154D63EECEC2CC9A2A641EA1C3DF6DA77380628106A33262DA60EF980D0318DC2170AE5CB4F8BBB7F7D0CAF3570ECAD72138FB766EBBBD487577A166223E764AE44485DCC313E86472F8A703CD121BAAE167ED05DFBBC17D9D23A40E1D22FF0EB55FCAC1AEABC12278039A9ADCC869F5F20BB04FDC7BA12BCFC2EE030B25A58391520E2F2BF8C0E54A6E38808F65E35763A6E44FEFB498AFD0C32141943F6906F6A523F747D6FD42618342809098516D4C471032729DD12B68C32F08F61DF042EFA237BB72C0ECF5652376F49F642230684735C2F061C4D177979FE547FF6612576CACEDCC26105090F791EF98388A466FDB7E2073BC85EBB465C4F59CCD9140B19A3A70954DF163B68F2FED96B21C0F3D4AC7EF8556B3FDDA3D87BA3D2B7C937EDBF82FC983A7392EB7069B2E6F847723A16A8259BEF81936E63767EE92138B2D1FF6DCC1AE33378D441F305700D786599F9C8C303123F27E7F09B6BDB5DC2F415282A8BC571E082B215EE1514C6B3E214FAC93EF917794D844BDE8C84D2DC5269E97DD3238A50D748B5F0A99BBD7FDAFA84623DBB57244D4A450CFCB91DDB4C6AE7157C338838CB2B31AB564E012061B0F0B7CAC70B068B6986F24E53E620E892C9967FA56B3F84D644559F6AC5B836DD8391C3ECFA84BF42B8F8EF30FCF7E0580C5E26B5DCF77496958D16B32D9984FF2EEA7237B264FA96466D2F9A3760F7CAD78D13006B0206B88CA204DB1428CC0558A9CC854B50345C4A2E39A0FC72514498B43DC3BA55C7743D9DE77466A31B16B844446691CDDF3FDFAECBB730DE0093AED438733DC43279271FC5BDD9B3B065048A09268582408C2EAC28258A8D5A57BAB1096968A7A3C90CF6A7D076C48597DE03287B31E1BDD587771FEF5F6FB149AAB525DE77DC7D7A45A41CC851B9F917D357F6772EB58521FE3EFCFF287AFCF8D3BF4ACC89EA7ED0B9CB73CB9031131C11F65B82222FA0F040F289FA7F971ED2D2AB676DFE8116D4B203A0D2F29BD69C0447EF5CF31A5F5A512348EBD13F7BC1AEE1397A87E4BC35FBC904B6FABC907DB2F9F4E4A0EBA88C89DEC6F665BEBBAC3862B1C78E029C1F3919ED80B92E3C02416661ADD180F3739299C8BEB2107CE0460A615C20FBBE84B98D13164BA155BCC60A38FC83615158AF6A82E0469C05E06D5D4BC8918D82E8CBA26E58A926C274929A8C4EF4DF5364F4F3D363EC77E832AE88DAED5E0FA031221C59121704BCC45C4844FBDB721786A21835A111BFF2CEFB3C645AE75C6558E9EC8F88176E505A42947AF7891B775F0D7AECE55EF87FDEFEA0AB702B5A49A5937A2BD0770F2D743CC500BC3BED2826F0883E509D0FA0CAFB0FB1C3E5AE148B9CEE138D955DE084E2910FD04D9D260A5CEE39113F8D1B4381A8DC47B56E963F3380EB6F566D23940CA3583BD76C66A284B9157DA888543B54028EFAB99BA2A8C0374D03759D74BE7C3EE62659E0420320BFB9D6F17FA8985871557C2CBBEA37E7D49A88D2E89736BB8B62E68A8DC9532C5213479BDDBBF9259BE3C3E8644AF43F74016D4AA14720F2C4FED88196793338748BE669C99D0613BD2B1A7B7A09A139FCDBD84204310D364E5C5AC799AB71F72ED6084FF169F19077CA6956923FDD7C95800D0F8F950F13078B3187F5C1F2F04174A512035CF1923289ECADAC785D7071675997025DAA29D70760CD0722D538A0DF3D168238FC3D626AA4664B20FDEB4F649397755368EC6AF13524E23F4C3587069582247208D0344D68161EA405C7A26FE62E6A1CBBB3A7AF59D562DC5B21174F0D867002831400E79C3B3CAC3C1324E47E26AD25A38076D59345D524A9306E7A66A447A4EA02E693403E853374DAA1E83D1A070E075A03ABC79AE750EBFF91FBB514786AD893F73A34AB8C33A81F86E8DF03A4F461F2AFCB33FA5CFD0ECC669C3A22B860FAC4024C3212D0AA787B1847CC832D3D4080B9B79361533CF92918B601AF958E7F73E4129B6845C620FF5E26E07E6155F44E422AEB6CCE63E5181626C99F8C525BC83493BC0EDBD26D7E0EBC89B31629A6B865A3CD16B370F23657169C49EBF9F6595F2E932B55658A84D6A46BA8FCB28605AD8793B96F58D11DE9D7CB7B78E70FC7A0B7A7FD283E8267419C7A478021FEA7A05AF628C8BBD0A89078127142F2B9AFB6173D978F0BED6BCF1E2692F3C4E848AC41C585FA15970B4DB270CA971BE79D7D72F69EF3914AB1DDF8017CF9352FB707B6771680C07798088B1D35B782E9E9A3489614C5CAF410602D203BABC1B958DBA7DE45715836769942D5E9B6D621A889585E707AD76F289A691BE6C71679DCCD2DF0CC3A3838A2EF13E4CFCBA1308FFAF5A99152310DC87F93B985C7C7A3971E8EF1FFF2E624F0F6A38F9E6201672E000FFD9061F3161F123955C1EAF5F20F6A65DFDBB7EE6F0BBB55C2130D3A669C203405C0DF3A2C85A3CFA2AF3CA4489200BCACE8889AFB4C11420DDE46029AC5C9EB02469B3ECBDC19E5C7A87EC54D3F9B4D049246F526D1D0172786278D0FD5BBE4336525DDB27001B1A0A39866B4F4EEFCE48EFDAA131AB8049E5835384EB27A5C7725619A50EF05FD2028719F931A0D13CA63515159C2A58A73013BBE87057D913AD0DCB90E4EF28E9ACABE60DEC8DB64CA6D59E5E96E41C536C9C035E02DC4E1BA313EF357FD2F919AA05373295D2823E7D573681ECB7A1D57F86CD1AD016A380C13DE5E5B80594FD37AA1AC0994103B0266786E343B05DA5FC50FF7FC54FCA31AB87E049ED06889A484956BAC402376EE6925EF20C0EDEDF28E0CFFA56411FF9B5D313467E3235E8289885E52741FE641BFB0EEED63008F448E752E1F3A1C41E98CCB6CB22C45D81C6B16B3D0432CB6C72F808D5D9E22D56D6FEFE092D103122F804F90EE4C3BE28D53849128D203A8DD4B53AC319F37F03DCB84AB74F56A141314A6E826ACB35E2A34FED4A63AD37ACEE8E29BA6E7CB57F9110E958DB95CC594B01E39222957CCD34FAFB12AAC49B5E5290440E8A3C734B88B4E643A655EF5959D4D1559223376B7A45686DC86021AC94A6FB17EF0D102838C1E52C94C5F5AB3A92C9DF31948F574FC0968E5F371146DB641A6A4B254B51EA74C493931DF109D425B460A3784890AC35312C84D66F5C10FAEE9E70A4436BE81CF14B37A15C994E8B47FC835D0E6D4A0BADB7171F7E58BB719FE4999DFA7EAE9D04065B6ED24EA4F86535B6C1028A0E5A8FF12E187A4B3B5A7D6B3D68CA130F552DF1F46A3EDC561E073460EFC73C19BDF7D4520EF46C1C1831A77E70CEEE9489FD468A29FFD8F7B386DC40B6D188F8B80B7F03E97A91AF182287C9A88E27060C588DF2976F3A15340D53C9F82638D56258B88CF17B8D49A8100E5554D84FDD4FE233989D9829522F889A62EECE643E371A2A2D28BE43A77044D2B133677394DBFDD23342D0543E52667BD2D4A798C93724AE435CB58E67018CA12B0659144F67AC51AB241A20C1B069087D2D2EF38477B6601598151250862CF5C90A3C0B44E5A436E522862D13F5EFF1C574D4DECF16B453AA496925B7DCDC63D2574C6B1DCF96604CCAF41CCF2CEAA381EE6211BA2D460958D5146C903AE9654E622666DE7FE14E7485A73B29A874CB458D745D2461346D54FA50241B57657801E916EDD7E39A888860A13F45F8B8F21AB85F5776BAD18B447B4BABC3FBEFA3EAE7C7859602D408934A197AD969E46E7F4F15F25901C4F63917197D59DF6DCDFB0644F337BF8D44E4CB2CB081D7E2EAE8D72D6025CB8C1702EB17A31C32F05774E1E731675ADA4816DE4740C98E6F17BF371317C3CC0A48DC8AD16F0F8A8E641B0237C8BDB7592033B65AD7FA15C098026FE72EBD140FC2B2B86A1F5AD1AA7D8B7C80C7CDF6AD1F8DD4A5BB944581277F55710B1D06FBAC2D5A6AD761B59101EB1DC516E4FFF05FC5D48E718BBE53531138ACBCDA4F5601BAF6D6F001487BDF2D2054C9763DFC55FA39CEDD545F13C6B0FEFA23F54A08E0784A482F1FBD6BC353EC83837ADF88EF83ABF8E7FD571866BE717292EE9C2D04A72DAA8F218470C084FD2B6554FC729F926D7650D647DD1CAB367A99A587BD70091573CF6705F380944DF482D2B45C22EBB565DF4C24B50B46328ACE589BCE4FC0DD1F81511FFB375CB5F3A0EE270E73E2FEA5FAC68BEDF4F991F73B7F3C9E2C7AB77F2DCD116686B22FFCEBB56E6413DE93107DC28D8D7361707AC7BEDE604E85D52CEF6A29FD632B40F8112B9ECD4342D9DAC2F371814E73DCD64CAC6490967097B374550ABD0D292EA49E112EA51B86AF898C6E95A80367897A1EF61E7CE2298682CDA410545ED29C4B0A63526B865D857296148884ED2ED284B4730379280656BED459412EE331D40FE67893D238145AAF38E16EF1A0C74DEB3469C1B2F6629F504569F5D37C3CB6DE544EF9CD5B67E3F48653DAFA48D126DD682C67C7A0C7275B859FE8E76E0FB10FE1518F76DF02C414E51E6399E1754B343366AE5D38A576E578D7F4DAF263030E112E49B49B5522B631198A69BC3FE1E4CFA12882D3599546C3251917BC16828EB946B1D78C9822CDD563A4E79D27B11855BEB5723F71C708406E293C1CBBD062C392DCA75F197273127203C274D0AAB410261CD40B02497DF855C5DBE03D9BFBABBC1F067F2CE2296993B65BA6AC3C89F5F37D6B6EEE3172EB523EB790231B1806DFF09B0FD46ECC0FC87982A6AFCA289A3816903C2C3A27441601E2C2D1B2D0C5187B3D06CBB15838972F3AD901479889903AA4FC43629A9355AE731CA4BFFA2DC1659B2B99A50DAC96F1CF67AD8F4E952922B9418C2DB9C244F39E9A115501A9A86F67FED23AB40CCD6FBB7CEAC21FF05C04EF18876E241FE6F9B14E1FA25FED1ED3DAFA0099184E55072D1946C6F1893922A36513A61CBC39863616FEFADA8E593A7960A143077191A17C777A77FBE68B648A1E50BE1D39856E6C17A8DD5B7CD4C3B4AA85046A95288720DBB5B1BE067221421B933C3BCD1DA765C47FEC37350238FEE1F9955840D177D007B7BA8FC8AC30BA10371F79B8F0B052D994DF10F8FC810845B3BE37CF5BA96D197D816976D6DB70491E1F3492049B1CB4F64D937ECD0D7B391536572F68138D08AF227DD83275AB42F8D31CCC3924C1B9D4E705EDF25A651C6EA05984D6F5A05ED37B7A1483309448AE5F65844B4EBC801B8643282F0C03976E4E2862BA13C84C7ABF8E1A08EA9DD81A79547E5EA6BEDD35841544DFF6C1AEE8952B349DD671D4DE3F094569ADB471BB28F455C97E6B1281DFD1CD6F66CF8DAF9E6634C03ABECD190A51239351346231FE50E1BBB55FCCFCCFD1213CB6A4CEE7910D2B80C05708F87AF19AC8426874355B4273103E28E5D6482FC20788E20500D9C3D32EB18D843142F7F16D1492F2E5F8CA68B904FAE0AA30F57DF4B67AFD457F3A1E8E4C54ED3D2F97C68F0AFCD1DD6B06849B22CBB126CDC5C4694D05CDEA2BB2B5C8AF733476F325CBD8B5F55035AB530913D9EEF381F162952778DAEB665C6511542219EC5FABA8A5ACCCEF8D5856DC577350735B81E971ACBA8A7CEBFA415B990DBCF229598A603BAC20FFC1799FCD8C9200CB7D604E860518D00E9744C225647EDE9B03CBB2910DDC0509510B52DF5DAC4599824ED4AEFB94673827AAD9885B0320F8929C3F39E51245DC7E4957F6A20A557205DF42960E4F9854C5EF459C20570A67E8DFEFAC40A8600BB7E0B43BDA5595EB664C40AA850B26265BE1C3402151100812673E6C9DCD033351F774ACC46D3771461C860B8778AB2AD10E73E6ECD09A417D1CC796B53D20BA9D207363F8793D352015AF5C62216CD97BEFDA4477EC29D7C1E3A0583A3DE7FB01BA9530C8AA2DFD532EC32D8C456140D71A5E7495107922440C92FD8C339B12DE1CCD650F44AAF7F6902281232E31E4903EDD0EF2BFDED682C86ED55B1489C935423B63D5357D231EDB4BB71C2A10EE6BD2CA6337FF5CB424954E7A172A832B6452CBDE78AEB2CD27F204A40B7C158441F32FB7393FA3ADE0710974D36E59C200BD7193065C1B934FB9CAECDC5FDD1BFE6F9454BFED8BDBD6EB55BA5E0B08F0E2269595133D9C49C2756B1CB3B6B9CE2AF8A8F039C679B7A842329A4893A3E827D34E7207E2BED5A33EF6A23C86F56DD024180E22BB34B922BB23ED15FC9B61C2E491A91EC7A49A8661C0111455E183BD31CD8C4E413E2BAB567A85617301FE71CAC2807F2E0E50835EEB833416FE3346246E97A01885FA36B61863173E068784D024147A96A0E2BCD468F729BB7FC9185C3592BE00D5582C6E474EFE73BCA473176E9CBF5FD755BFA9C0D7FD5B3927A2643969D9FF7EC796D3A205887B043A6673D551D05A6B1CEF8BD34C60DB17E4E1CB9D0A1DC5E9BC519D060B304F4A9DAFBA334AAE3B18FA0265A9EA4D9AC42FF7C558D9B8301B3858BB97A24FAA22CB5F5C308DADCB5C256A431E01445AE3CAEE4720B77671838B9C69088BA73EDE6F92EC301A29A18C04FA4A4632CCD8B37CAC21322379F8B352105C42D7F000315DCE9DF7C236F6AE8D001553CD5B42F3E9ADC893DD503B589333C1B1B95346BCDD9A60349E6EFC85AAA9041455150C7631DFC9E2FA2E229B5BE0B6A7028C32D9E34B1A2D84D77DB88FF4F8458DEE0DAA9758CC1BE1A7A219F63FF38F6291ED8585EB0594DF3E57CF01C2A153EB9C7BEDDD29E8C0284532817265348B6B7713DFE95EA2D9BB0B1C2658AC3B2A99A9A856523490A8EEF4E01E07FB51FAB5B70007F345DDFB28760BBCEE6072740F4670DF030C10C339447B94FD15201F291A2BD636F33E5F13D5FB55B211A0AB5426E97355D5D1FB17DD7000C92E83BF3C2D633C5B60B1F3CE78E4D09FF2AC9794355BE2171E289B0E94E47DC08A5231B7E748EB2C781AE8B96FA834444DD4B1C3E3A989D7AADE3829CA8693D7E23396FC567C28781FD20A4F657133C96E2953EE6CBF9F1A716D9E42DC53717F2D32763332D60DC56080085684BD411A5C788AD9F56393B96E38B5A502A8DD99A83F9AA272EC6AC6697315330E849D01AA734262AA4693283A2FA06CFC564A63D138774ED0B5E1BF873485BFC1CD7C132103031118D7B3623431446199DBEB7BC9B7B3829DB9662E47FD6E10F7A89BCDE6512DA45D0DDDBA05012C182CC5A53637C9050F56F91CE0530885DAD308D98F7AE70CB98DFE4008ECB7925FEA5F5CED8D511FC736D4EA1606836E0480E31F73F1380C47172B81782318F51786C5F80D17F86041D5A4709E96136E1E3489EF421B5446C4D2729370E5D45D630C9473157F09543D6E68272E49D81C84BCC690CA7114435B4AC1C786F16B19BE793E95A6B8D86B9463431448AA51560659B13EDB8B6F7B4F4213654379EEF94675CD6193DA96394C45E301D147867638641E82B68A790ACE349B868EEF215733FE610E1E2FA0554E22748BC9A09D26DE28AF114471F56DA21C090C3C8E8804725A1637FA3BBEAEC52B88AC35B4BBA068B8F33969F035440696103414D37B94FC3B016DD1E5724EC0335692BAB778CE3EF188E04173305056632C2EE33901696587057ABA5DF95BD6C8A0412BEA4BD96A04430D10DFBB874AF38B28284D2C9A6EB5FBD980C107A510E8365DF843992F2E379E9005B205EFDF45F4A3B17B25640D1E1DEEB601B09A2C2604BB2C2F6517C9DEC0749F0D680C8C71BC969A3FC239621463BC4806F40F32C465546E6A71C7E4BB1CF4D704848C5796804D75D779BC11F2A84CF0F88D94BDEADC394664A6DDA6EEFEA6A21F40003A64094260B9FF704BAAF61459E0DE24649C57D828F24E3015B6940DC161AF7586FAA93C8EF2D64CCEC9107002308E5E599660C1E3E86AD9562EC885FE1AA5B7ED14B8F578381DB28CE1466237A09BB7FE60913E0EF4CF1FA15FD9978842F48829DA671EA8AC01FDFBDD57D19BFFB1FE5DDA7E9D8AE9AC7BE24C22623E67DB3EF71991880D72D6CDBDD17B63FFA489CC5AA2750B31432DFBC8EF402E349F11A72A5A379AF716BAB7507907D9A7E25527C23A9E54EC153CC223497F7C884EDE74C027DC1486EE211502F222CD24C3710214F1EB867837F1A09FD0D7A2D929927D296331B38E17E4F13CF73C753E7E8C53724B896148AA8B2A9E936DA386956BF7156B33785C5B2051D4F4DDA629D2BF9EE75608B43B894D58BD513D85341F5537F3688DCFB049DC5AE09A03195B3F875FC9E225DE1BAEE206B55E4EF797E1E57A1D5041DF44125B81D6B083A5897809F20BFF398D7DEB0E7CE16F3C4938C29110F302367A3F42EA8A3720DC22E6ACECD0B6020E3334BD97B19D4F4C09179A9E92449B7626FF3EB185CD0BFF83D7E28027C8D9AD5245F6678801AE9E5BEB60FFF02308EAB1812597B2419F722138FA54FB6CAD105335D447581BC99533E4F2149D00F312018617AA37FDA5FCD942190D07E6A596C1800C19AC6569558B7488FFAFA08365D384DA6ECE3272A18A89ACA72E60699ABD09342DAAF3081A8C96181852285B29C986FC966DC1D10D32C3BABB83417D8CC6FF23888A0C377C3E401181AF1A1C51597AA74597881FB779F922E1844346F05FA4AF498D94DDE7ADE92057DB2B93463543F7DDD58C57FA8333345285286B0CF1196FF7C3839AF37D855BDAE836B5C68A4C82387DADA9498CA64E0CAFDDC37F94319F75075051E251FBF676E320771A2AF925B10BF97F81716BA3E8E11656B9CD280A8A9D7144C520BDB082D69079282B8A013AAF2FB43EBF265544F51201B842509B2DDCE827529195C81D5B2646E782257AE261D8E7A1BFF0EC856CD572BB752EF9252D3A10A29AABD7DD2C3EC8A96754621385698956A592994B35199508A75E7E35084012644D6B386A2D4DD6A60981AE7DA167E1D3ACBD48B6416C04C8235CAE89C079E7C7DEB0D45CFAE6035617CB3140BC7D48A37276784579134FEEFD2E84667A26B99F636615C820D51DC2E8CF36544832EA8F0D5527B7A950137D6F05B1DAF30A9EFAF05D5974EEDD7177A4BF82552A67A30009B7D25EFAC7A2E696147F80F73A11710B7FF02D8996E21AE8D5226DC418B30BE7BA55ECCA755B484BF8C474401ACA973A0D7B3E5DD6045A79164BD248F561DE486781272B35D785769D54ED469C0C241A0B2B74A28FA62CD70C583AC9A166F7C43CFFAF245997256121B4DCD8107FB79FFC8EAA3B3A5BD53D44CF7AA79A9F2601D2A978A5E392765503C63BEC949345C7E3CB76B1FA7C31E10C58463CB9C9E428B70B18327173955F53631DC442B6ABC7AA56A3BA217A84328E243375D3486E1DBB6CC0D7A96ED863D749F623604E05F185F80941676E74273D745CB977BBF1F515E2A6105A2937A6559F7A80D37BD5FC36FA0A18595AEF24294EACDA140B236F8CBFBC0C085B6C2CA398B32A9551E62910F968C7F7A11877BF888B6183BBB8067CAB57F36863C576023390A43E96EC45096E3DE48CD5F6EDF461B17FBC169EA74D64F189715C18262EBD58AC2F98AEA0AFB3AF60C190F664F32D4F6D41D1D16E139B326A8F0307E5AE003FEF9DA30F0FBFD078A269D0F044B0C8DBA2DED4D620E3A1502CCB8C54EF27C5DBFF461B287EB6FE26C37609C5C08F02F0B212F9A227B81F541E83B7441F6B4EADCF4B3D0DCBF9C5D07354B4A6DA905A3B7A8CA5ED668CB166FCB041025F163D52783A3CCAA083D1B20014CC869D73C3185E701E3AE5D9D5D1A1313232EE5AAF0158EF6C1EB5D7600D8C130BFCAACC292EAAAD43E560AE080661AFB3031CFB5FF83F4EEE6DE4F361DE13EF958CB8E5E409E92FDCC2FB39C01770991F7DADBF563AC9C3B0D52AF9FA18E1E22E92DA5881140DFEB68E614920098E283170000E5F3AAA90D361A6D9CA9DF7F959260A120F15F83BAE5054AED39F9BC0B9E60FE334ABF57A56BB6769CF6EB10E0F56B44FA327B6F90C9AECCF9FE6F07E19A3838F391126D949965BC842718788CE0D6980F707421AC14D97864F75F3281CEFF9A807A95BFF18491E577545D86999133BF518A03E2BC6FFA746047FB7FA3314EDEB6D76DD4A1F172BA246A3E5265510BE6F70314FD4958C2F6939DF954624AA8030BEEA15823D3DF44373D5B7A61905FC2FA03115360604C9C5945C619A561E9BAEDFD262C4365D9EFB8A05C1B10BE6B9661F46A71FFE68EE2BA27376B41E9247DB1D5CA192DE41F079354CA64B17274F15BB544AE9533308E469AF3B415D696124262EE93AC8D3049E9301EB63A0DD43320FAB051E217E387B8F5058BF0BD7DFFB34CAC5C986A6028A1AF09FFED1E172F31D45A446B139F26B3A3D67C24E3C96503887161AC42BEE67CD1818952E07C614A0F9575DCE7B4BD8A990E3B302F38AE3910020459FA1962DB8761312C35E9CB66E47E7A79EEEB7359445915742CA6F0B20278C078B7E944ADC95BB0B380944FE82BC3EFBCDA8C2D47B463179E0AB1F8A5563D95757BEA4198E7F287E34E91696B46396A6259794AA3FA11CD9239BEAB73D8E63DC8C9F1E55909BEBD12E5AEB91EF1ACF1270D3C1F617D888DBDF7A4027083B8A83E63AE8F87749D83A02CF20EE65131346FAB05E012799C2ECFBABB8444351E38D80F91187AA067847CB63992160793B3985C7B6B023A16A733886E4E58D78DFB719FF4B5DED8B8E635803EAF473C21E8BADC4D811AC76790AFDDD0C1BAFFE949A725323B1B3DB2D6DB0CD40099E1C92E18DAECFB61BA948B8104E3A65C635ABA96F9C2451A9AE915258D1ED76FB4042975FAA822BC6BD97FB5CDC8079E28219C610F1144D3A947C6BBD432B30E730B0FDE2C93A72BECA56B1CC1EFC63E12D20C50E9619A33AED1B85BBBD33E6C9353DF3126B22B798B663D7CC1523AB14E1B37D3AF5A0F6FFE27980B329A873142374097945E41709E8F2D900ACD42B56039C63AF8976C2BF74A9466F899DF39F4B08BE2D1E3A693161738F6F9B774CF1717F7DF3E67ADBAB2E567886B745FF077EBBD09CEA84B4F7A6FB69A4DCEFFC333017B37F33233D5729D8D7D079E1E05CE5ECD725A1CB4377F0BCDF04EE2521CE85C71DD2BD2A4036DAD3C9773993845F1B5DA5EE2B100FF459C82A9FB5358CFB2963CE5E708F3E38FF548AA30B858D4D751BE03911435621EC1EB7D61BAFFF60D702306657F482F10F11245A10C5592C99D15B3866AB885BE39F9D3F6609921F14019CA9C280B5C8C084B83A5D8A4845DD75BCB630E1B17C0CD5B134D5341E2F527D6F335631DB3DA03C0EA10C3B6F66A7A4B6F67645B486678D8794227B02736A2C4BD2DF1DF57CE2CB01685E35F770FD2FA2781A4B488118CCC4AF9D21C813662E6042F5D03A31B3E9694EA04F161047A843176876503D9EF33787BCFA58B329E94588DB952779C253898E7942A3929637FE6628C222A2F5C08A259F0405E900CF14000E6258B1961B832870DDF2D2503E0E1961888ECDA5F963B5A61D526570D952E0249A818D5EF9B09722480FF15FF60DC3C1E78C0361E9833230B9245D7ED1C04B1210EBB162998293BDA5D39989591BE6B9031E85CB74B6E602C682F8EBB5FC8F30DC84C9B4C4CFC4DAA03EB1D0D4871EAA7E64AC0F5DA901B11DBE3E0B9928AB21DFD1F54DC9DA505FFA4444C7C5BEE6178D571D93761A7F8727C9F0D162FBD141F4846E2F56D23A30BB9E12FB03F13EEFD42012FEF328F099A2E413BF1A984913803809508645BA5217E2C63DEFC1AFF1141D6794F137904D9AC48D5B4E46BA852EAF4687EDC813C44DFF869A6EB6DE908269218CC92CDB0CA8A700546B589DF4691A942B2DD3231A1FB3D11F202F06F4F054771BC043FF1EE1E0D99C65389C9482232F87F4D63AEBC4310F04F3AFCB16B44A3DF2281445F94C114BD3B585BF233714CD7643C5B7098D42769544DBB328A7E7F421181B4A2E354E30BA7503DB2786F69EC6F067A2F987417C24D8CDB530BB5CA4E56CAE11238E3F244D55A6CF894AC39E52BCC3B32D4911A18026C28F1B76108A69925233A4104011AFB63EC2BC5687ECA75BB9DB0ED8971FA8AF13594396037179C8D048D6E66468942B69E317E5D3EF0C43C842E0B19122A17EEB25B76D2444BB34C8ABFD9C531776B21174CD7AC136CB882ADF40B0337F772CBEEBB09E0C647278ED21770AB26B18E6D276E057D9D251A5398FCAFA3CD93DD861DDD072F6BD9FA134C5C0F4650880',
//         'device_name': 'NeteaseMuMu',
//         'device_platform': 'Android6.0.1NeteaseMuMu',
//         'device_tourist_id': '20096420566197',
//         'disable_rcmd': '0',
//         'dt':
//         'mV2Z%2F6SLYv10MZBYowD%2FJ%2Fj%2BJQ4IE2T7zaiLrnxxpyj1LQJ8yJ2GguZwqHIlGo%2Fu2LfhLb84ye3%2F%0A0ylX0hixiOaVIfaaI8MTLZrQIxSi1q17cq%2FkpIXVT3MDyLxJzcJUdsA15Qw7sp0MSwLL09cQXclG%0AcxYIyARMKH6MfD6M7Qg%3D%0A',
//         'from_pv': 'main.homepage.avatar-nologin.all.click',
//         'from_url': 'bilibili%3A%2F%2Fpegasus%2Fpromo',
//         'local_id': 'XZBF5D5B82C2D9D36FA139ED863534AC258FF',
//         'login_session_id': '4ebc268bd604d7684e05eb613a27c83c',
//         'mobi_app': 'android',
//         'password': urlEncode(rsaPassword),
//         'platform': 'android',
//         's_locale': 'zh_CN',
//         'statistics':
//         '%7B%22appId%22%3A1%2C%22platform%22%3A3%2C%22version%22%3A%226.72.0%22%2C%22abtest%22%3A%22%22%7D',
//         'ts': '1658922744',
//         'username': userName,
//       };
//
//       ///按照key排序
//       var sortedKeys = query.keys.toList()..sort();
//       var sortMap = {};
//       for (var element in sortedKeys) {
//         sortMap[element] = query[element];
//       }
//
//       ///参数序列化
//       String content = "";
//       sortMap.forEach((key, value) {
//         content += (key + "=" + value + "&");
//       });
//       content = content.substring(0, content.length - 1);
//
//       ///拼上appsec，并MD5加密
//       var sign = md5
//           .convert(const Utf8Encoder().convert(content + appsec))
//           .toString();
//
//       ///加上sign字段
//       final signEntry = <String, dynamic>{'sign': sign};
//       originalQuery.addEntries(signEntry.entries);
//
//       BaseOptions option = BaseOptions(
//           baseUrl: "https://passport.bilibili.com",
//           connectTimeout: 10000,
//           receiveTimeout: 10000,
//           contentType: 'multipart/form-data',
//           responseType: ResponseType.plain);
//       dio = Dio(option);
//
//       ///表单格式提交数据
//       FormData data = FormData.fromMap(originalQuery);
//       dio.post("/x/passport-login/oauth2/login", data: data).then((value) {
//         Map<String, dynamic> data = jsonDecode(value.data);
//         url = data["data"]["url"];
//         setState(() {});
//       });
//     });
//   });
// }