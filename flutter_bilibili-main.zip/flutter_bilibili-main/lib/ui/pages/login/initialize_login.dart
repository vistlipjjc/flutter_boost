import 'package:flutter_bilibili/core/extension/int_extension.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../core/model/region_model.dart';

class InitializeLogin {
  double imageWidth = 90.w;
  double imageHeight = 90.h;

  List<RegionModel> regionList = [
    RegionModel("中国大陆", "+86"),
    RegionModel("美国", "+21"),
    RegionModel("意大利", "+156"),
    RegionModel("西班牙", "+56"),
    RegionModel("泰国", "+65"),
    RegionModel("韩国", "+53"),
    RegionModel("英国", "+78"),
    RegionModel("印度", "+12"),
    RegionModel("埃及", "+82"),
  ];

  int regionIndex = 0;
}

