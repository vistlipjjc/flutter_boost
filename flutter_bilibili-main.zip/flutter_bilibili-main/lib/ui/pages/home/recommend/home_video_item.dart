import 'package:flutter/material.dart';
import 'package:flutter_bilibili/core/model/feed_index_model.dart';
import 'package:flutter_bilibili/core/model/video_model.dart';
import 'package:flutter_bilibili/ui/pages/video_play/video/video_play.dart';
import 'package:flutter_bilibili/ui/shared/app_theme.dart';
import 'package:flutter_bilibili/ui/shared/image_assets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';

import '../../../../core/service/request/video_play_request.dart';
import '../../../shared/color_radix_change.dart';
import '../../../shared/math_compute.dart';

final _radius = 5.r;
final _iconSize = 14.sp;

class HYHomeVideoItem extends StatefulWidget {
  final FeedIndexItem video;

  const HYHomeVideoItem({required this.video, Key? key}) : super(key: key);

  @override
  State<HYHomeVideoItem> createState() => _HYHomeVideoItemState();
}

class _HYHomeVideoItemState extends State<HYHomeVideoItem> {
  @override
  Widget build(BuildContext context) {
    FeedIndexItem _videoItem = widget.video;
    return GestureDetector(
      onTap: () {
        if (widget.video.goto == "av") {
          HYVideoRequestRequest.getMp4VideoPlayData(_videoItem.args!.aid!)
              .then((value) {
            ///匹配字符串readyVideoUrl: 到readyDuration之间的字符串
            RegExp exp =
                RegExp(r'(?<=(readyVideoUrl: ))[\s\S]*?(?=(readyDuration))');
            // print("exp.allMatches(value)---${exp.stringMatch(value)}");
            String videoMp4 = exp.stringMatch(value) ?? "";
            // print("videoMp4-----------${videoMp4.substring(0,videoMp4.length)}");
            _videoItem.videoData = videoMp4.substring(1, videoMp4.length - 1);

            ///跳转至播放界面
            Navigator.of(context)
                .pushNamed(HYVideoPlayScreen.routeName, arguments: _videoItem);
          });
        } else {
          SmartDialog.showToast("功能暂未完善");
        }
      },
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(_radius),
            topRight: Radius.circular(_radius),
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Stack(
              children: [
                ///视频封面
                buildHomeVideoItemCover(_videoItem),

                ///文字下的阴影块
                buildHomeVideoItemShadow(),

                /// 视频封面上的左下区域（如视频的评论数和观看数）
                buildHomeVideoItemLeftZone(_videoItem),

                ///视频封面上的右下区域（如视频的时长）
                buildHomeVideoItemRightZone(_videoItem)
              ],
            ),
            SizedBox(
              height: 85.h,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  ///标题
                  buildHomeVideoItemTitle(_videoItem),

                  ///视频底部的左下区域
                  buildHomeVideoItemFooter(_videoItem),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

///更多按钮
Widget buildHomeVideoMoreIcon() {
  return Image.asset(
    ImageAssets.videoMoreCustomPNG,
    width: _iconSize,
    height: _iconSize,
  );
}

///视频封面
Widget buildHomeVideoItemCover(FeedIndexItem video) {
  if (video.cardType == "cm_v2") {
    ///广告类型的数据
    return ClipRRect(
      borderRadius: BorderRadius.only(
        topLeft: Radius.circular(_radius),
        topRight: Radius.circular(_radius),
      ),
      child: SizedBox(
        width: 180.w,
        height: 120.h,
        child: FadeInImage(
          placeholder: AssetImage(ImageAssets.icUpperVideoDefaultPNG),
          image: NetworkImage(
            video.adInfo!.creativeContent!.imageUrl!,
          ),
          fit: BoxFit.fill,
          placeholderFit: BoxFit.fill,
        ),
      ),
    );
  } else {
    return ClipRRect(
      borderRadius: BorderRadius.only(
        topLeft: Radius.circular(_radius),
        topRight: Radius.circular(_radius),
      ),
      child: SizedBox(
        width: 180.w,
        height: 120.h,
        child: FadeInImage(
          placeholder: AssetImage(ImageAssets.icUpperVideoDefaultPNG),
          image: NetworkImage(
            video.cover!,
          ),
          fit: BoxFit.fill,
          placeholderFit: BoxFit.fill,
        ),
      ),
    );
  }
}

///视频时长
Widget buildHomeVideoItemRightZone(FeedIndexItem video) {
  if (video.coverRightText != null) {
    return Positioned(
      right: 5.w,
      bottom: 5.h,
      child: Text(video.coverRightText!,
          style: TextStyle(
              color: Colors.white, fontSize: HYAppTheme.xxxSmallFontSize)),
    );
  } else if (video.badge != null) {
    return Positioned(
      right: 5.w,
      bottom: 5.h,
      child: Text(video.badge!,
          style: TextStyle(
              color: Colors.white, fontSize: HYAppTheme.xxxSmallFontSize)),
    );
  } else {
    return Container();
  }
}

///视频播放量、评论数
Widget buildHomeVideoItemLeftZone(FeedIndexItem video) {
  if (video.goto == "live") {
    String _seenText = video.coverLeftText1!;
    return Positioned(
      left: 5.w,
      bottom: 5.h,
      child: Row(
        textBaseline: TextBaseline.ideographic,
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.baseline,
        children: [
          Image.asset(
            ImageAssets.seenPNG,
            width: _iconSize,
            height: _iconSize,
          ),
          5.horizontalSpace,
          Text(_seenText,
              style: TextStyle(
                  color: HYAppTheme.norWhite02Color,
                  fontSize: HYAppTheme.xxxSmallFontSize)),
        ],
      ),
    );
  } else if (video.goto == "av") {
    String _viewText = video.coverLeftText1!;
    String _remarkText = video.coverLeftText2!;
    return Positioned(
      left: 5.w,
      bottom: 5.h,
      child: Row(
        textBaseline: TextBaseline.ideographic,
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.baseline,
        children: [
          Image.asset(
            ImageAssets.icPlayVideoWhitePNG,
            width: _iconSize,
            height: _iconSize,
          ),
          5.horizontalSpace,
          Text(_viewText,
              style: TextStyle(
                  color: HYAppTheme.norWhite02Color,
                  fontSize: HYAppTheme.xxxSmallFontSize)),
          8.horizontalSpace,
          Image.asset(
            ImageAssets.icDanmuWhitePNG,
            width: _iconSize,
            height: _iconSize,
          ),
          5.horizontalSpace,
          Text(_remarkText,
              style: TextStyle(
                  color: HYAppTheme.norWhite02Color,
                  fontSize: HYAppTheme.xxxSmallFontSize)),
        ],
      ),
    );
  } else if (video.goto == "bangumi") {
    String _viewText = video.coverLeftText1!;
    String _likeText = video.coverLeftText2!;
    return Positioned(
      left: 5.w,
      bottom: 5.h,
      child: Row(
        textBaseline: TextBaseline.ideographic,
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.baseline,
        children: [
          Image.asset(
            ImageAssets.icPlayVideoWhitePNG,
            width: _iconSize,
            height: _iconSize,
          ),
          3.horizontalSpace,
          Text(_viewText,
              style: TextStyle(
                  color: HYAppTheme.norWhite02Color,
                  fontSize: HYAppTheme.xxxSmallFontSize)),
          6.horizontalSpace,
          Image.asset(
            ImageAssets.lovePNG,
            width: _iconSize,
            height: _iconSize,
          ),
          3.horizontalSpace,
          Text(_likeText,
              style: TextStyle(
                  color: HYAppTheme.norWhite02Color,
                  fontSize: HYAppTheme.xxxSmallFontSize)),
        ],
      ),
    );
  } else {
    return Container();
  }
}

///视频的标题
Widget buildHomeVideoItemTitle(FeedIndexItem video) {
  if (video.title != null) {
    return Container(
      alignment: Alignment.topLeft,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 8).r,
      child: Text(
        video.title!,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
            color: HYAppTheme.norTextColors,
            fontSize: HYAppTheme.xxSmallFontSize),
      ),
    );
  } else {
    return Container();
  }
}

///视频up主及id名称
Widget buildHomeVideoBottomInfo(FeedIndexItem video) {
  if (video.goto == "av") {
    if (video.rcmdReasonStyle != null) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 2).r,
        decoration: BoxDecoration(
            color: ColorRadixChange.hexColor(video.rcmdReasonStyle!.bgColor!),
            borderRadius: BorderRadius.all(Radius.circular(2.r)),
            border: Border(
                left: BorderSide(
                    color: ColorRadixChange.hexColor(
                        video.rcmdReasonStyle!.borderColor!)),
                top: BorderSide(
                    color: ColorRadixChange.hexColor(
                        video.rcmdReasonStyle!.borderColor!)),
                bottom: BorderSide(
                    color: ColorRadixChange.hexColor(
                        video.rcmdReasonStyle!.borderColor!)),
                right: BorderSide(
                    color: ColorRadixChange.hexColor(
                        video.rcmdReasonStyle!.borderColor!)))),
        child: Text(video.rcmdReasonStyle!.text!,
            style: TextStyle(
              fontSize: HYAppTheme.xxxSmallFontSize,
              color:
                  ColorRadixChange.hexColor(video.rcmdReasonStyle!.textColor!),
            )),
      );
    } else {
      return Row(
        textBaseline: TextBaseline.ideographic,
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.baseline,
        children: [
          Image.asset(
            ImageAssets.uperCustomPNG,
            width: _iconSize,
            height: _iconSize,
          ),
          4.horizontalSpace,
          SizedBox(
            width: 100.w,
            child: Text(video.args!.upName!,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: HYAppTheme.xxxSmallFontSize,
                  color: HYAppTheme.norGrayColor,
                )),
          ),
        ],
      );
    }
  } else if (video.goto == "vertical_av") {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 2).r,
      decoration: BoxDecoration(
          color: ColorRadixChange.hexColor(video.rcmdReasonStyle!.bgColor!),
          borderRadius: BorderRadius.all(Radius.circular(2.r)),
          border: Border(
              left: BorderSide(
                  color: ColorRadixChange.hexColor(
                      video.rcmdReasonStyle!.borderColor!)),
              top: BorderSide(
                  color: ColorRadixChange.hexColor(
                      video.rcmdReasonStyle!.borderColor!)),
              bottom: BorderSide(
                  color: ColorRadixChange.hexColor(
                      video.rcmdReasonStyle!.borderColor!)),
              right: BorderSide(
                  color: ColorRadixChange.hexColor(
                      video.rcmdReasonStyle!.borderColor!)))),
      child: Text(video.rcmdReasonStyle!.text!,
          style: TextStyle(
            fontSize: HYAppTheme.xxxSmallFontSize,
            color: ColorRadixChange.hexColor(video.rcmdReasonStyle!.textColor!),
          )),
    );
  } else if (video.goto == "live") {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        CircleAvatar(
          radius: 13.r,
          backgroundImage: NetworkImage(video.up!.avatar!.cover!),
        ),
        7.horizontalSpace,
        SizedBox(
          width: 80.w,
          child: Text(video.up!.name!,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: HYAppTheme.xxSmallFontSize,
                color: HYAppTheme.norGrayColor,
              )),
        ),
      ],
    );
  } else if (video.goto == "bangumi") {
    return video.badgeStyle != null
        ? Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 2).r,
                decoration: BoxDecoration(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.all(Radius.circular(2.r)),
                    border: Border(
                        left: BorderSide(
                            color: ColorRadixChange.hexColor(
                                video.badgeStyle!.borderColor!)),
                        top: BorderSide(
                            color: ColorRadixChange.hexColor(
                                video.badgeStyle!.borderColor!)),
                        bottom: BorderSide(
                            color: ColorRadixChange.hexColor(
                                video.badgeStyle!.borderColor!)),
                        right: BorderSide(
                            color: ColorRadixChange.hexColor(
                                video.badgeStyle!.borderColor!)))),
                child: Text(video.badgeStyle!.text!,
                    style: TextStyle(
                      fontSize: HYAppTheme.xxxSmallFontSize,
                      color: ColorRadixChange.hexColor(
                          video.badgeStyle!.textColor!),
                    )),
              ),
              6.horizontalSpace,
              video.rcmdReasonStyle != null
                  ? Container(
                      padding: const EdgeInsets.symmetric(horizontal: 2).r,
                      decoration: BoxDecoration(
                          color: ColorRadixChange.hexColor(
                              video.rcmdReasonStyle!.bgColor!),
                          borderRadius: BorderRadius.all(Radius.circular(2.r)),
                          border: Border(
                              left: BorderSide(
                                  color: ColorRadixChange.hexColor(
                                      video.rcmdReasonStyle!.borderColor!)),
                              top: BorderSide(
                                  color: ColorRadixChange.hexColor(
                                      video.rcmdReasonStyle!.borderColor!)),
                              bottom: BorderSide(
                                  color: ColorRadixChange.hexColor(
                                      video.rcmdReasonStyle!.borderColor!)),
                              right: BorderSide(
                                  color: ColorRadixChange.hexColor(video.rcmdReasonStyle!.borderColor!)))),
                      child: Text(video.rcmdReasonStyle!.text!,
                          style: TextStyle(
                            fontSize: HYAppTheme.xxxSmallFontSize,
                            color: ColorRadixChange.hexColor(
                                video.rcmdReasonStyle!.textColor!),
                          )),
                    )
                  : Container(),
            ],
          )
        : Container();
  } else {
    return Container();
  }
}

Widget buildHomeVideoItemFooter(FeedIndexItem video) {
  return Container(
    padding: const EdgeInsets.only(left: 10, right: 10, bottom: 5).r,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        ///视频Up主信息
        buildHomeVideoBottomInfo(video),

        ///视频右下更多按钮
        buildHomeVideoMoreIcon()
      ],
    ),
  );
}

Widget buildHomeVideoItemShadow() {
  return Positioned(
    bottom: 0,
    left: 0,
    right: 0,
    child: Container(
      width: 180.w,
      height: 35.h,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.black.withOpacity(.5),
            Colors.transparent,
          ],
          begin: Alignment.bottomCenter,
          end: Alignment.topCenter,
        ),
      ),
    ),
  );
}
