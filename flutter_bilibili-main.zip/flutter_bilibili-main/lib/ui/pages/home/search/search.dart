import 'package:flutter/material.dart';
import 'package:flutter_bilibili/ui/pages/home/search/search_content.dart';

class HYHomeSearchScreen extends StatelessWidget {
  const HYHomeSearchScreen({Key? key}) : super(key: key);
  static const String routeName = "/home_search";

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: HYHomeSeachContent(),
    );
  }
}
