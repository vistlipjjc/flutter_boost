import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bilibili/core/service/request/search_request.dart';
import 'package:flutter_bilibili/ui/shared/app_theme.dart';
import 'package:flutter_bilibili/ui/shared/math_compute.dart';
import 'package:flutter_bilibili/ui/widgets/user_level.dart';
import 'package:flutter_easyrefresh/easy_refresh.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

import '../../../../core/model/home_search_result.dart';
import '../../../../core/model/search_keywords_model.dart';
import '../../../shared/image_assets.dart';
import '../../../widgets/highlight_str_in_text.dart';
import '../../live/live_room_play.dart';

class HYHomeSeachContent extends StatefulWidget {
  @override
  _HYHomeSeachContentState createState() => _HYHomeSeachContentState();
}

class _HYHomeSeachContentState extends State<HYHomeSeachContent>
    with TickerProviderStateMixin {
  late HYSearchKeywordModel _searchKeyword;
  List<ListElement> _trendingList = [];
  late TextEditingController _textEditingController;

  ///创建FocusNode对象实例(绑定TextField的焦点）
  late FocusNode _focusNode;

  late HYSearchResultModel _searchResult;
  bool _showResult = false;

  late TabController _mainTabController;
  late TabController _subTabController;

  ///当前搜索的文本
  late String _searchKeywordText;

  @override
  void initState() {
    _textEditingController = TextEditingController();
    _mainTabController = TabController(length: 6, vsync: this);
    _subTabController = TabController(length: 4, vsync: this);

    ///添加listener监听
    ///对应的TextField失去或者获取焦点都会回调此监听
    _focusNode = FocusNode();
    _focusNode.addListener(() {
      if (_focusNode.hasFocus) {
        // print('得到焦点');
      } else {
        // print('失去焦点');
      }
    });

    ///获取搜索热词
    HYSearchRequest.getSearchKeywordData().then((value) {
      _searchKeyword = value;
      _trendingList = _searchKeyword.data[0].data!.list!;
      setState(() {});
    });
    _searchKeywordText = "";
    super.initState();
  }

  @override
  void dispose() {
    _textEditingController.removeListener(() {});
    _textEditingController.dispose();
    _mainTabController.dispose();
    _subTabController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8).r,
        child: Column(
          children: [
            buildSearchTextField(),
            5.verticalSpace,

            ///显示热搜还是搜索的结果
            _showResult == true ? buildSearchResult() : buildSearchRecommend(),
          ],
        ),
      ),
    );
  }

  ///搜索框
  Widget buildSearchTextField() {
    return SizedBox(
      height: 50.h,
      width: 1.sw,
      child: Row(
        children: [
          Expanded(
            child: TextField(
              autofocus: true,
              controller: _textEditingController,
              cursorColor: HYAppTheme.norMainThemeColors,
              cursorHeight: HYAppTheme.normalFontSize,
              focusNode: _focusNode,
              style: TextStyle(
                  color: Colors.black, fontSize: HYAppTheme.xSmallFontSize),
              decoration: InputDecoration(
                hintText: "搜索视频、番剧或up主",
                hintStyle: TextStyle(
                    color: HYAppTheme.norGrayColor.withOpacity(.6),
                    fontSize: HYAppTheme.xxSmallFontSize),
                isCollapsed: true,
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 30, vertical: 8).r,
                filled: true,
                fillColor: HYAppTheme.norGrayColor.withOpacity(.15),
                prefixIcon: Image.asset(
                  ImageAssets.searchCustomPNG,
                ),
                suffixIcon: GestureDetector(
                  onTap: () {
                    setState(() {
                      ///清空搜索内容
                      _textEditingController.clear();
                      getFocusFunction(context);
                    });
                  },
                  child: Image.asset(
                    ImageAssets.clearSearchPNG,
                  ),
                ),
                prefixIconConstraints: BoxConstraints(
                    maxHeight: HYAppTheme.smallFontSize, minWidth: 50.w),
                suffixIconConstraints: BoxConstraints(
                    maxHeight: HYAppTheme.xSmallFontSize, minWidth: 50.w),
                border: OutlineInputBorder(
                  borderSide: BorderSide.none,
                  borderRadius: BorderRadius.all(const Radius.circular(50).r),
                ),
              ),
              onSubmitted: (inputText) {
                if (inputText.isEmpty) {
                  SmartDialog.showToast("搜索内容不能为空");
                } else {
                  finishInputAndStartSearch(inputText);
                }
              },
              onChanged: (inputText) {
                if (inputText.isNotEmpty) {
                  ///根据输入的关键词返回包含相关关键词
                  HYSearchRequest.getSearchKeywordRecommendData(inputText).then(
                    (value) {
                      ///若查询出结果
                      if (value.result != null) {
                        SmartDialog.dismiss();
                        SmartDialog.show(
                          useAnimation: false,
                          maskWidget: Container(),
                          builder: (ctx) {
                            return Container(
                              height: 1.sh - 70.h,
                              width: 1.sw,
                              color: Colors.black.withOpacity(.3),
                              alignment: Alignment.topCenter,
                              child: Container(
                                height: 0.5.sh,
                                color: Colors.white,
                                child: ListView.separated(
                                  shrinkWrap: true,
                                  itemBuilder: (ctx, index) {
                                    String _searchItemText =
                                        value.result!.tag[index].name;
                                    return GestureDetector(
                                      onTap: () {
                                        finishInputAndStartSearch(
                                            _searchItemText);
                                      },
                                      child: Container(
                                        child: HYHighlightStrInText(
                                          originalColor: Colors.black,
                                          highlightColor:
                                              HYAppTheme.norMainThemeColors,
                                          highlightText: inputText,
                                          originalText:
                                              value.result!.tag[index].name,
                                        ),
                                        padding: const EdgeInsets.only(
                                                bottom: 5, left: 20)
                                            .r,
                                      ),
                                    );
                                  },
                                  separatorBuilder: (ctx, index) {
                                    return Container(
                                      child: const Divider(),
                                      padding: const EdgeInsets.symmetric(
                                              horizontal: 20)
                                          .r,
                                    );
                                  },
                                  itemCount: value.result!.tag.length,
                                ),
                              ),
                            );
                          },
                          alignment: Alignment.bottomCenter,
                        );
                      } else {
                        SmartDialog.dismiss();
                      }
                    },
                  );
                }
              },
            ),
          ),
          10.horizontalSpace,
          GestureDetector(
            onTap: () {
              Navigator.of(context).pop();
            },
            child: Text(
              "取消",
              style: TextStyle(
                color: Colors.black,
                fontSize: HYAppTheme.xSmallFontSize,
              ),
            ),
          )
        ],
      ),
    );
  }

  ///推荐搜索的关键词
  Widget buildSearchRecommend() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10).r,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ///b站热搜
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "B站热搜",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: HYAppTheme.xSmallFontSize,
                ),
              ),
              Text(
                "完整榜单 > ",
                style: TextStyle(
                  color: HYAppTheme.norGrayColor,
                  fontSize: HYAppTheme.xxSmallFontSize,
                ),
              ),
            ],
          ),

          ///热搜列表
          15.verticalSpace,
          _trendingList.isNotEmpty
              ? GridView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 200.w,
                    mainAxisExtent: 20.h,
                    mainAxisSpacing: 15.r,
                    crossAxisSpacing: 15.r,
                  ),
                  itemBuilder: (ctx, index) {
                    String _searchItemText = _trendingList[index].showName;
                    return GestureDetector(
                      onTap: () {
                        finishInputAndStartSearch(_searchItemText);
                      },
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            child: Text(
                              noMoreN(_searchItemText, 10),
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: HYAppTheme.xxSmallFontSize,
                              ),
                            ),
                          ),
                          5.horizontalSpace,
                          _trendingList[index].icon == null
                              ? Container()
                              : Image.network(
                                  _trendingList[index].icon!,
                                  width: 15.r,
                                  height: 15.r,
                                ),
                        ],
                      ),
                    );
                  },
                  itemCount: _trendingList.length,
                )
              : SizedBox(
                  height: 200.h,
                  child: Center(
                    child: SizedBox(
                      width: 30.r,
                      height: 30.r,
                      child: const CircularProgressIndicator(
                        color: HYAppTheme.norMainThemeColors,
                      ),
                    ),
                  ),
                )
        ],
      ),
    );
  }

  ///搜索结果
  Widget buildSearchResult() {
    List<Widget> _mainTabs = [];
    List<Widget> _subTabs = [];
    List<SearchResultDataItem> _items = _searchResult.data.item!;

    _mainTabs.add(Tab(text: "综合", height: 30.h));
    for (var item in _searchResult.data.nav) {
      String _num = item.total > 99 ? "99+" : item.total.toString();
      item.total > 0
          ? _mainTabs.add(Tab(text: "${item.name}($_num)", height: 30.h))
          : _mainTabs.add(Tab(text: item.name, height: 30.h));
    }
    _subTabs.add(Tab(text: "默认排序", height: 40.h));
    _subTabs.add(Tab(text: "新发布", height: 40.h));
    _subTabs.add(Tab(text: "播放多", height: 40.h));
    _subTabs.add(Tab(text: "弹幕多", height: 40.h));

    ///头部的（综合番剧用户直播影视）分类；（默认排序新发布播放多弹幕多）子分类
    ///主分类
    ///次分类
    List<Widget> staggeredGridChildren = [
      TabBar(
        tabs: _mainTabs,
        controller: _mainTabController,
        indicatorColor: HYAppTheme.norMainThemeColors,
        unselectedLabelColor: HYAppTheme.unselectedLabelColor,
        labelColor: HYAppTheme.norMainThemeColors,
        indicatorSize: TabBarIndicatorSize.label,
        labelStyle: const TextStyle(fontWeight: FontWeight.bold),
        unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.normal),
        indicatorWeight: 2.h,
        isScrollable: true,
      ),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          SizedBox(
            width: 0.7.sw,
            child: TabBar(
              tabs: _subTabs,
              indicator: const BoxDecoration(),
              controller: _subTabController,
              indicatorColor: HYAppTheme.norMainThemeColors,
              unselectedLabelColor: HYAppTheme.unselectedLabelColor,
              labelColor: HYAppTheme.norMainThemeColors,
              indicatorSize: TabBarIndicatorSize.label,
              labelStyle: TextStyle(fontSize: HYAppTheme.xxSmallFontSize),
              unselectedLabelStyle:
                  TextStyle(fontSize: HYAppTheme.xxSmallFontSize),
              labelPadding: EdgeInsets.zero,
            ),
          ),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 1.w,
                height: 15.h,
                color: HYAppTheme.norGrayColor.withOpacity(.5),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 10.r),
                child: Text(
                  "筛选",
                  style: TextStyle(
                      color: HYAppTheme.norGrayColor,
                      fontSize: HYAppTheme.xxSmallFontSize),
                ),
              ),
              Image.asset(
                ImageAssets.icFilterPNG,
                width: HYAppTheme.xxSmallFontSize,
                height: HYAppTheme.xxSmallFontSize,
              ),
            ],
          )
        ],
      ),
    ];

    ///搜索结果数据
    for (var item in _items) {
      Widget _child;
      if (item.linktype == "live") {
        ///直播类型的数据
        _child = GestureDetector(
          onTap: () {
            Navigator.of(context).pushNamed(HYLiveRoomPlayScreen.routeName,
                arguments: item.roomid!);
          },
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 15.r),
            decoration: BoxDecoration(
                border: BorderDirectional(
                    bottom: BorderSide(
                        color: HYAppTheme.norGrayColor.withOpacity(.1)))),
            child: Row(
              children: [
                ///封面
                Stack(
                  children: [
                    SizedBox(
                      width: 150.w,
                      height: 90.h,
                      child: ClipRRect(
                        borderRadius:
                            BorderRadius.all(const Radius.circular(4).r),
                        child: FadeInImage(
                          fit: BoxFit.fill,
                          placeholderFit: BoxFit.fill,
                          placeholder:
                              AssetImage(ImageAssets.icUpperVideoDefaultPNG),
                          image: NetworkImage(
                            item.cover,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      right: 5.w,
                      top: 5.h,
                      child: Container(
                        child: Text(
                          item.badge!,
                          style: TextStyle(
                            fontSize: HYAppTheme.xxxSmallFontSize,
                            color: Colors.white,
                          ),
                        ),
                        decoration: BoxDecoration(
                            color: HYAppTheme.norMainThemeColors,
                            borderRadius:
                                BorderRadius.all(const Radius.circular(3).r)),
                        padding: const EdgeInsets.symmetric(horizontal: 3).r,
                      ),
                    ),
                  ],
                ),
                10.horizontalSpace,

                ///右侧视频信息
                Expanded(
                  child: SizedBox(
                    height: 90.h,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: HYAppTheme.xxSmallFontSize),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Image.asset(
                                  ImageAssets.upGrayPNG,
                                  width: HYAppTheme.xxSmallFontSize,
                                  height: HYAppTheme.xxSmallFontSize,
                                ),
                                5.horizontalSpace,
                                Text(
                                  item.author != null
                                      ? item.author!
                                      : item.name!,
                                  style: TextStyle(
                                    color: HYAppTheme.norGrayColor,
                                    fontSize: HYAppTheme.xxSmallFontSize,
                                  ),
                                ),
                              ],
                            ),
                            4.verticalSpace,
                            item.online != null
                                ? Row(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Image.asset(ImageAssets.viewGrayPNG,
                                          width: HYAppTheme.xxSmallFontSize,
                                          height: HYAppTheme.xxSmallFontSize),
                                      5.horizontalSpace,
                                      Text(
                                        changeToWan(item.online!),
                                        style: TextStyle(
                                          fontSize: HYAppTheme.xxxSmallFontSize,
                                          color: HYAppTheme.norGrayColor,
                                        ),
                                      ),
                                    ],
                                  )
                                : Container()
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      } else if (item.linktype == "channel") {
        ///频道类型的数据
        _child = Container(
          padding: EdgeInsets.symmetric(vertical: 15.r),
          decoration: BoxDecoration(
              border: BorderDirectional(
                  bottom: BorderSide(
                      color: HYAppTheme.norGrayColor.withOpacity(.1)))),
          child: Column(
            children: [
              Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(3).r),
                    child: Image.network(
                      item.cover,
                      width: 43.r,
                      height: 43.r,
                    ),
                  ),
                  10.horizontalSpace,
                  Expanded(
                    child: Container(
                      height: 43.r,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                item.title,
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: HYAppTheme.xxSmallFontSize,
                                ),
                              ),
                              5.horizontalSpace,
                              Image.network(
                                item.typeIcon!,
                                width: HYAppTheme.xxSmallFontSize,
                                height: HYAppTheme.xxSmallFontSize,
                              ),
                            ],
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                item.channelLabel1!.text,
                                style: TextStyle(
                                  color: HYAppTheme.norMainThemeColors,
                                  fontSize: HYAppTheme.xxxSmallFontSize,
                                ),
                              ),
                              10.horizontalSpace,
                              Text(
                                item.channelLabel2!.text,
                                style: TextStyle(
                                  color: HYAppTheme.norMainThemeColors,
                                  fontSize: HYAppTheme.xxxSmallFontSize,
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(vertical: 2, horizontal: 4).r,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(3).r),
                        border: Border.all(
                            color: HYAppTheme.norMainThemeColors, width: 1.r)),
                    child: Text(
                      item.channelButton!.text,
                      style: TextStyle(
                        color: HYAppTheme.norMainThemeColors,
                        fontSize: HYAppTheme.xxSmallFontSize,
                      ),
                    ),
                  ),
                  15.horizontalSpace,
                ],
              ),
              15.verticalSpace,
              item.items![0].goto! == "av"
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        buildChannelVideo(item, 0),
                        buildChannelVideo(item, 1),
                        buildChannelVideo(item, 2),
                      ],
                    )
                  : GridView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                        maxCrossAxisExtent: 70.r,
                        mainAxisSpacing: 10.r,
                      ),
                      itemBuilder: (ctx, i) {
                        return Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            ClipRRect(
                              child: Image.network(
                                item.items![i].cover!,
                                width: 35.r,
                                height: 35.r,
                              ),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(3).r),
                            ),
                            5.verticalSpace,
                            Text(
                              item.items![i].title!,
                              style: TextStyle(
                                fontSize: HYAppTheme.xxSmallFontSize,
                              ),
                            ),
                          ],
                        );
                      },
                      itemCount: item.items!.length,
                    ),
            ],
          ),
        );
      } else if (item.linktype == "app_user") {
        ///用户
        _child = Container(
          padding: EdgeInsets.symmetric(vertical: 15.r),
          decoration: BoxDecoration(
              border: BorderDirectional(
                  bottom: BorderSide(
                      color: HYAppTheme.norGrayColor.withOpacity(.1)))),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Container(
                    child: CircleAvatar(
                      backgroundImage: NetworkImage(item.cover),
                      radius: 22.r,
                    ),
                    padding:
                        EdgeInsets.only(left: 4, top: 4, bottom: 4, right: 8).r,
                  ),
                  Expanded(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              item.title,
                              style: TextStyle(
                                  fontSize: HYAppTheme.xxSmallFontSize,
                                  fontWeight: FontWeight.bold,
                                  color: HYAppTheme.norMainThemeColors),
                            ),
                            4.horizontalSpace,
                            HYUserLevel(level: item.level!)
                          ],
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              "粉丝:${changeToWan(item.fans!)}   视频:${changeToWan(item.archives!)}",
                              style: TextStyle(
                                fontSize: HYAppTheme.xxSmallFontSize,
                                color: HYAppTheme.norGrayColor,
                              ),
                            )
                          ],
                        ),
                        item.officialVerify!.desc != null
                            ? Text(
                                item.officialVerify!.desc!,
                                style: TextStyle(
                                  fontSize: HYAppTheme.xxSmallFontSize,
                                  color: HYAppTheme.norGrayColor,
                                ),
                              )
                            : Container()
                      ],
                      crossAxisAlignment: CrossAxisAlignment.start,
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2).r,
                    child: Text(
                      "+关注",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: HYAppTheme.xSmallFontSize,
                      ),
                    ),
                  ),
                  Image.asset(
                    ImageAssets.videoMoreCustomPNG,
                    width: HYAppTheme.smallFontSize,
                    height: HYAppTheme.smallFontSize,
                  ),
                ],
              ),
              15.verticalSpace,

              ///前三个视频
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  buildAppUserVideo(item, 0),
                  buildAppUserVideo(item, 1),
                  buildAppUserVideo(item, 2),
                ],
              ),
              15.verticalSpace,
              Text(
                "查看全部${item.archives}个视频>",
                style: TextStyle(
                  color: HYAppTheme.norMainThemeColors,
                  fontSize: HYAppTheme.xxSmallFontSize,
                ),
              ),
            ],
          ),
        );
      } else if (item.linktype == "esports") {
        ///赛事
        _child = Container(
          padding: EdgeInsets.only(bottom: 15, left: 5, right: 5).r,
          decoration: BoxDecoration(
              border: BorderDirectional(
                  bottom: BorderSide(
                      color: HYAppTheme.norGrayColor.withOpacity(.3)))),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                color: HYAppTheme.norBlue03Colors,
                width: 1.sw,
                height: 40.h,
                padding: const EdgeInsets.only(
                        left: 15, right: 10, top: 4, bottom: 4)
                    .r,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Image.network(
                            item.cover,
                            width: 40.r,
                            height: 40.r,
                            fit: BoxFit.cover,
                          ),
                          Text(
                            item.title,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: HYAppTheme.xSmallFontSize,
                            ),
                          ),
                        ],
                      ),
                      padding: EdgeInsets.symmetric(vertical: 4.r),
                    ),
                    Container(
                      decoration: BoxDecoration(
                          color: Colors.transparent,
                          border: Border.all(color: Colors.white),
                          borderRadius: BorderRadius.all(Radius.circular(4).r)),
                      child: Text(
                        "赛事专题>",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: HYAppTheme.xxSmallFontSize,
                        ),
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 3.r),
                    )
                  ],
                ),
              ),
              10.verticalSpace,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      15.verticalSpace,
                      Image.network(
                        item.items![0].team1!.cover,
                        width: 45.r,
                        height: 45.r,
                      ),
                      25.verticalSpace,
                      Text(
                        item.items![0].team1!.title,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: HYAppTheme.xxSmallFontSize,
                        ),
                      )
                    ],
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        item.items![0].matchStage!,
                        style: TextStyle(
                          fontSize: HYAppTheme.xxxSmallFontSize,
                        ),
                      ),
                      10.verticalSpace,
                      Text(
                        "${item.items![0].team1!.score ?? "0"} : ${item.items![0].team2!.score ?? "0"}",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: HYAppTheme.hugeFontSize,
                        ),
                      ),
                      5.verticalSpace,
                      item.items![0].matchLabel != null
                          ? Text(
                              item.items![0].matchLabel!.text,
                              style: TextStyle(
                                color: HYAppTheme.norMainThemeColors,
                                fontSize: HYAppTheme.xxxSmallFontSize,
                              ),
                            )
                          : Container(),
                      5.verticalSpace,
                      Container(
                        padding: const EdgeInsets.symmetric(
                                vertical: 4, horizontal: 8)
                            .r,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Image.asset(
                              ImageAssets.onlinePNG,
                              width: HYAppTheme.xxxSmallFontSize,
                              height: HYAppTheme.xxxSmallFontSize,
                            ),
                            4.horizontalSpace,
                            Text(
                              item.items![0].matchButton!.text,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: HYAppTheme.xSmallFontSize,
                              ),
                            )
                          ],
                        ),
                        decoration: BoxDecoration(
                            color: HYAppTheme.norMainThemeColors,
                            borderRadius:
                                BorderRadius.all(Radius.circular(4).r)),
                      )
                    ],
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      15.verticalSpace,
                      Image.network(
                        item.items![0].team2!.cover,
                        width: 45.r,
                        height: 45.r,
                      ),
                      25.verticalSpace,
                      Text(
                        item.items![0].team2!.title,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: HYAppTheme.xxSmallFontSize,
                        ),
                      )
                    ],
                  ),
                ],
              ),
              10.verticalSpace,
              Divider(
                color: HYAppTheme.norGrayColor.withOpacity(.3),
              ),
              10.verticalSpace,
              buildESportsRow(item, 1),
              15.verticalSpace,
              buildESportsRow(item, 2),
              20.verticalSpace,
              Row(
                children: [
                  buildESportsBottomButton("全部赛事"),
                  buildESportsBottomButton("赛事视频"),
                  buildESportsBottomButton("征稿活动"),
                  buildESportsBottomButton("赛事话题"),
                ],
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              ),
            ],
          ),
        );
      } else if (item.linktype == "video") {
        ///video视频类的数据
        _child = GestureDetector(
          onTap: () {
            ///播放视频需要接受grpc型数据
            ///数据类型不符合，先放着
          },
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 10.r, horizontal: 5.r),
            decoration: BoxDecoration(
                border: BorderDirectional(
                    bottom: BorderSide(
                        color: HYAppTheme.norGrayColor.withOpacity(.1)))),
            child: Row(
              children: [
                ///封面
                Stack(
                  children: [
                    SizedBox(
                      width: 150.w,
                      height: 90.h,
                      child: ClipRRect(
                        borderRadius:
                            BorderRadius.all(const Radius.circular(4).r),
                        child: FadeInImage(
                          fit: BoxFit.fill,
                          placeholderFit: BoxFit.fill,
                          placeholder:
                              AssetImage(ImageAssets.icUpperVideoDefaultPNG),
                          image: NetworkImage(
                            item.cover,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      right: 5.w,
                      bottom: 5.h,
                      child: Container(
                        child: Text(
                          item.duration!,
                          style: TextStyle(
                            fontSize: HYAppTheme.xxxSmallFontSize,
                            color: Colors.white,
                          ),
                        ),
                        decoration: BoxDecoration(
                            color: Colors.black.withOpacity(.6),
                            borderRadius:
                                BorderRadius.all(Radius.circular(3).r)),
                        padding: EdgeInsets.symmetric(horizontal: 3).r,
                      ),
                    ),
                  ],
                ),
                10.horizontalSpace,

                ///右侧视频信息
                Expanded(
                  child: SizedBox(
                    height: 90.h,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        HYHighlightStrInText(
                          originalText: item.title,
                          highlightText: _searchKeywordText,
                          highlightColor: HYAppTheme.norMainThemeColors,
                          originalColor: Colors.black,
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Image.asset(
                                  ImageAssets.upGrayPNG,
                                  width: HYAppTheme.xxSmallFontSize,
                                  height: HYAppTheme.xxSmallFontSize,
                                ),
                                5.horizontalSpace,
                                Text(
                                  item.author!,
                                  style: TextStyle(
                                    color: HYAppTheme.norGrayColor,
                                    fontSize: HYAppTheme.xxSmallFontSize,
                                  ),
                                ),
                              ],
                            ),
                            2.verticalSpace,
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Image.asset(ImageAssets.iconListPlayerPNG,
                                        width: HYAppTheme.xxSmallFontSize,
                                        height: HYAppTheme.xxSmallFontSize),
                                    5.horizontalSpace,
                                    Text(
                                      "${changeToWan(item.play!)}${item.showCardDesc2}",
                                      style: TextStyle(
                                        fontSize: HYAppTheme.xxxSmallFontSize,
                                        color: HYAppTheme.norGrayColor,
                                      ),
                                    ),
                                  ],
                                ),
                                Image.asset(ImageAssets.videoMoreCustomPNG,
                                    width: HYAppTheme.xxSmallFontSize,
                                    height: HYAppTheme.xxSmallFontSize),
                              ],
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      } else if (item.linktype == "bgm_media") {
        List<Widget> _rowChildren = [];
        if (item.episodesNew!.length > 6) {
          for (int i = 0; i < 6; i++) {
            Widget _child;
            if (i == 0 || i == 1) {
              _child = buildNumberContainer(i.toString());
            } else if (i == 3) {
              _child = buildNumberContainer(
                  (item.episodesNew!.length - 3).toString());
            } else if (i == 4) {
              _child = buildNumberContainer(
                  (item.episodesNew!.length - 2).toString());
            } else if (i == 5) {
              _child = buildNumberContainer(
                  (item.episodesNew!.length - 1).toString());
            } else {
              _child = buildNumberContainer("...");
            }
            _rowChildren.add(_child);
          }
        } else {
          for (var i in item.episodesNew!) {
            _rowChildren.add(buildNumberContainer(i.title));
          }
        }

        ///番剧
        _child = Container(
          padding: EdgeInsets.symmetric(vertical: 15.r),
          decoration: BoxDecoration(
              border: BorderDirectional(
                  bottom: BorderSide(
                      color: HYAppTheme.norGrayColor.withOpacity(.1)))),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(4).r),
                    child: Image.network(
                      item.cover,
                      width: 90.w,
                      height: 120.h,
                      fit: BoxFit.contain,
                    ),
                  ),
                  10.horizontalSpace,
                  Expanded(
                    child: Container(
                      height: 120.h,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: HYAppTheme.xSmallFontSize,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black),
                              ),
                              Text(
                                item.styles!,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: HYAppTheme.xxSmallFontSize,
                                    color: HYAppTheme.norGrayColor),
                              ),
                              Text(
                                item.style!,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: HYAppTheme.xxSmallFontSize,
                                    color: HYAppTheme.norGrayColor),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Container(
                                child: Text(
                                  item.watchButton!.title,
                                  style: TextStyle(
                                      fontSize: HYAppTheme.xSmallFontSize,
                                      color: HYAppTheme.norMainThemeColors),
                                ),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(
                                        width: 1.r,
                                        color: HYAppTheme.norMainThemeColors),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(3.r))),
                                padding: EdgeInsets.symmetric(
                                        horizontal: 6, vertical: 2)
                                    .r,
                              ),
                              10.horizontalSpace,
                              Container(
                                child: Row(
                                  children: [
                                    Image.network(
                                      item.followButton!.icon,
                                      width: HYAppTheme.xSmallFontSize,
                                      height: HYAppTheme.xSmallFontSize,
                                    ),
                                    Text(
                                      item.followButton!.texts["0"]!,
                                      style: TextStyle(
                                          fontSize: HYAppTheme.xSmallFontSize,
                                          color: Colors.white),
                                    ),
                                  ],
                                  mainAxisSize: MainAxisSize.min,
                                ),
                                decoration: BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(3.r)),
                                  color: HYAppTheme.norMainThemeColors,
                                ),
                                padding: EdgeInsets.symmetric(
                                        horizontal: 6, vertical: 2)
                                    .r,
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(
                              text: item.rating.toString(),
                              style: TextStyle(
                                  fontSize: HYAppTheme.normalFontSize,
                                  color: HYAppTheme.norYellow02Colors),
                            ),
                            TextSpan(
                              text: "分",
                              style: TextStyle(
                                  fontSize: HYAppTheme.xxSmallFontSize,
                                  color: HYAppTheme.norYellow02Colors),
                            ),
                          ],
                        ),
                      ),
                      Text(
                        item.vote.toString() + "人",
                        style: TextStyle(
                            fontSize: HYAppTheme.xxxSmallFontSize,
                            color: HYAppTheme.norGrayColor),
                      ),
                    ],
                  )
                ],
              ),
              10.verticalSpace,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: _rowChildren,
              ),
            ],
          ),
        );
      } else {
        return Container();
      }
      staggeredGridChildren.add(_child);
    }
    return Expanded(
      child: EasyRefresh(
        child: StaggeredGrid.count(
          crossAxisCount: 1,
          children: staggeredGridChildren,
        ),
      ),
    );
  }

  Widget buildAppUserVideo(SearchResultDataItem item, int position) {
    return Container(
      width: 108.w,
      height: 130.h,
      decoration:
          BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(3).r)),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ///封面
          Stack(
            children: [
              SizedBox(
                width: 108.w,
                height: 70.h,
                child: ClipRRect(
                  borderRadius: BorderRadius.all(const Radius.circular(4).r),
                  child: FadeInImage(
                    fit: BoxFit.fill,
                    placeholderFit: BoxFit.fill,
                    placeholder: AssetImage(ImageAssets.icUpperVideoDefaultPNG),
                    image: NetworkImage(
                      item.avItems![position].cover,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 5.w,
                bottom: 5.h,
                child: Row(
                  children: [
                    Image.asset(ImageAssets.icPlayVideoWhitePNG,
                        width: HYAppTheme.xSmallFontSize,
                        height: HYAppTheme.xSmallFontSize),
                    3.horizontalSpace,
                    Text(
                      changeToWan(item.avItems![position].play),
                      style: TextStyle(
                        fontSize: HYAppTheme.xxxSmallFontSize,
                        color: Colors.white,
                      ),
                    ),
                  ],
                  mainAxisSize: MainAxisSize.min,
                ),
              ),
            ],
          ),

          ///标题
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4, vertical: 5).r,
            child: Text(
              item.avItems![position].title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.black,
                fontSize: HYAppTheme.xxxSmallFontSize,
              ),
            ),
          ),

          ///发布时间
          Text(
            item.avItems![position].ctimeLabel,
            style: TextStyle(
              color: HYAppTheme.norGrayColor,
              fontSize: HYAppTheme.xxxSmallFontSize,
            ),
          )
        ],
      ),
    );
  }

  Widget buildChannelVideo(SearchResultDataItem item, int position) {
    return Container(
      width: 108.w,
      height: 115.h,
      decoration:
          BoxDecoration(borderRadius: BorderRadius.all(Radius.circular(3).r)),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ///封面
          Stack(
            children: [
              SizedBox(
                width: 108.w,
                height: 70.h,
                child: ClipRRect(
                  borderRadius: BorderRadius.all(const Radius.circular(4).r),
                  child: FadeInImage(
                    fit: BoxFit.fill,
                    placeholderFit: BoxFit.fill,
                    placeholder: AssetImage(ImageAssets.icUpperVideoDefaultPNG),
                    image: NetworkImage(
                      item.items![position].cover!,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 5.w,
                bottom: 5.h,
                child: Row(
                  children: [
                    Image.asset(ImageAssets.icPlayVideoWhitePNG,
                        width: HYAppTheme.xSmallFontSize,
                        height: HYAppTheme.xSmallFontSize),
                    3.horizontalSpace,
                    Text(
                      item.items![position].coverLeftText1!,
                      style: TextStyle(
                        fontSize: HYAppTheme.xxxSmallFontSize,
                        color: Colors.white,
                      ),
                    ),
                  ],
                  mainAxisSize: MainAxisSize.min,
                ),
              ),
            ],
          ),

          ///标题
          Container(
            padding: EdgeInsets.symmetric(horizontal: 4, vertical: 5).r,
            child: Text(
              item.items![position].title!,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.black,
                fontSize: HYAppTheme.xxxSmallFontSize,
              ),
            ),
          ),
        ],
      ),
    );
  }

  ///第2,3条赛事
  Widget buildESportsRow(SearchResultDataItem item, int index) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Text(
          item.items![index].matchTime!.text,
          style: TextStyle(
            fontSize: HYAppTheme.xxSmallFontSize,
          ),
        ),
        Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(noMoreN(item.items![index].team1!.title, 5),
                style: TextStyle(
                  fontSize: HYAppTheme.xxSmallFontSize,
                )),
            20.horizontalSpace,
            Text("VS",
                style: TextStyle(
                  fontSize: HYAppTheme.xxSmallFontSize,
                  color: HYAppTheme.norGrayColor,
                )),
            20.horizontalSpace,
            Text(
              noMoreN(item.items![index].team2!.title, 5),
              style: TextStyle(
                fontSize: HYAppTheme.xxSmallFontSize,
              ),
            ),
          ],
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 20.r, vertical: 3.r),
          child: Text(
            item.items![index].matchButton!.text,
            style: TextStyle(
              color: HYAppTheme.norMainThemeColors,
              fontSize: HYAppTheme.xxSmallFontSize,
            ),
          ),
          decoration: BoxDecoration(
              border: Border.all(
                color: HYAppTheme.norMainThemeColors,
              ),
              color: Colors.white,
              borderRadius: BorderRadius.all(Radius.circular(4.r))),
        ),
      ],
    );
  }

  ///全部赛事、赛事视频、征稿活动、赛事话题
  Widget buildESportsBottomButton(String title) {
    return Container(
      child: Text(
        title,
        style: TextStyle(
          color: Colors.black,
          fontSize: HYAppTheme.xxSmallFontSize,
        ),
      ),
      padding: EdgeInsets.symmetric(horizontal: 15, vertical: 4).r,
      decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: HYAppTheme.norGrayColor.withOpacity(.3))),
    );
  }

  Widget buildNumberContainer(String num) {
    return Container(
      decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(4).r),
          border: Border.all(
            color: HYAppTheme.norGrayColor.withOpacity(.15),
          )),
      alignment: Alignment.center,
      child: Text(num),
      width: 45.r,
      height: 45.r,
    );
  }

  ///完成输入并开始搜索，获取所有结果
  void finishInputAndStartSearch(String text) {
    _searchKeywordText = text;

    ///关闭弹框
    SmartDialog.dismiss();

    ///设置文本
    _textEditingController.text = text;

    ///失去焦点
    unFocusFunction();

    ///隐藏键盘
    hideKeyBoard();

    ///获取搜索的结果
    HYSearchRequest.getSearchResultData(text).then((_searchResultData) {
      setState(() {
        ///显示搜索结果
        _showResult = true;
        _searchResult = _searchResultData;
      });
    });
  }

  ///获取焦点
  void getFocusFunction(BuildContext context) {
    FocusScope.of(context).requestFocus(_focusNode);
  }

  ///失去焦点
  void unFocusFunction() {
    _focusNode.unfocus();
  }

  ///隐藏键盘而不丢失文本字段焦点：
  void hideKeyBoard() {
    SystemChannels.textInput.invokeMethod('TextInput.hide');
  }
}
