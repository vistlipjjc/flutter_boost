import 'package:flutter/material.dart';
import 'live_room_play_content.dart';

class HYLiveRoomPlayScreen extends StatelessWidget {
  static String routeName = "/live_room_play";

  const HYLiveRoomPlayScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // LiveRoomModel _liveRoomData =
    //     ModalRoute.of(context)?.settings.arguments as LiveRoomModel;
    int _roomId = ModalRoute.of(context)?.settings.arguments as int;
    return SafeArea(
      child: HYLiveRoomPlayContent(_roomId),
    );
  }
}
