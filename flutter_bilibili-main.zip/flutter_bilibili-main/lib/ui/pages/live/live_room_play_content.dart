import 'dart:async';

import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bilibili/core/model/live_room_model.dart';
import 'package:flutter_bilibili/core/model/online_gold_rank_model.dart';
import 'package:flutter_bilibili/core/service/request/live_room_play_request.dart';
import 'package:flutter_bilibili/ui/shared/image_assets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:video_player/video_player.dart';
import '../../shared/app_theme.dart';
import 'live_dan_mu.dart';

class HYLiveRoomPlayContent extends StatefulWidget {
  int roomId;

  HYLiveRoomPlayContent(this.roomId, {Key? key})
      : super(key: key); // LiveRoomModel liveRoomData;

  // HYLiveRoomPlayContent(this.liveRoomData, {Key? key}) : super(key: key);

  @override
  State<HYLiveRoomPlayContent> createState() => _HYLiveRoomPlayContentState();
}

class _HYLiveRoomPlayContentState extends State<HYLiveRoomPlayContent> {
  late VideoPlayerController _videoPlayerController;
  late ChewieController _chewieController;
  bool isLoadingAccomplished = false;
  late Timer _timer;

  String userName = "获取中...";
  String userFace = "";
  int onlineNum = 0;
  List<OnlineRankItem> top4UserFace = [];
  String watchedShow = "0人看过";

  @override
  void initState() {
    ///顶部状态蓝颜色
    // SystemUiOverlayStyle systemUiOverlayStyle =
    //     const SystemUiOverlayStyle(statusBarColor: HYAppTheme.norTextColors);
    // SystemChrome.setSystemUIOverlayStyle(systemUiOverlayStyle);

    ///每隔一段时间获取实时人气
    _timer = Timer.periodic(const Duration(seconds: 5), (t) {
      ///请求直播间基本信息,主播基本信息
      HYLiveRoomPlayRequest.getInfoByLiveRoomData(widget.roomId).then((value) {
        userName = value.anchorInfo.baseInfo.uname;
        userFace = value.anchorInfo.baseInfo.face;
        watchedShow = value.watchedShow.textLarge;
        if (mounted) {
          setState(() {});
        }
      });

      // ///前四高能榜
      // HYLiveRoomPlayRequest.getOnlineGoldRankData(
      //         widget.upId, widget.roomId, 1, 4)
      //     .then((value) {
      //   onlineNum = value.onlineNum;
      //   top4UserFace.addAll(value.onlineRankItem);
      //   if (mounted) {
      //     setState(() {});
      //   }
      // });
    });

    ///请求直播间基本信息,主播基本信息
    HYLiveRoomPlayRequest.getInfoByLiveRoomData(widget.roomId).then((value) {
      userName = value.anchorInfo.baseInfo.uname;
      userFace = value.anchorInfo.baseInfo.face;
      watchedShow = value.watchedShow.textLarge;
      if (mounted) {
        setState(() {});
      }
    });

    // ///前四高能榜
    // HYLiveRoomPlayRequest.getOnlineGoldRankData(
    //         widget.upId, widget.roomid, 1, 4)
    //     .then((value) {
    //   onlineNum = value.onlineNum;
    //   top4UserFace.addAll(value.onlineRankItem);
    //   if (mounted) {
    //     setState(() {});
    //   }
    // });

    ///请求视频直播
    HYLiveRoomPlayRequest.getLiveRoomStreamData(widget.roomId).then((value) {
      ///线路一
      _videoPlayerController = VideoPlayerController.network(value.durl[0].url);
      _videoPlayerController.initialize().then((value) {
        _chewieController = ChewieController(
          autoPlay: true,
          videoPlayerController: _videoPlayerController,
          isLive: true,
          allowMuting: false,
        );
        isLoadingAccomplished = true;
        if (mounted) {
          setState(() {});
        }
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    _timer.cancel();
    _videoPlayerController.dispose();
    _chewieController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: HYAppTheme.norTextColors,
        body: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            buildLiveRoomPlayAppBarTitle(),
            buildLiveRoomPlayRanking(),
            10.verticalSpace,
            buildLiveRoomPlayLivePlayer(),
            Expanded(
              child: buildLiveRoomPlayLiveDanMuPanel(),
            ),
          ],
        ),
        bottomNavigationBar: buildLiveRoomPlayBottomSendDanMu(),
      ),
    );
  }

  ///顶部的appBar的内容
  Widget buildLiveRoomPlayAppBarTitle() {
    return Container(
      color: HYAppTheme.norTextColors,
      height: 70.h,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10).r,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            child: Image.asset(
              ImageAssets.biliPlayerBackButtonPNG,
              width: HYAppTheme.normalFontSize,
              height: HYAppTheme.normalFontSize,
            ),
            padding: const EdgeInsets.only(top: 5, right: 5, bottom: 5).r,
          ),
          userFace.isEmpty
              ? CircleAvatar(
            radius: 15.r,
                  backgroundImage: AssetImage(
                    ImageAssets.icRecommendAvatarPNG,
                  ),
                )
              : CircleAvatar(
                  radius: 15.r,
                  backgroundImage: NetworkImage(
                    userFace,
                  ),
                ),
          3.horizontalSpace,
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 2).r,
            width: 65.w,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  userName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: HYAppTheme.xxSmallFontSize,
                      color: Colors.white),
                ),
                Text(
                  watchedShow,
                  maxLines: 1,
                  style: TextStyle(
                      fontSize: HYAppTheme.xxxSmallFontSize,
                      color: Colors.white),
                ),
              ],
            ),
          ),
          3.horizontalSpace,
          Container(
            padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16).r,
            decoration: BoxDecoration(
                color: HYAppTheme.norPink02Colors,
                borderRadius: BorderRadius.all(Radius.circular(20.r))),
            child: Text(
              "+关注",
              style: TextStyle(
                  fontSize: HYAppTheme.xxSmallFontSize, color: Colors.white),
            ),
          ),
          10.horizontalSpace,
          // Expanded(
          //   child: Stack(
          //     alignment: Alignment.centerLeft,
          //     children: top4UserFace.isNotEmpty
          //         ? buildTop4User(top4UserFace)
          //         : buildTop4UserBg(top4UserFace),
          //   ),
          // ),
          Container(
            padding: const EdgeInsets.only(left: 10).r,
            child: Image.asset(
              ImageAssets.videoPlayerMoreCustomPNG,
              width: 20.w,
              height: 20.h,
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> buildTop4User(List<OnlineRankItem> top4UserFace) {
    List<Widget> _widgets = [];
    int leftDistance = 75;
    int i = 0;
    for (var item in top4UserFace) {
      _widgets.add(
        Positioned(
          left: leftDistance.w,
          child: CircleAvatar(
            radius: 15.r,
            backgroundImage: NetworkImage(top4UserFace[i].face),
          ),
        ),
      );
      leftDistance -= 25;
      i++;
    }
    _widgets.add(buildTop4UserLastWidget());
    return _widgets;
  }

  List<Widget> buildTop4UserBg(List<OnlineRankItem> top4UserFace) {
    List<Widget> _widgets = [];
    int leftDistance = 75;
    for (var item in top4UserFace) {
      _widgets.add(
        Positioned(
          left: leftDistance.w,
          child: CircleAvatar(
            radius: 18.r,
            backgroundImage: AssetImage(ImageAssets.icRecommendAvatarPNG),
          ),
        ),
      );
      leftDistance -= 25;
    }
    _widgets.add(buildTop4UserLastWidget());
    return _widgets;
  }

  Widget buildTop4UserLastWidget() {
    return Positioned(
      right: 0,
      child: Container(
        decoration: BoxDecoration(
            gradient: LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [
            HYAppTheme.norTextColors.withOpacity(.7),
            HYAppTheme.norTextColors
          ],
        )),
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 13).r,
        child: Center(
          child: Text(
            onlineNum.toString(),
            style: TextStyle(
                color: Colors.white, fontSize: HYAppTheme.xxSmallFontSize),
          ),
        ),
      ),
    );
  }

  Widget buildLiveRoomPlayAppBarActions() {
    return Image.asset("assets/image/icon/video_more.png",
        width: 15.w, height: 15.h);
  }

  Widget buildLiveRoomPlayAppBarLeading() {
    return Image.asset(
      "assets/image/icon/bili_player_back_button.png",
      width: 15.w,
      height: 15.h,
    );
  }

  Widget buildLiveRoomPlayLivePlayer() {
    return Container(
      color: HYAppTheme.norTextColors,
      height: 250.h,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 5).r,
      child: isLoadingAccomplished == true
          ? AspectRatio(
              aspectRatio:
                  _chewieController.videoPlayerController.value.aspectRatio,
              child: Chewie(controller: _chewieController),
            )
          : Center(
              child: SizedBox(
                width: 40.w,
                height: 40.h,
                child: const CircularProgressIndicator(
                  color: HYAppTheme.norMainThemeColors,
                ),
              ),
            ),
    );
  }

  Widget buildLiveRoomPlayLiveDanMuPanel() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 30).r,
      child: LiveDanMuScreen(widget.roomId),
    );
  }

  Widget buildLiveRoomPlayBottomSendDanMu() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10).r,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          SizedBox(
            height: 30.h,
            width: 30.w,
            child: CircleAvatar(
              backgroundImage: AssetImage(ImageAssets.icRecommendAvatarPNG),
            ),
          ),
          Container(
            width: 200.w,
            height: 35.h,
            padding: const EdgeInsets.symmetric(horizontal: 15).r,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.3),
              borderRadius: BorderRadius.all(
                Radius.circular(30.r),
              ),
            ),
            child: TextField(
              showCursor: true,
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: "发个弹幕~",
                hintStyle: TextStyle(
                    color: Colors.white.withOpacity(.5),
                    fontSize: HYAppTheme.xxSmallFontSize),
              ),
            ),
          ),
          CircleAvatar(
            radius: 15.r,
            backgroundColor: HYAppTheme.norTextColors,
            backgroundImage: AssetImage(ImageAssets.facePNG),
          ),
          CircleAvatar(
            radius: 15.r,
            backgroundColor: HYAppTheme.norTextColors,
            backgroundImage: AssetImage(ImageAssets.hotActivityPNG),
          ),
          CircleAvatar(
            radius: 15.r,
            backgroundColor: HYAppTheme.norTextColors,
            backgroundImage: AssetImage(ImageAssets.giftPNG),
          ),
        ],
      ),
    );
  }
}

Widget buildLiveRoomPlayRanking() {
  return Container(
    padding: const EdgeInsets.only(left: 20).r,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(
            vertical: 5,
            horizontal: 12,
          ).r,
          child: Text(
            "热门榜 >",
            style: TextStyle(
              color: Colors.white,
              fontSize: HYAppTheme.xxxSmallFontSize,
            ),
          ),
          decoration: BoxDecoration(
              color: HYAppTheme.norPink03Colors,
              borderRadius: BorderRadius.all(Radius.circular(20.r))),
        ),
      ],
    ),
  );
}
