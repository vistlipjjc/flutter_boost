import 'package:flutter/material.dart';
import 'live_content.dart';

class HYLiveScreen extends StatelessWidget {
  const HYLiveScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const HYLiveContent();
  }
}
