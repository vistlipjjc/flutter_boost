import 'package:flutter/material.dart';
import 'package:flutter_bilibili/ui/pages/live/initialize_live.dart';
import 'package:flutter_bilibili/ui/pages/live/live_room_recommend.dart';
import 'package:flutter_bilibili/ui/shared/image_assets.dart';
import 'package:flutter_bilibili/ui/shared/platform_judge.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../shared/app_theme.dart';
import 'live_room_wzry.dart';

class HYLiveContent extends StatelessWidget {
  const HYLiveContent({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: liveTabTitle.length,
      child: Scaffold(
        appBar: AppBar(
          toolbarHeight: 45.h,
          centerTitle: PlatformJudge.platformJudgeIsPhone() ? false : true,
          elevation: 0,
          title: buildLiveTabBar(),
          backgroundColor: Colors.white,
        ),
        body: buildLiveTabBarView(),
      ),
    );
  }

  Widget buildLiveTabBar() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        SizedBox(
          width: .7.sw,
          child: TabBar(
            tabs: liveTabTitle.map((e) => Tab(text: e)).toList(),
            isScrollable: true,
            indicatorColor: Colors.transparent,
            labelStyle: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: HYAppTheme.xxSmallFontSize),
            unselectedLabelStyle: TextStyle(
                fontWeight: FontWeight.normal,
                fontSize: HYAppTheme.xxSmallFontSize),
            unselectedLabelColor: HYAppTheme.unselectedLabelColor,
            labelColor: HYAppTheme.norTextColors,
          ),
        ),
        Container(
          child: IconButton(
            onPressed: () {
              print("moreLive");
            },
            icon: Image.asset(
              ImageAssets.liveMoreCustomPNG,
              width: HYAppTheme.smallFontSize,
              height: HYAppTheme.smallFontSize,
            ),
          ),
        ),
      ],
    );
  }

  Widget buildLiveTabBarView() {
    return TabBarView(
        children: liveTabTitle.map((e) {
      if (e == '推荐') {
        return const HYLiveRecommendScreen();
      } else if (e == '颜值') {
        return Container();
      } else if (e == '英雄联盟') {
        return Container();
      } else if (e == '王者荣耀') {
        return const HYLiveWangZheRongYaoScreen();
      } else if (e == '虚拟主播') {
        return Container();
      } else if (e == 'LOL手游') {
        return Container();
      } else if (e == '电台') {
        return Container();
      } else if (e == '单机游戏') {
        return Container();
      } else if (e == '娱乐') {
        return Container();
      } else {
        return Container();
      }
    }).toList());
  }
}
