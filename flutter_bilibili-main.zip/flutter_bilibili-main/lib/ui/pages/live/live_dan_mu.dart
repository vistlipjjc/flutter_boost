import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../shared/app_theme.dart';
import '../../shared/platform_judge.dart';

class LiveDanMuScreen extends StatefulWidget {
  int roomId;

  LiveDanMuScreen(this.roomId, {Key? key}) : super(key: key);

  @override
  State<LiveDanMuScreen> createState() => _LiveDanMuScreenState();
}

class _LiveDanMuScreenState extends State<LiveDanMuScreen> {
  final Completer<WebViewController> _controller =
      Completer<WebViewController>();

  @override
  void initState() {
    super.initState();
    if (PlatformJudge.platformJudgeIsPhone()) {
      WebView.platform = SurfaceAndroidWebView();
    }
  }

  @override
  Widget build(BuildContext context) {
    return WebView(
      backgroundColor: HYAppTheme.norTextColors,
      initialUrl:
          'file:///android_asset/flutter_assets/assets/html/live_dan_mu.html?roomid=${widget.roomId}',
      zoomEnabled: false,
      javascriptMode: JavascriptMode.unrestricted,
      onWebViewCreated: (WebViewController webViewController) {
        _controller.complete(webViewController);
      },
      onProgress: (int progress) {
        print('WebView is loading (progress : $progress%)');
      },
    );
  }
}
