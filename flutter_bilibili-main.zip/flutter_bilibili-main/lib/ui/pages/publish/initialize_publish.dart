var publishTabList = ['开直播', '拍摄', '上传', '发动态', '模板创作'];
