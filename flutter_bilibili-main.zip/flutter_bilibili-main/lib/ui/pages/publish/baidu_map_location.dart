import 'package:flutter/material.dart';
import 'package:flutter_bilibili/ui/pages/publish/baidu_map_content.dart';

class HYBaiduMapLocationScreen extends StatelessWidget {
  static String routeName = "/baidu_map";

  const HYBaiduMapLocationScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const HYBaiduMapLocationContent();
  }
}
