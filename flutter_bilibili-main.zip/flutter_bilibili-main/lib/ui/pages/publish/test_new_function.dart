import 'package:flutter/material.dart';
import 'package:jpush_flutter/jpush_flutter.dart';

void main() async {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HYTest(),
    );
  }
}

class HYTest extends StatefulWidget {
  const HYTest({Key? key}) : super(key: key);

  @override
  State<HYTest> createState() => _HYTestState();
}

class _HYTestState extends State<HYTest> {
  JPush jPush = JPush();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
