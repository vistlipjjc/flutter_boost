import 'package:flutter/material.dart';
import 'package:flutter_bilibili/ui/pages/publish/ready_2_publish_content.dart';
import 'package:flutter_bilibili/ui/shared/app_theme.dart';
import 'package:flutter_bilibili/ui/widgets/rectangle_checkBox.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class HYReady2PublishScreen extends StatefulWidget {
  static const String routeName = "/ready_2_publish";

  HYReady2PublishScreen({Key? key}) : super(key: key);

  @override
  State<HYReady2PublishScreen> createState() => _HYReady2PublishScreenState();
}

class _HYReady2PublishScreenState extends State<HYReady2PublishScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: .8,
        leading: Icon(
          Icons.arrow_back_rounded,
          size: 20.sp,
          color: HYAppTheme.norTextColors,
        ),
      ),
      body: const HYReady2PublishContent(),
      bottomNavigationBar: buildReady2PublishBottomWidget(),
    );
  }

  ///预发布界面底部
  Widget buildReady2PublishBottomWidget() {
    var _flag = true;
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15).r,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            "如存在商业合作，需电脑网页端投稿并进行商业声明",
            style: TextStyle(
                color: HYAppTheme.norGrayColor,
                fontSize: HYAppTheme.xxSmallFontSize),
          ),
          8.verticalSpace,
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              RectangleCheckBox(
                size: 13.sp,
                checkedColor: HYAppTheme.norMainThemeColors,
                isChecked: _flag,
                onTap: (value) {
                  setState(() {
                    _flag = value!;
                  });
                },
              ),
              10.verticalSpace,
              Text(
                "我已经阅读并接收",
                style: TextStyle(
                    color: HYAppTheme.norTextColors,
                    fontSize: HYAppTheme.xxSmallFontSize),
              ),
              Text(
                "《哔哩哔哩创作公约》",
                style: TextStyle(
                    color: HYAppTheme.norMainThemeColors,
                    fontSize: HYAppTheme.xxSmallFontSize),
              ),
            ],
          ),
          8.verticalSpace,
          Row(
            children: [
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 5).r,
                padding:
                    const EdgeInsets.symmetric(vertical: 3, horizontal: 15).r,
                child: Image.asset(
                  "assets/image/icon/save_script.png",
                  width: 25.w,
                  height: 25.h,
                ),
                decoration: BoxDecoration(
                    border:
                        Border.all(color: HYAppTheme.norGrayColor, width: .2),
                    borderRadius: BorderRadius.all(Radius.circular(3.r))),
              ),
              Expanded(
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10).r,
                  child: TextButton(
                    onPressed: () {
                      ///点击发布
                    },
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(
                          HYAppTheme.norMainThemeColors),
                    ),
                    child: Text(
                      "发布",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: HYAppTheme.xSmallFontSize),
                    ),
                  ),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
