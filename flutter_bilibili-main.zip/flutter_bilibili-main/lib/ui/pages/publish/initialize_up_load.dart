List<String> upLoadTabList = ["视频", "照片", "文件夹"];
