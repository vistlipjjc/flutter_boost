import 'package:flutter/material.dart';
import 'package:flutter_bilibili/ui/pages/publish/baidu_map_location.dart';
import 'package:flutter_bilibili/ui/shared/app_theme.dart';
import 'package:flutter_bilibili/ui/shared/image_assets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class HYReady2PublishContent extends StatefulWidget {
  const HYReady2PublishContent({Key? key}) : super(key: key);

  @override
  State<HYReady2PublishContent> createState() => _HYReady2PublishContentState();
}

class _HYReady2PublishContentState extends State<HYReady2PublishContent> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Theme.of(context).canvasColor,
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15).r,
      child: ListView(
        children: [
          buildReady2PublishVideoCover(),
          10.verticalSpace,
          buildReady2PublishVideoTitle(),
          10.verticalSpace,
          buildReady2PublishVideoType(),
          buildReady2PublishVideoDetailButton(),
          buildReady2PublishVideoDetail(),
        ],
      ),
    );
  }

  Widget buildReady2PublishVideoDetailButton() {
    return Container(
      padding: const EdgeInsets.all(10).r,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text(
            "收起",
            style: TextStyle(
                color: HYAppTheme.norTextColors,
                fontSize: HYAppTheme.xSmallFontSize),
          ),
          10.horizontalSpace,
          Image.asset(
            ImageAssets.icArrowUpPNG,
            width: 10.w,
            height: 10.h,
          )
        ],
      ),
    );
  }

  Widget buildReady2PublishVideoDetail() {
    List<String> _titleList = ["添加水印", "定时发布", "精选评论区"];
    List<String> _subTitleList = ["", "转载稿件撞车判定将以定时发布时间为准", "评论经过你的筛选才会向所有人展示"];
    return Container(
      padding: const EdgeInsets.all(10).r,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(4.r)),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            "简介",
            style: TextStyle(
              color: HYAppTheme.norTextColors,
              fontSize: HYAppTheme.xSmallFontSize,
            ),
          ),
          10.verticalSpace,
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(
                Radius.circular(4.r),
              ),
            ),
            child: Container(
              padding: const EdgeInsets.all(5).r,
              color: HYAppTheme.norGrayColor.withOpacity(.1),
              child: TextField(
                showCursor: true,
                maxLength: 2000,
                maxLines: 4,
                textAlign: TextAlign.start,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: '可填写简介',
                  hintStyle: TextStyle(fontSize: HYAppTheme.xSmallFontSize),
                  contentPadding: const EdgeInsets.all(10).r,
                ),
              ),
            ),
          ),
          10.verticalSpace,
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (ctx, index) {
              return ListTile(
                  title: Text(
                    _titleList[index],
                    style: TextStyle(
                      color: HYAppTheme.norTextColors,
                      fontSize: HYAppTheme.xSmallFontSize,
                    ),
                  ),
                  subtitle: Text(
                    _subTitleList[index],
                    style: TextStyle(
                      color: HYAppTheme.norTextColors,
                      fontSize: HYAppTheme.xxSmallFontSize,
                    ),
                  ),
                  trailing: Switch(
                    value: false,
                    onChanged: (_) {
                      ///待改
                    },
                    activeColor: HYAppTheme.norMainThemeColors,
                  ));
            },
            separatorBuilder: (ctx, index) {
              return Divider(
                height: .3.h,
                color: HYAppTheme.norGrayColor,
              );
            },
            itemCount: 3,
          ),
          10.verticalSpace,
          Text(
            "动态",
            style: TextStyle(
              color: HYAppTheme.norTextColors,
              fontSize: HYAppTheme.xSmallFontSize,
            ),
          ),
          10.verticalSpace,
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(
                Radius.circular(4.r),
              ),
            ),
            child: Container(
              padding: const EdgeInsets.all(5).r,
              color: HYAppTheme.norGrayColor.withOpacity(.1),
              child: TextField(
                showCursor: true,
                maxLength: 2000,
                maxLines: 4,
                textAlign: TextAlign.start,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: '编辑此投稿的动态、把稿件推荐给粉丝',
                  hintStyle: TextStyle(fontSize: HYAppTheme.xSmallFontSize),
                  contentPadding: const EdgeInsets.all(10).r,
                ),
              ),
            ),
          ),
          10.verticalSpace,
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.of(context)
                      .pushNamed(HYBaiduMapLocationScreen.routeName);
                },
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4).r,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset(
                        "assets/image/icon/ic_following_lbs_detail_location.png",
                        width: 15.w,
                        height: 15.h,
                      ),
                      5.horizontalSpace,
                      const Text(
                        "你在哪里?",
                        style: TextStyle(color: HYAppTheme.norTextColors),
                      ),
                    ],
                  ),
                  decoration: BoxDecoration(
                    color: HYAppTheme.norGrayColor.withOpacity(.1),
                    borderRadius: BorderRadius.all(Radius.circular(20.r)),
                  ),
                ),
              ),
              15.horizontalSpace,
              Image.asset(
                ImageAssets.icVoteCommonPNG,
                width: 18.w,
                height: 18.h,
              ),
            ],
          )
        ],
      ),
    );
  }

  ///视频封面
  Widget buildReady2PublishVideoCover() {
    return Container(
      height: 200.h,
      child: Image.asset(
        "assets/image/icon/img_holder_pay_success.png",
        fit: BoxFit.contain,
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(4.r)),
        color: Colors.white,
      ),
    );
  }

  ///视频标题
  Widget buildReady2PublishVideoTitle() {
    return Container(
      padding: const EdgeInsets.all(10).r,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(4.r)),
          color: Colors.white),
      child: Container(
        padding: const EdgeInsets.all(5).r,
        color: HYAppTheme.norGrayColor.withOpacity(.1),
        child: TextField(
          showCursor: true,
          maxLength: 80,
          maxLines: 3,
          textAlign: TextAlign.start,
          decoration: InputDecoration(
              contentPadding: const EdgeInsets.all(10).r,
              border: InputBorder.none,
              hintText: '请输入标题（必填）',
              hintStyle: TextStyle(fontSize: HYAppTheme.xSmallFontSize)),
        ),
      ),
    );
  }

  ///视频分区
  Widget buildReady2PublishVideoType() {
    return Container(
      padding: const EdgeInsets.all(10).r,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(4.r)),
        color: Colors.white,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "选择分区和标签（必填）",
                style: TextStyle(
                    color: HYAppTheme.norGrayColor,
                    fontSize: HYAppTheme.smallFontSize),
              ),
              Image.asset(
                "assets/image/icon/ic_staff_group_more.png",
                width: 18.w,
                height: 18.h,
              )
            ],
          ),
          15.verticalSpace,
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "类型（必填）",
                style: TextStyle(
                    color: HYAppTheme.norTextColors,
                    fontSize: HYAppTheme.smallFontSize),
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset(
                    "assets/image/icon/abc_btn_radio_to_on_mtrl_000.png",
                    width: 20.w,
                    height: 20.h,
                    color: HYAppTheme.norGrayColor,
                  ),
                  5.horizontalSpace,
                  Text(
                    "自制",
                    style: TextStyle(
                        color: HYAppTheme.norTextColors,
                        fontSize: HYAppTheme.smallFontSize),
                  ),
                  15.horizontalSpace,
                  Image.asset(
                    "assets/image/icon/abc_btn_radio_to_on_mtrl_000.png",
                    width: 20.w,
                    height: 20.h,
                    color: HYAppTheme.norGrayColor,
                  ),
                  5.horizontalSpace,
                  Text(
                    "转载",
                    style: TextStyle(
                        color: HYAppTheme.norTextColors,
                        fontSize: HYAppTheme.smallFontSize),
                  ),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }
}
