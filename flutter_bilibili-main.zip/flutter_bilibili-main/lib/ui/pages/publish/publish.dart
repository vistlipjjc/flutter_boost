import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bilibili/ui/pages/publish/ready_2_publish.dart';
import 'package:flutter_bilibili/ui/pages/publish/up_load.dart';
import 'package:flutter_bilibili/ui/shared/platform_judge.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../shared/app_theme.dart';
import 'initialize_publish.dart';

class HYPublishScreen extends StatelessWidget {
  static String routeName = "/publish";

  const HYPublishScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: DefaultTabController(
        initialIndex: 2,
        length: 5,
        child: Scaffold(
          backgroundColor: HYAppTheme.norTextColors,
          bottomNavigationBar: TabBar(
            labelColor: Colors.white,
            tabs: publishTabList.map((e) => Tab(text: e)).toList(),
            indicatorColor: HYAppTheme.norMainThemeColors,
            indicatorWeight: 4.h,
            indicatorSize: TabBarIndicatorSize.label,
            padding: const EdgeInsets.all(10).r,
            labelPadding: const EdgeInsets.symmetric(vertical: 5).r,
          ),
          body: PlatformJudge.platformJudgeIsPhone()
              ? TabBarView(
                  children: [
                    Container(),
                    Container(),
                    const HYPublishUpLoad(),
                    Container(),
                    Container(),
                  ],
                )
              : Container(),

          ///压扁的floatingActionButton
          floatingActionButton: FloatingActionButton.extended(
            backgroundColor: HYAppTheme.norMainThemeColors,
            onPressed: () {
              Navigator.of(context).pushNamed(HYReady2PublishScreen.routeName);
            },
            label: Text(
              "去发布",
              style: TextStyle(
                fontSize: HYAppTheme.xSmallFontSize,
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
