import 'package:flutter/material.dart';
import 'package:flutter_bilibili/ui/pages/home/home.dart';
import 'package:flutter_bilibili/ui/pages/publish/publish.dart';
import 'package:flutter_bilibili/ui/shared/app_theme.dart';
import 'package:flutter_bilibili/ui/shared/image_assets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get_utils/get_utils.dart';
import '../../../core/I18n/str_res_keys.dart';
import '../dynamic_circle/dynamic_circle.dart';
import '../mine/mine.dart';
import '../vip_shop/vip_shop.dart';

final _iconSize = 18.sp;

///未点击时的大小
final _activeIcon = 18.sp;

///点击时的大小
final List<Widget> mainIndexStackPages = [
  const HYHomeScreen(),
  const HYDynamicCircleScreen(),
  const HYPublishScreen(),
  const HYVipShopScreen(),
  const HYMineScreen(),
];

///中间的按钮
BottomNavigationBarItem buildBottomNavigationBarCenterBarItem() {
  return BottomNavigationBarItem(
    label: "",
    icon: Container(
      margin: EdgeInsets.only(top: 5.h),
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 13).r,
      child: Image.asset(
        ImageAssets.addCustomPNG,
        width: 15.sp,
        height: 15.sp,
      ),
      decoration: BoxDecoration(
        color: HYAppTheme.norMainThemeColors,
        borderRadius: BorderRadius.all(
          Radius.circular(12.r),
        ),
      ),
    ),
  );
}

///首页、动态、会员购、我的
BottomNavigationBarItem buildBottomNavigationBarItem(
    String title, String iconName) {
  return BottomNavigationBarItem(
    label: title,
    icon: Image.asset(
      "assets/image/icon/${iconName}_custom.png",
      width: _iconSize,
      height: _iconSize,
      gaplessPlayback: true, //gaplessPlayback: 原图片保持不变，直到图片加载完成时替换图片，这样就不会出现闪烁
    ),
    activeIcon: Image.asset(
      "assets/image/icon/${iconName}_selected.png",
      width: _activeIcon,
      height: _activeIcon,
      gaplessPlayback: true,
    ),
  );
}
