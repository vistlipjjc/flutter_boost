import 'package:flutter/material.dart';
import 'package:flutter_bilibili/ui/pages/charts/pie_chart/pie_chart_samples.dart';
import 'package:flutter_bilibili/ui/pages/charts/radar_chart/radar_chart_samples.dart';
import 'package:flutter_bilibili/ui/pages/charts/scatter_chart/scatter_chart_samples.dart';

import '../../shared/app_theme.dart';
import 'bar_chart/bar_chart_samples.dart';
import 'line_chart/line_chart_samples.dart';

class HYChartsContent extends StatefulWidget {
  const HYChartsContent({Key? key}) : super(key: key);

  @override
  State<HYChartsContent> createState() => _HYChartsContentState();
}

class _HYChartsContentState extends State<HYChartsContent> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      initialIndex: 0,
      child: Scaffold(
        appBar: AppBar(
          elevation: .5,
          centerTitle: true,
          title: Text(
            "图表【fl_chart】",
            style: TextStyle(fontSize: HYAppTheme.smallFontSize),
          ),
          bottom: const TabBar(
            tabs: [
              Tab(text: "线图"),
              Tab(text: "柱图"),
              Tab(text: "饼图"),
              Tab(text: "雷达图"),
              Tab(text: "散列图"),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            HYLineChartSamples(),
            HYBarChartSamples(),
            HYPieChartSamples(),
            HYRadarChartSamples(),
            HYScatterChartSamples()
          ],
        ),
      ),
    );
  }
}
