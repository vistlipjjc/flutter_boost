import 'package:flutter/material.dart';
import 'package:flutter_bilibili/ui/pages/charts/charts_content.dart';

class HYChartScreen extends StatelessWidget {
  const HYChartScreen({Key? key}) : super(key: key);
  static const String routeName = "/charts";

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: SafeArea(
        child: HYChartsContent(),
      ),
    );
  }
}
