import 'package:flutter/material.dart';

class HYDynamicCircleScreen extends StatefulWidget {
  static const String routeName = "/dynamic_circle";

  const HYDynamicCircleScreen({Key? key}) : super(key: key);

  @override
  State<HYDynamicCircleScreen> createState() => _HYDynamicCircleScreenState();
}

class _HYDynamicCircleScreenState extends State<HYDynamicCircleScreen> {

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('动态'),
        ),
      ),
    );
  }
}