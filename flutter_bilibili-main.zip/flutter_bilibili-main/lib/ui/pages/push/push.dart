import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';

class HYPushScreen extends StatefulWidget {
  static const String routeName = "/push";

  const HYPushScreen({Key? key}) : super(key: key);

  @override
  State<HYPushScreen> createState() => _HYPushScreenState();
}

class _HYPushScreenState extends State<HYPushScreen> {
  // late HYNotification notification;
  late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;
  late InitializationSettings initializationSettings;

  @override
  void initState() {
    // notification = HYNotification();
    requestPermission();
    flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
    var android = const AndroidInitializationSettings('@mipmap/ic_launcher');
    initializationSettings = InitializationSettings(android: android);
    flutterLocalNotificationsPlugin
        .initialize(
      initializationSettings,
      // onSelectNotification: selectNotification
    )
        .then((value) {
      print("flutterLocalNotificationsPlugin本地初始化成功");
    });
    super.initState();
  }

  Future<void> _showNotification() async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails('your channel id', 'your channel name',
            channelDescription: 'your channel description',
            importance: Importance.max,
            priority: Priority.high,
            ticker: 'ticker');
    const NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);
    await flutterLocalNotificationsPlugin.show(
        0, 'plain title', 'plain body', platformChannelSpecifics,
        payload: 'item x');
  }

  Future requestPermission() async {
    Map<Permission, PermissionStatus> statuses = await [
      Permission.notification,
    ].request();
  }

  // Future selectNotification(String payload) {
  //   debugPrint('notification payload: $payload');
  //   showDialog(
  //       context: context,
  //       builder: (_) {
  //         return AlertDialog(
  //           title: Text("data"),
  //           content: Text("data"),
  //         );
  //       });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () async {
          await _showNotification();
          // notification.send("标题", "内容");
        },
      ),
    );
    // return HYPushContent();
  }
}
