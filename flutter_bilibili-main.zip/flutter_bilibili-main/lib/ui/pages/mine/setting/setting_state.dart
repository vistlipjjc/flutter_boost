import 'package:flutter_bilibili/core/shared_preferences/bilibili_shared_preference.dart';
import 'package:flutter_bilibili/core/shared_preferences/shared_preference_util.dart';

class SettingState {
  late bool isLogin;

  SettingState() {
    ///是否登录
    isLogin =
        SharedPreferenceUtil.getBool(BilibiliSharedPreference.isLogin) ?? false;
  }
}
