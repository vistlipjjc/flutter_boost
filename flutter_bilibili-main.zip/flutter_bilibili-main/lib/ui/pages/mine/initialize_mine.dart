import 'package:flutter_screenutil/flutter_screenutil.dart';

final double iconSize = 17.sp;