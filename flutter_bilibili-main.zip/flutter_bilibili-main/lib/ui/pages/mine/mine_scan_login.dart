import 'package:flutter/material.dart';
import 'package:flutter_bilibili/core/extension/int_extension.dart';
import 'package:flutter_bilibili/ui/shared/app_theme.dart';
import 'package:flutter_bilibili/ui/shared/image_assets.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:scan/scan.dart';
import 'package:url_launcher/url_launcher_string.dart';

class HYMineScanLogin extends StatefulWidget {
  static const String routeName = "/scanLogin";

  @override
  State<HYMineScanLogin> createState() => _HYMineScanLoginState();
}

class _HYMineScanLoginState extends State<HYMineScanLogin> {
  IconData lightIcon = Icons.flash_on;

  final ScanController _controller = ScanController();

  void getResult(String result, BuildContext context) async {
    result = "youku:// ";
    if (await canLaunchUrlString(result)) {
      await launchUrlString(result);
    } else {
      throw 'Could not launch $result';
    }
    // Navigator.of(context).pushNamed(HYLaunchUrl.routeName, arguments: result);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,

      ///顶部bar为透明色
      appBar: AppBar(
        title: Text(
          "扫描二维码",
          style: TextStyle(
              color: Colors.white,
              fontSize: HYAppTheme.smallFontSize,
              fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Stack(
        children: [
          ScanView(
            ///扫描
            controller: _controller,
            scanLineColor: HYAppTheme.norPink07Colors,
            scanAreaScale: 1,
            onCapture: (data) {
              _controller.pause();
              getResult(data, context);
            },
          ),
          Positioned(
            left: 30.w,
            bottom: 30.h,
            child: SizedBox(
              height: 60.h,
              width: 60.w,
              child: CircleAvatar(
                child: Image.asset(
                  ImageAssets.myProfilePNG,
                  width: 30.w,
                  height: 30.h,
                ),
                backgroundColor: HYAppTheme.norTextColors.withOpacity(.5),
              ),
            ),
          ),
          Positioned(
            right: 30.w,
            bottom: 30.h,
            child: SizedBox(
              height: 60.h,
              width: 60.w,
              child: GestureDetector(
                onTap: () async {
                  // List<Media>? res =
                  //     await ImagesPicker.pick(count: 1, maxSize: 1024);
                  // if (res != null) {
                  //   _controller.pause();
                  //   Media image = res.first;
                  //   String? result = await Scan.parse(image.path);
                  //   if (result != null) {
                  //     getResult(result, context);
                  //   }
                  // }
                },
                child: CircleAvatar(
                  child: Image.asset(
                    ImageAssets.photoPNG,
                    width: 30.w,
                    height: 30.h,
                  ),
                  backgroundColor: Color.fromRGBO(0, 0, 0, .5),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
