// import 'package:flutter/material.dart';
// import 'package:url_launcher/url_launcher_string.dart';
//
// class HYLaunchUrl extends StatefulWidget {
//   static const String routeName = "/launch_url";
//
//   @override
//   State<HYLaunchUrl> createState() => _HYLaunchUrlState();
// }
//
// class _HYLaunchUrlState extends State<HYLaunchUrl> {
//   Future<void>? _launched;
//
//   Future<void> _launchInWebViewOrVC(String url) async {
//     if (!await launchUrlString(
//       url,
//       mode: LaunchMode.inAppWebView,
//     )) {
//       throw 'Could not launch $url';
//     }
//   }
//
//   Widget _launchStatus(BuildContext context, AsyncSnapshot<void> snapshot) {
//     if (snapshot.hasError) {
//       return Text('Error: ${snapshot.error}');
//     } else {
//       return const Text('');
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final String url = ModalRoute.of(context)?.settings.arguments as String;
//     _launched = _launchInWebViewOrVC(url);
//     return Scaffold(
//       appBar: AppBar(
//         centerTitle: true,
//         title: Text("扫码登录", style: TextStyle(color: Colors.black),),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(10.0),
//         child: FutureBuilder(
//           builder: _launchStatus,
//           future: _launched,
//         ),
//       ),
//     );
//   }
// }
