import 'package:flutter/material.dart';

import 'mine_content.dart';

class HYMineScreen extends StatelessWidget {
  static const String routeName = "/mine";

  const HYMineScreen({Key? key}) : super(key: key); //起始路由

  @override
  Widget build(BuildContext context) {
    return const SafeArea(child: HYMineContent());
  }
}
