import 'package:flutter/material.dart';

import 'offline_content.dart';

class HYOfflineCacheScreen extends StatelessWidget {
  static String routeName = "/offline_cache";

  const HYOfflineCacheScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _localPath = ModalRoute.of(context)!.settings.arguments as String;
    return HYOfflineContent(_localPath);
  }
}
