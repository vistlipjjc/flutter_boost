import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bilibili/ui/shared/app_theme.dart';

class HYOfflineContent extends StatefulWidget {
  String localPath;

  HYOfflineContent(this.localPath, {Key? key}) : super(key: key);

  @override
  State<HYOfflineContent> createState() => _HYOfflineContentState();
}

class _HYOfflineContentState extends State<HYOfflineContent> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: .5,
        title: Text(
          "离线缓存",
          style: TextStyle(
              color: HYAppTheme.norTextColors,
              fontSize: HYAppTheme.smallFontSize),
        ),
      ),
      body: Column(
        children: [
          Text(
            "已缓存视频",
            style: TextStyle(
                color: HYAppTheme.norTextColors,
                fontSize: HYAppTheme.xSmallFontSize),
          ),
          Expanded(
            child: ListView(
              children: [],
            ),
          )
        ],
      ),
    );
  }

  void getFiles() async {
    Stream<FileSystemEntity> fileList = Directory(
            "/storage/emulated/0/Android/data/com.example.flutter_bilibili/files/bilibili_download")
        .list();
    await for (FileSystemEntity fileSystemEntity in fileList) {
      print('$fileSystemEntity');
    }
  }
}
