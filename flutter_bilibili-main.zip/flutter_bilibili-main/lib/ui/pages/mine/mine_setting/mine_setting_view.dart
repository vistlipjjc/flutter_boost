import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'mine_setting_logic.dart';

class Mine_settingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final logic = Get.find<Mine_settingLogic>();
    final state = Get.find<Mine_settingLogic>().state;

    return Container();
  }
}
