class Mine_settingState {
  Mine_settingState() {
    ///Initialize variables
  }
}
