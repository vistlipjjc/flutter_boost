import 'package:get/get.dart';

import 'mine_setting_logic.dart';

class Mine_settingBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => Mine_settingLogic());
  }
}
