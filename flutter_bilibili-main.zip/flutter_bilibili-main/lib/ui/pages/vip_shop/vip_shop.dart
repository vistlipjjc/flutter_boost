import 'package:flutter/material.dart';

class HYVipShopScreen extends StatefulWidget {
  static const String routeName = "/vip_shop";

  const HYVipShopScreen({Key? key}) : super(key: key);

  @override
  State<HYVipShopScreen> createState() => _HYVipShopScreenState();
}

class _HYVipShopScreenState extends State<HYVipShopScreen> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("会员购"),
      ),
    );
  }
}
