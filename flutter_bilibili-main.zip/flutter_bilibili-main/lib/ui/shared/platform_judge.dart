import 'dart:io';

import 'package:flutter/foundation.dart';

class PlatformJudge {
  static platformJudgeIsPhone() {
    if (kIsWeb) {
      return false;
    } else {
      if (Platform.isAndroid || Platform.isIOS) {
        return true;
      } else {
        return false;
      }
    }
  }
}
