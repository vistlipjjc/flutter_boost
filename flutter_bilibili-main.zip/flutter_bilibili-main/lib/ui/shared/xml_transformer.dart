import 'package:xml2json/xml2json.dart';
transformerXmlToJson(var xmlString) {
  final myTransformer = Xml2Json();
  myTransformer.parse(xmlString);
  var json = myTransformer.toGData();
  // return myTransformer.toBadgerfish();
  return myTransformer.toParker();
  return myTransformer.toParkerWithAttrs();
  return myTransformer.toBadgerfish();
}