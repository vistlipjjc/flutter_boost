import 'package:flutter/material.dart';
import 'package:flutter_bilibili/ui/shared/app_theme.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

///广告栏
class HYAdvertisingRow extends StatelessWidget {
  String image;
  String title;
  Widget rightBtn;

  HYAdvertisingRow(
      {Key? key,
      required this.image,
      required this.title,
      required this.rightBtn})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          decoration: BoxDecoration(
              color: HYAppTheme.norWhite02Color,
              borderRadius: BorderRadius.all(Radius.circular(3.r))),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10).r,
          child: Row(
            children: [
              SizedBox(
                child: Image.network(image),
                height: HYAppTheme.xSmallFontSize,
                width: HYAppTheme.xSmallFontSize,
              ),
              10.horizontalSpace,
              Text(
                title,
                style: TextStyle(
                    color: HYAppTheme.norTextColors,
                    fontSize: HYAppTheme.xSmallFontSize),
              ),
            ],
          ),
        ),
        Positioned(
          child: rightBtn,
          right: 10.w,
          top: 0,
          bottom: 0,
        )
      ],
    );
  }
}
