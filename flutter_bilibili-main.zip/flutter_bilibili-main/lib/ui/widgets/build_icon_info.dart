import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../shared/app_theme.dart';

Widget buildIconInfo(String icon, String text) {
  return Row(
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      Image.asset(
        icon,
        width: 16.w,
        height: 16.h,
      ),
      Container(
        margin: const EdgeInsets.only(left: 5).r,
        child: Text(
          text,
          style: TextStyle(
              color: HYAppTheme.norGrayColor,
              fontSize: HYAppTheme.xxSmallFontSize),
        ),
      )
    ],
  );
}
