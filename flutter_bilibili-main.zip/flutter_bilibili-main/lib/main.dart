import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bilibili/core/shared_preferences/shared_preference_util.dart';
import 'package:flutter_bilibili/core/viewmodel/feed_index_view_model.dart';
import 'package:flutter_bilibili/core/viewmodel/live_room_view_model.dart';
import 'package:flutter_bilibili/core/viewmodel/upload_video_notifier.dart';
import 'package:flutter_bilibili/core/viewmodel/video_view_model.dart';
import 'package:flutter_bilibili/ui/shared/app_theme.dart';
import 'package:flutter_bilibili/core/viewmodel/player_notifier.dart';
import 'package:flutter_bilibili/ui/shared/platform_judge.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:provider/provider.dart';

import 'core/I18n/string_res.dart';
import 'core/router/router.dart';
import 'core/shared_preferences/bilibili_shared_preference.dart';
import 'core/viewmodel/base_data_view_model.dart';
import 'dart:ui' as ui;

main() async {
  if (PlatformJudge.platformJudgeIsPhone()) {
    WidgetsFlutterBinding.ensureInitialized();

    ///强制竖屏
    SystemChrome.setPreferredOrientations(
        [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);

    ///缓存视频导入和初始化
    await FlutterDownloader.initialize(debug: false, ignoreSsl: true);

    ///实例化sharedPreference
    await SharedPreferenceUtil.getInstance();

    ///手机状态栏的背景颜色及状态栏文字颜色
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        ///状态栏字体颜色（黑色）
        statusBarIconBrightness: Brightness.dark,

        ///状态栏背景色
        statusBarColor: Colors.white,
      ),
    );
  } else {
    await SharedPreferenceUtil.getInstance();
  }
  runApp(
    MultiProvider(
      ///配置共享数据
      providers: [
        ///基础数据包括主页每次加载多少数据，加载多少页，分区是什么
        ChangeNotifierProvider(create: (ctx) => HYBaseDataViewModel()),

        ///直播间贡共享数据，包括当前有哪些直播间
        ChangeNotifierProvider(create: (ctx) => HYLiveRoomViewModel()),

        ///发布视频
        ChangeNotifierProvider(create: (ctx) => PlayerNotifier.init()),
        ChangeNotifierProvider(create: (ctx) => UploadVideoNotifier()),

        ///代理，当HYVideoViewModel需要用到HYBaseDataViewModel的数据时，使用代理。视频详细数据
        ChangeNotifierProxyProvider<HYBaseDataViewModel, HYVideoViewModel>(
          create: (cts) => HYVideoViewModel(),
          update: (ctx, baseDataVM, videoVM) {
            videoVM?.updateBaseData(baseDataVM);
            return videoVM as HYVideoViewModel;
          },
        ),

        ///首页推荐视频新接口
        ChangeNotifierProvider(create: (ctx) => HYFeedIndexViewModel()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  ///APP从此处开始
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      minTextAdapt: true,
      splitScreenMode: true,
      designSize: const Size(360, 690),
      builder: (ctx, child) {
        ///保存本地语言
        String? _locale =
            SharedPreferenceUtil.getString(BilibiliSharedPreference.locale);
        if (_locale!.isEmpty) {
          SharedPreferenceUtil.setString(
              BilibiliSharedPreference.locale, ui.window.locale.languageCode);
        }
        return GetMaterialApp(
          ///去掉右上角的debug
          debugShowCheckedModeBanner: false,

          ///APP名称
          title: '哔哩哔哩',

          ///主题
          theme: HYAppTheme.norTheme,

          ///起始路由
          initialRoute: HYRouter.initialRoute,

          ///对应的路由
          routes: HYRouter.routes,

          ///后面再改
          // onGenerateRoute: HYRouter.generateRoute,

          ///未找到也面跳转至该页
          // onUnknownRoute: HYRouter.unKnowRoute,

          ///smartDialog 插件需要初始化
          navigatorObservers: [FlutterSmartDialog.observer],

          ///smartDialog 插件需要初始化
          builder: FlutterSmartDialog.init(),

          ///I18n国际化
          translations: StringRes(),
          locale: _locale == "zh"
              ? const Locale('zh', 'CN')
              : const Locale('en', 'US'),
          fallbackLocale: const Locale('zh', 'CN'),

          ///getX
          // getPages: HYRouter.getPages,
        );
      },
    );
  }
}
