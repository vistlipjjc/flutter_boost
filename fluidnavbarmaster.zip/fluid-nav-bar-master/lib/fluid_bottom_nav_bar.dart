library fluid_bottom_nav_bar;

export 'src/fluid_nav_bar.dart';
export 'src/fluid_nav_bar_icon.dart';
export 'src/fluid_nav_bar_style.dart';
