const Map<String, String> en_US = {
  "appName": "LuoXun",
  "pushLabel": "You have pushed the button this many times:",

  "navigationHome": "Home",
  "navigationFind": "Find",
  "navigationMap": "Map",
  "navigationMessage": "Message",
  "navigationMine": "Mine",

  "exitBy2Click": "click again to exit",

  "menuSettings": "Settings",
  "menuAbout": "About",
  "menuLanguage": "Language",
  "menuTheme": "Theme",
  "menuLogOut": "LogOut",
  "languageChinese": "Chinese",
  "languageEnglish": "English",
  "languageAuto": "Auto"
};