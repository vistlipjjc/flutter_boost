//程序的主入口
import 'init/app_init.dart';

void main() => AppInit.run();