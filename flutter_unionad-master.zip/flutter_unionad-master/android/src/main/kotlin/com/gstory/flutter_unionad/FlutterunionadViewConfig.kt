package com.gstory.flutter_unionad

class FlutterunionadViewConfig {

    companion object {
         //event事件
         const val adevent = "com.gstory.flutter_unionad/adevent"
        //SplashAdView
        const val splashAdView = "com.gstory.flutter_unionad/SplashAdView"

        //BannerAdView
        const val bannerAdView = "com.gstory.flutter_unionad/BannerAdView"

        //NativeAdView
        const val nativeAdView = "com.gstory.flutter_unionad/NativeAdView"

        //InteractionAdVie
        const val interactionAdVie = "com.gstory.flutter_unionad/InteractionAdVie"

        //DrawFeedAdView
        const val drawFeedAdView = "com.gstory.flutter_unionad/DrawFeedAdView"
    }
}