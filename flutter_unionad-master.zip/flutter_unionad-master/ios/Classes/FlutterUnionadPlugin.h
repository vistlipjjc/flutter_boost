#import <Flutter/Flutter.h>

@interface FlutterUnionadPlugin : NSObject<FlutterPlugin>
@end
